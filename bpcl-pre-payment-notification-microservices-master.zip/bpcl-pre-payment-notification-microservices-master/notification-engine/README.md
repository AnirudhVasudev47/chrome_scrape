# Clone the repository

```
$ git clone https://gitlab.com/nishranjan/bpcl-pre-payment-notification-microservices.git
```

# Installation
- `npm install`

Creating a new project with the Nest CLI is recommended for first-time users. [https://docs.nestjs.com/]((https://docs.nestjs.com/))
- `npm i -g @nestjs/cli`
- `nest new project-name`

# Running the app:

## development
  `npm run start` to start the local server.

## watch mode
  `npm run start:dev`

## production mode
  `npm run start:prod`

# Test

## unit tests
  `npm run test`

## e2e tests
  `npm run test:e2e`

## test coverage
  `npm run test:cov`


## Connecting the database

```bash
# run docker image from root directory of your project
$ docker-compose up -d
```

To run the database in your local you need MySQL Workbench installed.
Open MySQL worknech and start a new connection:

* Provide database name and password according to `ormconfig.json` and connect to the database.
* Run the following queries with workbench. Replace the 'passowrd' in the first query with the password parameter from `ormconfig.json`

1. ```ALTER USER 'root' IDENTIFIED WITH mysql_native_password BY 'password'```
2. `flush privileges;`


