import { TypeOrmModuleOptions } from '@nestjs/typeorm';
import * as config from 'config';
import { LoggerService } from 'src/utility/logger/logger.service';

const dbConfig = config.get('db');

const logger = new LoggerService('Database Initialization');

const typeOrmConfig: TypeOrmModuleOptions = {
    type: dbConfig.type,
    host: dbConfig.host,
    port: dbConfig.port,
    username: dbConfig.username,
    password: dbConfig.password,
    database: dbConfig.database,
    entities: ["dist/**/*.entity{.ts,.js}"],
    synchronize: dbConfig.synchronize,
    migrations: ["src/migration/**/*.ts"],
    subscribers: ["src/subscriber/**/*.ts"]
}

logger.log(`type: ${typeOrmConfig.type}, host: ${typeOrmConfig.host}, port: ${typeOrmConfig.port}, database: ${typeOrmConfig.database},`);

export  {typeOrmConfig}
