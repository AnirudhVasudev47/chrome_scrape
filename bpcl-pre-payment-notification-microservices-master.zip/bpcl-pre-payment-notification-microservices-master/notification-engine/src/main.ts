import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import * as config from 'config';
import { Transport } from '@nestjs/microservices';
import { join } from 'path';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { AppService } from './app.service';
import { LoggerService } from './utility/logger/logger.service';
const url = config.get('url');

//grpc microservice options setup
const microserviceOptions = {
  transport: Transport.GRPC,
  options: {
    package: 'notification',
    protoPath: join(__dirname, '../src/proto/notification.proto'),
    url: url.notification,
  },
  logger: new LoggerService('Notification Engine Main')
};


async function bootstrap() {
  const serverConfig = config.get('server');
  //const app = await NestFactory.create(AppModule);
  //microservice instantiated with grpc configurations
  const app = await NestFactory.createMicroservice(
    AppModule,
    microserviceOptions,
  );
  //app.enableCors();
  const options = new DocumentBuilder()
    .setTitle('BPCL-Prepayment')
    .setDescription('Notification Engine(sms/email)')
    .setVersion('1.0')
    .addTag('Notification Engine')
    .build();
  // const document = SwaggerModule.createDocument(app, options);
  // SwaggerModule.setup('api', app, document);

  //const port = process.env.PORT || serverConfig.port;
  // await app.listen(port);
  const logger = app.get(LoggerService)
  app.useLogger(new LoggerService('Main'))

  await app.listen(() => {
    logger.log(`Notification Microservice is listening on ${microserviceOptions.options['url']}`);
  });

  // logger.log(`Application listening on port ${port}`);
}
bootstrap();
