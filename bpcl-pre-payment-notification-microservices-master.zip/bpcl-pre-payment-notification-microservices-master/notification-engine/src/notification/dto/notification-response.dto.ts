import { IsString, MaxLength, IsNumber, IsOptional } from 'class-validator';

export class NotificationResponseDto {

    @IsString()
    status:string;

    @IsString()
    timeStamp: Date;
}