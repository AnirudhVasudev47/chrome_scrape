import { Controller, UseFilters } from '@nestjs/common';
import { EmailService } from 'src/email/email.service';
import { SmsService } from 'src/sms/sms.service';
import { EmailRequestDto } from '../email/dto/email-request.dto';
import { NotificationResponseDto } from './dto/notification-response.dto';
import { logMessage } from 'src/utility/log-message/log-message';
import { GrpcMethod, RpcException } from '@nestjs/microservices';
import { SmsRequestDto } from 'src/sms/dto/sms-request.dto';
import { LoggerService } from 'src/utility/logger/logger.service';
import { GrpcExceptionFilter } from '../utility/filters/rpc-exception.filter';

//receive sms/email notifications from the client.
@Controller('notification')
@UseFilters(GrpcExceptionFilter)
export class NotificationController {
  private logger = new LoggerService(NotificationController.name);
  constructor(
    private readonly emailService: EmailService,
    private readonly smsService: SmsService,
  ) {}

  //receives the Email notifications and sends email notifications to the customers.
  // @UsePipes(ValidationPipe)
  @GrpcMethod('NotificationController', 'SendEmail')
  async sendEmail(emailRequestDto: EmailRequestDto): Promise<void> {
    try {
      const { emailRequest } = emailRequestDto;
      emailRequest.forEach(async email => {
        this.logger.verbose(
          `${logMessage.EMAIL_NOTIFICATION_RECEIVED} ${email.receiverMail}`,
        );

        //save email notification details before sending
        let id = await this.emailService.saveEmail(email);

        //send and update email status
        await this.emailService.sendEmail(email, id);
      });
    } catch (error) {
      throw new RpcException(`${logMessage.FAILED_TO_SEND_EMAIL_NOTIFICATION}`);
    }
  }

  //receive the sms notifications and sends sms to customers
  @GrpcMethod('NotificationController', 'SendSms')
  async sendSms(
    smsRequestDto: SmsRequestDto,
  ): Promise<NotificationResponseDto> {
    try {
      this.logger.verbose(
        `${logMessage.SMS_NOTIFICATION_RECEIVED} ${JSON.stringify(
          smsRequestDto,
        )}`,
      );

      // 1.save sms in database
      const id = await this.smsService.saveSms(smsRequestDto);
      // 2.send sms to customer by yellow messenger
      const status = await this.smsService.sendSmsByYellowMessenger(smsRequestDto, id);

      return status;
    } catch (error) {
      throw new RpcException(`${logMessage.FAILED_TO_SEND_SMS_NOTIFICATION}`);
    }
  }
}
