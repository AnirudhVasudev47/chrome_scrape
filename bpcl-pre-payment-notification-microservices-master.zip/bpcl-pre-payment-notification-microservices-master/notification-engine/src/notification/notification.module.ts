import { Module, HttpModule } from '@nestjs/common';
import { NotificationController } from './notification.controller';
import { SmsService } from 'src/sms/sms.service';
import { EmailService } from 'src/email/email.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Sms } from 'src/sms/sms.entity';
import { Email } from 'src/email/email.entity';
import { LoggerModule } from 'src/utility/logger/logger.module';

@Module({
  imports: [
    LoggerModule,
    TypeOrmModule.forFeature([Sms, Email]),
    HttpModule.register({
      timeout: 5000,
      maxRedirects: 3,
    })
  ],
  controllers: [NotificationController],
  providers: [SmsService, EmailService]
})
export class NotificationModule { }
