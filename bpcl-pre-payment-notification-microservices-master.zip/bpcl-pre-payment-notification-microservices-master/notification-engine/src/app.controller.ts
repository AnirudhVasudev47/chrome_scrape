import { Controller, Get, UseFilters } from '@nestjs/common';
import { AppService } from './app.service';
import { LoggerService } from './utility/logger/logger.service';
import { GrpcExceptionFilter } from './utility/filters/rpc-exception.filter';

@Controller()
@UseFilters(GrpcExceptionFilter)
export class AppController {
  private logger = new LoggerService(AppController.name);
  constructor(private readonly appService: AppService) { }

  @Get()
  getHello(): string {
    return this.appService.getHello();
  }
}
