import { PrimaryGeneratedColumn, Column, Entity, BaseEntity, IsNull, Timestamp, CreateDateColumn, UpdateDateColumn, VersionColumn, PrimaryColumn } from "typeorm";

export enum EmailStatus {
    SUCCESS = "SUCCESS",
    FAIL = "FAIL",
}

@Entity('email')
export class Email extends BaseEntity {
    @PrimaryGeneratedColumn("uuid")
    id: string;

    //@PrimaryColumn()
    @Column()
    uid: string; // id

    @Column({ nullable: true })
    senderMail: string;

    @Column({ nullable: true })
    receiverMail: string;

    // @Column({ nullable: true })
    // subject: string;

    // @Column({ nullable: true })
    // content: string;

    @Column({
        type: 'enum',
        enum: EmailStatus,
        // default: VoucherStatus.ACTIVE
        nullable: true
    })
    status: string;

    @Column({ nullable: true })
    timeStamp: Date;

    @CreateDateColumn()
    createdAt: Date

    @UpdateDateColumn()
    updatedAt: Date

    @VersionColumn()
    version: number
}

