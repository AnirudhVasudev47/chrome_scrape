import { Module } from '@nestjs/common';
import { EmailService } from './email.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Email } from './email.entity';
import { LoggerModule } from 'src/utility/logger/logger.module';

@Module({
  imports: [
    LoggerModule,
    TypeOrmModule.forFeature([Email])
  ],
  controllers: [],
  providers: [EmailService]
})
export class EmailModule { }
