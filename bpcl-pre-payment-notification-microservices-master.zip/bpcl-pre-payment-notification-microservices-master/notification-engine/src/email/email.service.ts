import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import * as config from 'config';
import { NotificationResponseDto } from '../notification/dto/notification-response.dto';
import { EmailRequest } from './dto/email-request.dto';
import { logMessage } from "../utility/log-message/log-message";
import { EmailRepository } from './email.repository';
import { LoggerService } from '../utility/logger/logger.service';
import * as moment from 'moment';
import { EmailStatus } from './email.entity';
import { RpcException } from '@nestjs/microservices';
import { v4 as uuidv4 } from 'uuid';
import axios from 'axios';

const emailConfig = config.get('email');
const nodemailer = require("nodemailer");
const { google } = require("googleapis");
const OAuth2 = google.auth.OAuth2;

@Injectable()
export class EmailService {

    private readonly logger = new LoggerService(EmailService.name);

    constructor(
        @InjectRepository(EmailRepository) private readonly emailRepository: EmailRepository,
    ) { }

    /**
    * Save email details in db
    * @param emailRequestDto
    * @returns Promise<number>
    */
    async saveEmail(emailRequestDto: EmailRequest): Promise<string> {
        //step 1--save email details in db
        try {
            emailRequestDto.id = emailRequestDto.uid = uuidv4();
            const data = await this.emailRepository.save(emailRequestDto);
            let id = data.id;
            return id;
        } catch (error) {
            this.logger.debug(`${logMessage.SAVE_EMAIL_FAILED} ${emailRequestDto.receiverMail} `);
            throw new RpcException(`${logMessage.SAVE_EMAIL_FAILED}`);
        }
    }

    /**
    * send email to customer
    * @param emailRequestDto
    * @param id
    * @returns Promise<NotificationResponseDto>
    */
    async sendEmail(emailRequestDto: EmailRequest, id: string): Promise<void> {
        try {
            //step 2--setup email content and send email to customer
            const { clientId, clientSecret, url, refreshToken, service, type, user } = emailConfig;
            const { receiverMail, subject, content } = emailRequestDto;

            //setup OAuth client
            const oauth2Client = new OAuth2(clientId, clientSecret, url);

            //provide refresh token to get new access token
            oauth2Client.setCredentials({ refresh_token: refreshToken });
            const accessToken = oauth2Client.getAccessToken();

            //configuring how to send the email using SMTP and Nodemailer
            const smtpTransport = nodemailer.createTransport({
                service: service,
                auth: {
                    type: type,
                    user: `${user}`,
                    clientId: clientId,
                    clientSecret: clientSecret,
                    refreshToken: refreshToken,
                    accessToken: accessToken
                }
            });

            //setting up email content
            const mailOptions = {
                from: `${user}`,
                to: `${receiverMail}`,
                subject: `${subject}`,
                html: `${content}`
            };

            //send email to customer
            const res = await smtpTransport.sendMail(mailOptions);
            if (res) {
                this.logger.verbose(`${logMessage.EMAIL_SENT_SUCCESSFULLY} ${emailRequestDto.receiverMail}`);
                res.timeStamp = moment.utc().toDate()
                res.status = EmailStatus.SUCCESS;
                await this.updateEmail(res, id);//update email status in db
            }
        }
        catch (error) {
            this.logger.debug(`${logMessage.FAILED_TO_SEND_SMS_NOTIFICATION} ${emailRequestDto.receiverMail}`);
            throw new RpcException(`${logMessage.FAILED_TO_SEND_SMS_NOTIFICATION}`);
        }
    }

    /**
    * send email to customer 
    * @param emailRequestDto
    * @param id
    * @returns Promise<NotificationResponseDto>
    */
    async sendEmailByYellowMessenger(emailRequestDto: EmailRequest, id: string): Promise<void> {
        try {
            const { url, apiToken } = emailConfig;
            const { receiverMail, subject, content } = emailRequestDto;
            // 1.send email to user
            const response: any = await axios.post(url, {
                apiToken: apiToken,
                userId: receiverMail,
                content: content,
                subject: subject
            })

            // 2. send response
            let emailResponse;
            if (response.data.success) { // if email sent successfully
                this.logger.verbose(`${logMessage.EMAIL_SENT_SUCCESSFULLY} ${emailRequestDto.receiverMail}`);
                let res = new NotificationResponseDto();
                res.status = EmailStatus.SUCCESS;
                res.timeStamp = moment.utc().toDate()
                emailResponse = await this.updateEmail(res, id);
            } else { // if email not sent
                this.logger.debug(`${logMessage.FAILED_TO_SEND_SMS_NOTIFICATION} ${emailRequestDto.receiverMail}`);
                let res = new NotificationResponseDto();
                res.status = EmailStatus.FAIL;
                res.timeStamp = moment.utc().toDate()
                emailResponse = await this.updateEmail(res, id);
            }
            return emailResponse;
        }
        catch (error) {
            this.logger.debug(`${logMessage.FAILED_TO_SEND_SMS_NOTIFICATION} ${emailRequestDto.receiverMail}`);
            throw new RpcException(`${logMessage.FAILED_TO_SEND_SMS_NOTIFICATION}`);
        }
    }



    /**
    * update email status in db
    * @param emailResponse
    * @param id
    * @returns Promise<EmailResponseDto>
    */
    async updateEmail(emailResponse: NotificationResponseDto, id: string): Promise<void> {
        try {
            // //step 3--update the email status in db
            const { status, timeStamp } = emailResponse;
            const email = await this.emailRepository.findOne(id);
            email.status = status;
            email.timeStamp = timeStamp;
            email.senderMail = emailConfig.user;

            //updating in db
            await this.emailRepository.save(email);
            this.logger.verbose(`${logMessage.UPDATED_EMAIL_STATUS} ${id}`);

            //fetching email status response
            const res = await this.emailRepository.findOne(id);

            //sending response back 
            // const emailRes = new NotificationResponseDto();
            // emailRes.status = res.status;
            // emailRes.timeStamp = res.timeStamp;
            // return emailRes;
        }
        catch (error) {
            this.logger.debug(`${logMessage.UPDATE_EMAIL_FAILED} ${id}`);
            throw new RpcException(`${logMessage.UPDATE_EMAIL_FAILED}`);
        }
    }
}
