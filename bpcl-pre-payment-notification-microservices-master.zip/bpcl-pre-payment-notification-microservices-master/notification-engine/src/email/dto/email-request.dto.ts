// import { IsString, IsEmail, IsNumber, IsBoolean } from 'class-validator';

// export class EmailRequestDto {
//     @IsEmail()
//     receiverMail: string;

//     @IsString()
//     subject: string;

//     @IsString()
//     content: string;

//     @IsString()
//     generateTextFromHtml: string;

//     @IsNumber()
//     channel: number;

//     @IsString()
//     extra: string;
// }

export class EmailRequest {
    id: string;
    uid: string;
    receiverMail: string;
    subject: string;
    content: string;
    generateTextFromHtml: string;
    channel: number;
    extra: string;
}

export class EmailRequestDto {
    emailRequest: EmailRequest[];
}

