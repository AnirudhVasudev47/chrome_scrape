import { Test, TestingModule } from '@nestjs/testing';
import { EmailService } from './email.service';
import { EmailRepository } from './email.repository';
import { LoggerService } from '../utility/logger/logger.service';
// const { google } = require("googleapis");
// const OAuth2 = google.auth.OAuth2 = () => {
//   setCredentials: jest.fn()
// };

const mockEmailRepo = () => ({
  save: jest.fn(),
  sendingEmail: jest.fn(),
  saveEmailInDb: jest.fn(),
  updateDatabase: jest.fn(),
  findOne: jest.fn()
});

const mockLogger = () => ({
  error: jest.fn(),
  setContext: jest.fn(),
  verbose: jest.fn()
});


describe('EmailService', () => {
  let emailService;
  let emailRepo;
  let logger;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        EmailService,
        { provide: EmailRepository, useFactory: mockEmailRepo },
        { provide: LoggerService, useFactory: mockLogger },
      ],
    }).compile();

    emailService = await module.get<EmailService>(EmailService);
    emailRepo = await module.get<EmailRepository>(EmailRepository);
    logger = await module.get<LoggerService>(LoggerService);
  });

  describe('save email details in db', () => {
    let emailResponse;
    let emailDto;

    beforeEach(() => {
      emailResponse = { id: 123, receiverMail: 'test@gmail.com', subject: 'Test', content: 'test message' };
      emailDto = { to: 'test@gmail.com', subject: 'Test', content: 'test message' };
    });

    it('successfully saves email details in db', async () => {
      emailRepo.save.mockResolvedValue(emailResponse);
      expect(emailRepo.save).not.toHaveBeenCalled();

      let result = await emailService.saveEmailInDb(emailDto);

      expect(emailRepo.save).toHaveBeenCalled();
      expect(emailRepo.save).toHaveBeenCalledWith(emailDto);
      expect(result).toEqual(123);
    });
  });

  describe('updateDatabase with email status', () => {
    let emailDetailDto;
    let emailResponse;

    beforeEach(() => {
      emailResponse = { status: 'success', timeStamp: new Date() };
      emailDetailDto = {
        id: 123,
        senderMail: 'admin@gmail.com',
        receiverMail: 'test@gmail.com',
        subject: 'Test',
        content: 'test message'
      }
    });

    it('updates email status', async () => {
      emailRepo.findOne.mockResolvedValue(emailDetailDto);
      expect(emailRepo.findOne).not.toHaveBeenCalled();
      const result = await emailService.updateDatabase(emailResponse, 123);
      expect(emailRepo.findOne).toHaveBeenCalledTimes(2);
      expect(emailRepo.findOne).toHaveBeenCalledWith(123);
      expect(emailRepo.save).toHaveBeenCalled();
      expect(result).toEqual(emailResponse);
    });

    it('throws error as email is not found', async () => {
      emailRepo.findOne.mockResolvedValue(null);
      expect(emailService.updateDatabase(emailResponse, 123)).rejects.toThrow();
    })
  });

  describe('testing smtp mailer', () => {
    let emailResponse;

    beforeEach(() => {
      emailResponse = { status: 'success', timeStamp: new Date() };
      emailService.updateDatabase = jest.fn().mockResolvedValue({
        status: 'success', timeStamp: new Date()
      });

      //google.auth.OAuth2.jest.fn();
    });

    it('successfully sends email', async () => {
      const result = await emailService.sendingEmail(emailResponse, 123);
    });
  });

});
