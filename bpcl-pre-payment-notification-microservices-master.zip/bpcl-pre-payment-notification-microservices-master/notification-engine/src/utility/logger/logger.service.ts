import * as winston from "winston";
import * as path from 'path';

export class LoggerService {

  private logger: winston.Logger;


  constructor(private context: string) {
    const consoleFormat = winston.format.combine(
      winston.format.colorize({ all: true }),
      // winston.format.timestamp({ format: 'DD/MM/YYYY HH:MM:SS' }),
      winston.format.timestamp(),
      winston.format.printf(info => `[${info.level}] ${info.timestamp} [${info.context}] ${info.message}`)
    );


    this.logger = winston.createLogger({
      level: 'info',
      format: winston.format.combine(
        winston.format.json(),
        // winston.format.prettyPrint()
      ),
      defaultMeta: { microservice: 'Notification Engine' }, //We can provide other info as Container ID, IP Address etc
      transports: [

        // new winston.transports.File({
        //   dirname: path.join(__dirname, '../../../log'),
        //   filename: 'prod.log',
        //   level: 'warn',
        //   // maxsize: 500 //Defines the max size of log file in bytes
        // }),

        new winston.transports.Console({
          format: consoleFormat,
          level: 'debug'
        }),

        new winston.transports.File({
          dirname: path.join(__dirname, '../../../log'),
          filename: 'dev.log',
          level: 'debug',
          // maxsize: 500 //Defines the max size of log file in bytes
        }),
      ]
    });

  }

  setContext(context: string){
    this.context = context;
  }

  log(message: string) {
    const currentDate = new Date();
    this.logger.info(message, {
      timestamp: currentDate.toISOString(),
      context: this.context
    });
  }

  error(message: string, trace?: string) {
    const currentDate = new Date();
    this.logger.error(`${message} -> (${trace || 'trace not provided !'})`, {
      timestamp: currentDate.toISOString(),
      context: this.context,
    });
  }
  warn(message: string) {
    const currentDate = new Date();
    this.logger.warn(message, {
      timestamp: currentDate.toISOString(),
      context: this.context,
    });
  }
  debug(message: string) {
    const currentDate = new Date();
    this.logger.debug(message, {
      timestamp: currentDate.toISOString(),
      context: this.context
    });
  }
  verbose(message: string) {
    const currentDate = new Date();
    this.logger.verbose(message, {
      timestamp: currentDate.toISOString(),
      context: this.context
    });
  }

}

