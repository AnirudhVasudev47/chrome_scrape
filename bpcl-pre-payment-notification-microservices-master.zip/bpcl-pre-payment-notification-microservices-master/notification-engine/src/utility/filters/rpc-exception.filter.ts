import { Catch, RpcExceptionFilter, ArgumentsHost } from '@nestjs/common';
import { Observable, throwError } from 'rxjs';
import { RpcException } from '@nestjs/microservices';
import { LoggerService } from 'src/utility/logger/logger.service';
import { logMessage as BusinessErrors } from '../log-message/log-message';

@Catch(RpcException)
export class GrpcExceptionFilter implements RpcExceptionFilter<RpcException> {

  private readonly logger: LoggerService = new LoggerService(GrpcExceptionFilter.name);

  catch(exception: RpcException, host: ArgumentsHost): Observable<any> {

    const err = exception.getError();

    // If an unfamiliar error occurs / not a business error
    if (Object.values(BusinessErrors).includes(err.toString()) == false) {
      this.logger.error(JSON.stringify(exception.getError()), exception.stack);
    }
    return throwError(exception.getError());
  }
}