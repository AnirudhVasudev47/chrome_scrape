export const logMessage = {
    "APP_RUNNING": "Application running on port",
    "API_LOG": "Route: {path}, Method: {method}",
    "EMAIL_NOTIFICATION_RECEIVED": "Send email notification to customer received",
    "FAILED_TO_SEND_EMAIL_NOTIFICATION": "Failed to send email notification to customer",
    "SAVE_EMAIL_FAILED": "Failed to save email details",
    "EMAIL_SENT_SUCCESSFULLY": "Email sent successfully to the customer",
    "UPDATED_EMAIL_STATUS": "Email status updated successfully",
    "UPDATE_EMAIL_FAILED": "Failed to update the email status",
    "SMS_NOTIFICATION_RECEIVED": "Send sms notification to customer received",
    "FAILED_TO_SEND_SMS_NOTIFICATION": "Failed to send sms notification to customer",
    "SAVE_SMS_FAILED": "Failed to save sms details",
    "UPDATE_SMS_FAILED": "Failed to update the sms status",
    "SMS_SENT_SUCCESSFULLY": "SMS sent successfully to the customer",
    "UPDATED_SMS_STATUS": "SMS status updated successfully",
    "EMAIL_DETAILS_NOT_FOUND": "Email details with specific id not found"
}