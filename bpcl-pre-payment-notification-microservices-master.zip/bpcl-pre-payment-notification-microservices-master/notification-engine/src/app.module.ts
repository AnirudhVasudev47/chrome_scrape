import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { SmsModule } from './sms/sms.module';
import { EmailModule } from './email/email.module';
import { typeOrmConfig } from './config/typeorm.config';
import { I18nModule, I18nJsonParser } from 'nestjs-i18n';
import { NotificationModule } from './notification/notification.module';
import { LoggerModule } from './utility/logger/logger.module';

@Module({
  imports: [
    TypeOrmModule.forRoot(typeOrmConfig),
    SmsModule,
    EmailModule,
    NotificationModule,
    LoggerModule
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule { }
