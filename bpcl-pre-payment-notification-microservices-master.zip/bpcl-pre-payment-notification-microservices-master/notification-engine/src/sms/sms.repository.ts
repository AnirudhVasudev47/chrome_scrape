import { Repository, EntityRepository } from "typeorm";
import { Sms } from "./sms.entity";

@EntityRepository(Sms)
export class SmsRepository extends Repository<Sms>{

}