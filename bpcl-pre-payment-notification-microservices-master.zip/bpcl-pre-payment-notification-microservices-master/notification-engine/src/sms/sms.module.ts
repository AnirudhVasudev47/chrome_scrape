import { Module, HttpModule } from '@nestjs/common';
import { SmsService } from './sms.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Sms } from './sms.entity';
import { LoggerModule } from 'src/utility/logger/logger.module';

@Module({
  imports: [
    LoggerModule,
    TypeOrmModule.forFeature([Sms]),
    HttpModule.register({
      timeout: 5000,
      maxRedirects: 3,
    })
  ],
  controllers: [],
  providers: [SmsService]
})
export class SmsModule { }
