import { PrimaryGeneratedColumn, Column, Entity, CreateDateColumn, UpdateDateColumn, VersionColumn, PrimaryColumn } from "typeorm";

export enum SmsStatus {
    SUCCESS = "SUCCESS",
    FAIL = "FAIL",
}

@Entity('sms')
export class Sms {
    @PrimaryGeneratedColumn("uuid")
    id: string;

    // @PrimaryColumn()
    @Column()
    uid: string; // id

    //Type of sms whether text or utf (text/unicode)
    // @Column({ nullable: true })
    // messageType: string;

    @Column({ nullable: true })
    mobileNumber: string;

    //6-digit apha sender id for transactional sms
    // @Column({ nullable: true })
    // senderId: string;

    @Column({
        type: 'enum',
        enum: SmsStatus,
        // default: VoucherStatus.ACTIVE
        nullable: true
    })
    status: string;

    @Column({ nullable: true })
    timeStamp: Date;

    @CreateDateColumn()
    createdAt: Date

    @UpdateDateColumn()
    updatedAt: Date

    @VersionColumn()
    version: number
}