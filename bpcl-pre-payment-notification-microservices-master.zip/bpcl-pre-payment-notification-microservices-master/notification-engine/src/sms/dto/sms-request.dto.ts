import { IsString, MaxLength, IsNumber } from 'class-validator';

export class SmsRequestDto {
    @IsString()
    id: string;

    @IsString()
    uid: string;

    @IsString()
    mobileNumber: string;

    @IsString()
    msg: string;

    @IsNumber()
    channel: number;

    // @IsString()
    // messageType: string;

    // @IsString()
    // qrCode: string;

    // @IsString()
    // extra: string
}
