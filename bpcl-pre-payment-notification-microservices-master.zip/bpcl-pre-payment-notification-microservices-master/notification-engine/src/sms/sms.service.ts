import { Injectable, HttpService } from '@nestjs/common';
import * as config from 'config';
import { SmsStatus } from './sms.entity';
import { SmsRequestDto } from './dto/sms-request.dto';
import { logMessage } from 'src/utility/log-message/log-message';
import { NotificationResponseDto } from 'src/notification/dto/notification-response.dto';
import { SmsRepository } from './sms.repository';
import * as moment from 'moment';
import { RpcException } from '@nestjs/microservices';
import { v4 as uuidv4 } from 'uuid';
import { LoggerService } from 'src/utility/logger/logger.service';
import axios from 'axios';

const smsConfig = config.get('sms');

@Injectable()
export class SmsService {

    private logger = new LoggerService(SmsService.name);
    constructor(
        private http: HttpService,
        private readonly smsRepository: SmsRepository,
    ) { }

    /**
    * Save sms details in db
    * @param NotificationRequestDto
    * @returns Promise<number>
    */
    async saveSms(smsRequestDto: SmsRequestDto): Promise<string> {
        //step 1--save sms details in db
        try {
            smsRequestDto.id = smsRequestDto.uid = uuidv4();
            const data = await this.smsRepository.save(smsRequestDto);
            let id = data.id;
            return id;
        } catch (error) {
            this.logger.debug(`${logMessage.SAVE_SMS_FAILED} ${smsRequestDto.mobileNumber} ${error}`);
            throw new RpcException(`${logMessage.SAVE_SMS_FAILED}`);
        }
    }

    /** 
    * Send sms to customer
    * @param NotificationRequestDto
    * @returns Promise<NotificationResponseDto>
    */
    async sendSms(smsRequestDto: SmsRequestDto, id: string): Promise<NotificationResponseDto> {
        //step 2--send sms to customer using sms gateway
        const { mobileNumber, msg } = smsRequestDto;
        const { url, username, password, senderId } = smsConfig;
        try {
            //sms gateway url
            const gatewayUrl = `${url}?username=${username}&password=${password}&mobile=${mobileNumber}&senderId=${senderId}&message=${msg}`;
            const response = await this.http.get(gatewayUrl).toPromise();

            let smsResponse;
            if (response.data) {
                this.logger.verbose(`${logMessage.SMS_SENT_SUCCESSFULLY} ${smsRequestDto.mobileNumber}`);
                let res = new NotificationResponseDto();
                res.status = SmsStatus.SUCCESS;
                res.timeStamp = moment.utc().toDate()
                smsResponse = await this.updateSms(res, id);
            }
            return smsResponse;
        } catch (error) {
            this.logger.debug(`${logMessage.FAILED_TO_SEND_SMS_NOTIFICATION} ${smsRequestDto.mobileNumber} ${error}`);
            throw new RpcException(`${logMessage.FAILED_TO_SEND_SMS_NOTIFICATION}`);
        }
    }

    /** 
    * Send sms to customer by yellow messenger
    * @param NotificationRequestDto
    * @returns Promise<NotificationResponseDto>
    */
    async sendSmsByYellowMessenger(smsRequestDto: SmsRequestDto, id: string): Promise<NotificationResponseDto> {
        const { mobileNumber, msg } = smsRequestDto;
        const { url, apiToken } = smsConfig;
        try {
            // 1.send sms to customer
            const gatewayUrl = `${url}`;
            const response: any = await axios.post(gatewayUrl, {
                apiToken: apiToken,
                userId: mobileNumber,
                content: msg,
            })

            // 2. send response
            let smsResponse;
            if (response.data.success) { // if sms sent successfully
                this.logger.verbose(`${logMessage.SMS_SENT_SUCCESSFULLY} ${smsRequestDto.mobileNumber}`);
                let res = new NotificationResponseDto();
                res.status = SmsStatus.SUCCESS;
                res.timeStamp = moment.utc().toDate()
                smsResponse = await this.updateSms(res, id);
            } else { // if sms not sent
                this.logger.verbose(`${logMessage.FAILED_TO_SEND_SMS_NOTIFICATION} ${smsRequestDto.mobileNumber}`);
                let res = new NotificationResponseDto();
                res.status = SmsStatus.FAIL;
                res.timeStamp = moment.utc().toDate()
                smsResponse = await this.updateSms(res, id);
            }
            return smsResponse;
        } catch (error) {
            this.logger.debug(`${logMessage.FAILED_TO_SEND_SMS_NOTIFICATION} ${smsRequestDto.mobileNumber} ${error}`);
            throw new RpcException(`${logMessage.FAILED_TO_SEND_SMS_NOTIFICATION}`);
        }
    }

    /**
    * update sms status in db
    * @param NotificationResponseDto
    * @param id
    * @returns Promise<NotificationResponseDto>
    */
    async updateSms(smsResponse: NotificationResponseDto, id: string): Promise<NotificationResponseDto> {
        try {
            //step 3--update the sms status in db
            const { status, timeStamp } = smsResponse;
            const sms = await this.smsRepository.findOne(id);
            sms.status = status;
            sms.timeStamp = timeStamp;

            //updating in db
            await this.smsRepository.save(sms);
            this.logger.verbose(`${logMessage.UPDATED_SMS_STATUS} ${id}`);

            //fetching updated sms status
            const res = await this.smsRepository.findOne(id);

            //sending response back 
            const smsRes = new NotificationResponseDto();
            smsRes.status = res.status;
            smsRes.timeStamp = res.timeStamp;

            return smsRes;
        }
        catch (error) {
            this.logger.debug(`${logMessage.UPDATE_SMS_FAILED} ${id} ${error}`);
            throw new RpcException(`${logMessage.UPDATE_SMS_FAILED}`);
        }
    }
}
