import {Strapi} from '@strapi/strapi';
import {scheduleNotification} from './api/primaryuser/services/lifecycle'

export default {
	register(/*{ strapi }*/) {
	},
	bootstrap({strapi}) {
		strapi.db.lifecycles.subscribe(async (event) => {
			if (event.action === 'afterCreate') {
				// console.log('event: ', event);
				if (event.model.uid === 'api::primaryuser.primaryuser') {
					await scheduleNotification(event.result);
				}
			}
		})
	},
};
