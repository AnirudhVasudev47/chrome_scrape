export enum SolarCategorySapDivisionCode {
  SOLAR_WATER_HEATER_CODE = "06", // Solar Water Heater
  SOLAR_POWER_SYSTEM_CODE = "26", // Solar Power System
}

export enum SolarCategory {
  SOLAR_WATER_HEATER = "Solar water heater",
  SOLAR_POWER_SYSTEM = "Solar power system",
}
