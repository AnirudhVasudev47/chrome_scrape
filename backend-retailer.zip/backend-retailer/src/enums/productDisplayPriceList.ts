export enum ProductAndPriceListContentType {
  PRODUCT_TRAINING = "Product training",
  PRODUCT_FLYER = "Product flyer",
  PRODUCT_SCHEME = "Product scheme",
  PRODUCT_BROCHURE = "Product brochure",
  PRODUCT_DEMO = "Product demo",
  PRODUCT_AD = "Product Ad",
  PRODUCT_PRICE_LIST_BOOK = "Product price list book",
}
