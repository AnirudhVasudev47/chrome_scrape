export enum UserType {
  PRIMARY = "Primary",
  SECONDARY = "Secondary",
}

export enum UserRole {
  PRIMARY_USER = "Primary user",
  SECONDARY_USER = "Secondary user",
}

export enum UserActivationStatusEnum {
  NOT_YET_INVITED = "Not yet invited",
  INVITATION_TRIGGERED = "Invitation triggered",
  INVITATION_SENT = "Invitation sent",
  LOGGED_IN = "Logged in",
  FIRST_SCAN_COMPLETED = "First scan completed",
}
