export enum OTPPurposeEnum {
  LOGIN = "LOGIN",
}
