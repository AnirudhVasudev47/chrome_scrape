// import { UserType } from "../enums";
// const uuuu = require("../enums");

module.exports = (config, { strapi }) => {
  return async (ctx, next) => {
    try {
      await processToken(ctx, strapi);
    } catch (error) {}
    await next();
  };
};

async function processToken(ctx, strapi) {
  const authorizationHeader = ctx.request.header.authorization;
  if (!authorizationHeader || !authorizationHeader.startsWith("Bearer ")) {
    return; // If no Authorization header or it's not a Bearer token, skip
  }
  const token = authorizationHeader.split(" ")[1];
  const { id } = await strapi.plugins["users-permissions"].services.jwt.verify(
    token
  );
  if (id) {
    await fetchUser(ctx, strapi, id);
  }
}

async function fetchUser(ctx, strapi, userId) {
  const primaryUser = await strapi.db
    .query("api::primaryuser.primaryuser")
    .findOne({
      where: { userId },
    });
  if (!primaryUser) {
    const secondaryUser = await strapi.db
      .query("api::secondaryuser.secondaryuser")
      .findOne({
        where: { userId },
      });
    ctx.state.userType = "Secondary";
    ctx.state.loggedInUser = secondaryUser;
  } else {
    ctx.state.userType = "Primary";
    ctx.state.loggedInUser = primaryUser;
  }
}
