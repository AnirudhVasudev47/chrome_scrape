export class PaginationDto {
  page: number;
  pageSize?: number;
  pageCount?: number;
  total?: number;
}
