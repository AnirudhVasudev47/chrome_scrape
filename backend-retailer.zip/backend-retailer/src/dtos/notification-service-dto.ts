export class sendInviteLinkRequest {
    name: string;
    mobileNumber: number;
}

export class sendInviteLinkRequestDto {
    details: sendInviteLinkRequest[];
}

export class sendOtpRequest {
    mobileNumber: number;
    otp: number;
}