import { LeadTypeEnum } from "../enums";
import { PaginationDto } from "./pagination-dto";

export class CreateLeadRequestDto {
  name: string;
  email: string;
  mobileNumber: string;
  categoryId: string;
  subCategoryId: string;
  leadType: LeadTypeEnum;
  pincode: string;
  district: string;
  salesOffice: string;
  state: string;
  zone: string;
  country: string;
}

export class FetchLeadsRequestDto {
  pagination: {
    page: number;
    pageSize?: number;
  };
  filters: {
    categoryIds?: string[];
    leadType?: LeadTypeEnum[];
  };
}

export class LeadDto {
  id: number;
  leadCode: string;
  leadId: string;
  createdAt: Date;
  updatedAt: Date;
  publishedAt: Date;
  name: string;
  email: string;
  mobileNumber: string;
  leadType: LeadTypeEnum;
  leadTypeId: string | null;
  pincode: string;
  district: string;
  salesOffice: string;
  state: string;
  zone: string;
  country: string;
  leadCategory: {
    categoryName: string;
  };
  leadSubCategory?: {
    categoryName: string;
  };
}

export class FetchLeadsResponseDto {
  data: LeadDto[];
  meta: {
    pagination: PaginationDto;
    filters: {
      categoryIds?: string[];
      leadType?: LeadTypeEnum;
    };
  };
}

export class FetchLeadDetailsResponseDto {
  data: LeadDto;
}

export class FetchAssignedLeadsRequestDto {
  pagination: {
    page: number;
    pageSize?: number;
  };
  filters: {
    status?: string[];
    subStatus?: string[];
  };
}

export class FetchAssignedLeadsResponseDto {
  data: LeadDto[];
  meta: {
    pagination: PaginationDto;
    filters: {
      status?: string[];
      subStatus?: string[];
    };
  };
}
