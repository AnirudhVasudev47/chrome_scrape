import { PaginationDto } from "./pagination-dto";

export class DateDto{
    fromDate: string;
    toDate: string;
}

export class FetchTicketHistoryRequestDto {
    pagination: {
        page: number;
        pageSize?: number;
    };
    filters: {
        type: string[];
        contentType?: string;
        ticketStatus?: string[];
        customDate?: DateDto;
    };
}

export class FetchTicketHistoryResponseDto {
    data: TicketHistoryDto[];
    meta: {
      pagination: PaginationDto;
      filters: {
        type: string[];
        contentType?: string;
        ticketStatus?: string[];
        customDate?: DateDto;    
      };
    };
  }

export class TicketHistoryDto {
    ticketCreatedDate: string;
    ticketStatus: string;
    ticketId: string;
    supportType: string;
    subType: string;
    remarks: string;
    productCategory: string;

}

export class raiseTicketRequestDto {
    supportType: string;
    subType: string;
    productCategory: string[]; // Accept an array of strings for productCategory
    marketMaterialType: string;
    comments: string;
  }