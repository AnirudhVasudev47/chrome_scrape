import { PaginationDto } from "./pagination-dto";


export class SecondarySchemeDto {
  id: number;
  secondarySchemeId: string;
  schemeName: string;
  startDate: Date;
  endDate: Date;
  schemeType: string;
}

export class FetchAllSecondarySchemesRequestDto {
    pagination: {
      page: number;
      pageSize?: number;
    };
    filters: {
        schemeStatus?: string;
        customDate?: DateDto;
        categoryIds?: string[];
        schemeNameIds: string[];
    };
  }

export class DateDto{
    fromDate: string;
    toDate: string;
}

export class SchemeDetailsDto {
  categoryId: string;
  skuProduct: string;
}

export class FetchAllSecondarySchemesResponseDto {
  category: string;
  categoryId: string;
  schemes: SecondarySchemeDto[];
}

export class FetchSecondarySchemesResponseDto {
  data: FetchAllSecondarySchemesResponseDto[];
  meta: {
    pagination: PaginationDto;
    filters: {
      schemeStatus?: string;
        customDate?: DateDto;
        categoryIds?: string[];
        schemeNameIds: string[];      
    };
  };
}

  export class SecondarySchemeResponse{
    totalSchemes: number;
    output: FetchAllSecondarySchemesResponseDto[];
}