export default {
  birthdayMessage({name, points}) {
    return {
      icon: `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAABYlAAAWJQFJUiTwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAIdSURBVHgB7ZfhTcMwEIWfEP+BDW4D2ABvQEbwBmQDugEwAWWCdoOGCdoN2g3aDSCnnBW3tRs7PatI8EmWC2cnL77z+Qz8QWZtW+IXs2nbd9sMFLiCPnPpH6BACYEr6e+hQAmBO+nvoEBJgbdQoIRAJ2wXsHFcrttmI3Prtm3RbbJXFGIiL3gL2KzYPgI2EpvfbIkVfJS+CdhOuZ2k5032Kb+zMwENTGK7+3oK2KdiqwM2Fr/F/gpWSKQKTA7FyIPYGuSLd2MadLm0RiK192AWufL+5iPt0G1VRECFePyNhtDtOn7wJPL/kMgYKqeLj8Vpl40RqcpCBNiInXBBkYQ+7obGXUTkG9KDmnABke6FJnE8IV0k26w0gxEfZORF67xpySLdmKG8GmWK49SiKZLDZy7vadCLTFpJ/8ghjIOQF5M83iARi3juy4FQaOMM5b4cCMoiCZnxkPhMJ3KGM3GFQUruy4HQx7XBGeTmvhwmiFfaUfyK2qD70g3O3yAh3B3lBhn4Aq30DcrwJP0XRuLcS9DFoNsc7mQijMCiTwUacAZ4QZ+yXFU0umDVyH0syhyIcsJ4YxBGQhi+zJzCiIDDS1UDpWxg5YHzjDnOhcuAqBqKx9o19i/MQ6JM256xvzKcPt5FXIMCWHRfv4jYDY5duIWiC4fwyysuGnmnEToXHhaWDZRdmEqF4wrXX60JCtxpcyF0Fe5GGv82+Oc0P5sMzoO6ZQWuAAAAAElFTkSuQmCC`,
      title: 'Birthday',
      tag: 'Special events',
      message: `Dear Partner ${name}, wishing you a very happy birthday. Here is ${points} additional points as a gift for your birthday.`
    }
  },
  anniversaryMessage({name, points}) {
    return {
      icon: `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAABYlAAAWJQFJUiTwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAIdSURBVHgB7ZfhTcMwEIWfEP+BDW4D2ABvQEbwBmQDugEwAWWCdoOGCdoN2g3aDSCnnBW3tRs7PatI8EmWC2cnL77z+Qz8QWZtW+IXs2nbd9sMFLiCPnPpH6BACYEr6e+hQAmBO+nvoEBJgbdQoIRAJ2wXsHFcrttmI3Prtm3RbbJXFGIiL3gL2KzYPgI2EpvfbIkVfJS+CdhOuZ2k5032Kb+zMwENTGK7+3oK2KdiqwM2Fr/F/gpWSKQKTA7FyIPYGuSLd2MadLm0RiK192AWufL+5iPt0G1VRECFePyNhtDtOn7wJPL/kMgYKqeLj8Vpl40RqcpCBNiInXBBkYQ+7obGXUTkG9KDmnABke6FJnE8IV0k26w0gxEfZORF67xpySLdmKG8GmWK49SiKZLDZy7vadCLTFpJ/8ghjIOQF5M83iARi3juy4FQaOMM5b4cCMoiCZnxkPhMJ3KGM3GFQUruy4HQx7XBGeTmvhwmiFfaUfyK2qD70g3O3yAh3B3lBhn4Aq30DcrwJP0XRuLcS9DFoNsc7mQijMCiTwUacAZ4QZ+yXFU0umDVyH0syhyIcsJ4YxBGQhi+zJzCiIDDS1UDpWxg5YHzjDnOhcuAqBqKx9o19i/MQ6JM256xvzKcPt5FXIMCWHRfv4jYDY5duIWiC4fwyysuGnmnEToXHhaWDZRdmEqF4wrXX60JCtxpcyF0Fe5GGv82+Oc0P5sMzoO6ZQWuAAAAAElFTkSuQmCC`,
      title: 'Wedding Anniversary',
      tag: 'Special events',
      message: `Dear Partner ${name}, wishing you a very happy wedding anniversary. Here is ${points} additional points as a gift for your wedding anniversary.`
    }
  },
  storeAnniversaryMessage({name, points}) {
    return {
      icon: `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAABYlAAAWJQFJUiTwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAIdSURBVHgB7ZfhTcMwEIWfEP+BDW4D2ABvQEbwBmQDugEwAWWCdoOGCdoN2g3aDSCnnBW3tRs7PatI8EmWC2cnL77z+Qz8QWZtW+IXs2nbd9sMFLiCPnPpH6BACYEr6e+hQAmBO+nvoEBJgbdQoIRAJ2wXsHFcrttmI3Prtm3RbbJXFGIiL3gL2KzYPgI2EpvfbIkVfJS+CdhOuZ2k5032Kb+zMwENTGK7+3oK2KdiqwM2Fr/F/gpWSKQKTA7FyIPYGuSLd2MadLm0RiK192AWufL+5iPt0G1VRECFePyNhtDtOn7wJPL/kMgYKqeLj8Vpl40RqcpCBNiInXBBkYQ+7obGXUTkG9KDmnABke6FJnE8IV0k26w0gxEfZORF67xpySLdmKG8GmWK49SiKZLDZy7vadCLTFpJ/8ghjIOQF5M83iARi3juy4FQaOMM5b4cCMoiCZnxkPhMJ3KGM3GFQUruy4HQx7XBGeTmvhwmiFfaUfyK2qD70g3O3yAh3B3lBhn4Aq30DcrwJP0XRuLcS9DFoNsc7mQijMCiTwUacAZ4QZ+yXFU0umDVyH0syhyIcsJ4YxBGQhi+zJzCiIDDS1UDpWxg5YHzjDnOhcuAqBqKx9o19i/MQ6JM256xvzKcPt5FXIMCWHRfv4jYDY5duIWiC4fwyysuGnmnEToXHhaWDZRdmEqF4wrXX60JCtxpcyF0Fe5GGv82+Oc0P5sMzoO6ZQWuAAAAAElFTkSuQmCC`,
      title: 'Store Anniversary',
      tag: 'Special events',
      message: `Dear Partner ${name}, wishing you a very happy store anniversary. Here is ${points} additional points as a gift for your store anniversary.`
    }
  },
}
