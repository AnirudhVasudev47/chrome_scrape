import crypto from "crypto";

const algorithm = "aes-256-cbc";
const keyLength = 32; // Bytes for AES-256 (recommended)

// Function to generate a random key securely using a KDF
function generateRandomKey(password: string) {
  const salt = crypto.randomBytes(16); // Generate random salt
  return crypto
    .pbkdf2Sync(password, salt, 10000, keyLength, "sha512")
    .toString("hex");
}

// Function to encrypt data (consider using authenticated encryption modes for advanced protection)
export function encrypt(text: string, password: string) {
  const key = generateRandomKey(password); // Generate key using KDF and password
  const iv = crypto.randomBytes(16); // Generate random IV for each encryption

  const cipher = crypto.createCipheriv(algorithm, Buffer.from(key, "hex"), iv);
  let encrypted = cipher.update(text, "utf8", "hex");
  encrypted += cipher.final("hex");

  return {
    encrypted,
    iv: iv.toString("hex"), // Store IV in base64 or hexadecimal
    key,
  };
}

// Function to decrypt data
export function decrypt(encryptedData: string, ivString: string, key: string) {
  const iv = Buffer.from(ivString, "hex"); // Convert IV back from base64 or hexadecimal
  const decipher = crypto.createDecipheriv(
    algorithm,
    Buffer.from(key, "hex"),
    iv
  );
  let decrypted = decipher.update(encryptedData, "hex", "utf8");
  decrypted += decipher.final("utf8");

  return decrypted;
}
