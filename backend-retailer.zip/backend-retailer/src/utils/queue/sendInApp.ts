export const sendInApp = async ({date, description, icon, retailerId, tagName, title}) => {
	const id = await getTypeId(tagName, icon);

	await strapi
		.entityService
		.create("api::app-notification.app-notification", {
			data: {
				title: title,
				description: description,
				isOpened: false,
				retailerId: retailerId,
				date: new Date(),
				notificationType: id,
			}
		});
}


const getTypeId = async (tag, icon) => {
	const result = await strapi.db.query('api::notification-type.notification-type').findOne({
		where: {tag: tag},
		populate: '*',
	});
	console.log('result for notification type: ', result)
	if (result) {
		console.log(result)
		return result.data.id
	} else {
		const newResp = await strapi
			.entityService
			.create("api::notification-type.notification-type", {
				data: {
					name: tag,
					icon: icon
				}
			});

		return newResp.id
	}
}
