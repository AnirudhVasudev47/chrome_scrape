import Queue from 'bull';
import short from "short-uuid";
import {sendInApp} from './sendInApp'

const notificationInAppQueue = new Queue('notification_in_app_queue', {
	redis: {
		host: '127.0.0.1',
		port: 6379,
	}
});

const NOTIFYJOB = short.generate()

export const addToInAppQueue = (data) => {
	let cronString = getCronString(data.date, data.repeat)
	const options = {
		attempts: 3,
		repeat: {
			cron: cronString,
		},
	};

	notificationInAppQueue.add(NOTIFYJOB, data, options);
}

notificationInAppQueue.process(NOTIFYJOB, async (job) => {

	const now = new Date();
	let data = job.data
	const endDate = new Date(data.end);

	if (data.hasEnding && now > endDate) {
		console.log('ending job!!')
		await notificationInAppQueue.removeRepeatableByKey(job.opts.repeat.key);
	}

	await sendInApp(data);
})

// ------------------------------- Helper Function ------------------------------- //

const getCronString = (date, occurrence) => {

	const scheduleDate = new Date(date);

	const minute = scheduleDate.getMinutes();
	const hour = scheduleDate.getHours();
	const dayOfMonth = scheduleDate.getDate();
	const month = scheduleDate.getMonth() + 1; // getMonth() returns 0-11
	const dayOfWeek = scheduleDate.getDay(); // getDay() returns 0-6 (0 for Sunday)

	let cronString;
	switch (occurrence.toLowerCase()) {
		case 'none':
			cronString = `${minute} ${hour} ${dayOfMonth} ${month} *`;
			break;
		case 'monthly':
			cronString = `${minute} ${hour} ${dayOfMonth} * *`;
			break;
		case 'weekly':
			cronString = `${minute} ${hour} * * ${dayOfWeek}`;
			break;
		case 'daily':
			cronString = `${minute} ${hour} * * *`;
			break;
		case 'yearly':
			cronString = `${minute} ${hour} ${dayOfMonth} ${month} *`;
			break;
		default:
			throw new Error('Unsupported occurrence type');
	}

	return cronString;
}

export default {
	addToInAppQueue,
}
