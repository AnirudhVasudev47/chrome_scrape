export const modifiedStrapiResponse = (data) => {
  if (data) {
    if (
      data.length &&
      Object.keys(data[0]).length > 1 &&
      "attributes" in data[0]
    ) {
      return { data: data[0].attributes };
    }
    return { data };
  }
  return { data: null };
};

export const currentFormattedDate = () => {
  const currentDate = new Date();
  const formattedDate = currentDate.toISOString().split("T")[0];
  return formattedDate;
};
