import { mobileNumberSchema } from "./commonSchemas";
import { OTP_REGEX } from "../constants";

const { yup } = require("@strapi/utils");
const { object, number } = yup;

export const SendOTPSchema = object().shape({
  mobileNumber: mobileNumberSchema,
});

export const VerifyOTPSchema = object().shape({
  mobileNumber: mobileNumberSchema,
  otp: number()
    .required("Please enter 6 digit OTP")
    .test("is-valid-otp", "Must be a 6-digit OTP", (value) =>
      OTP_REGEX.test(value)
    ),
});
