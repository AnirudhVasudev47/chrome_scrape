import { MOBILE_NUMBER_REGEX } from "../constants";
import { yup } from "@strapi/utils";

const { number } = yup;

export const mobileNumberSchema = number()
  .required("Mobile number is required")
  .test(
    "is-indian-number",
    "Please enter a valid Indian phone number",
    (value) => {
      // Convert the number to a string for regex test
      const stringValue = String(value);

      // Validate Indian phone number using regex
      return MOBILE_NUMBER_REGEX.test(stringValue);
    }
  );
