/**
 * lead-status-history service
 */

import { factories } from "@strapi/strapi";
import { LeadStatusEnum } from "../../../enums";

export default factories.createCoreService(
  "api::lead-status-history.lead-status-history",
  ({ strapi }) => ({
    async getStatusHistoryByLeadCode(leadCode: string) {
      const leadStatusHistory = await strapi.db
        .query("api::lead-status-history.lead-status-history")
        .findMany({
          where: { leadCode, status: LeadStatusEnum.PARTNER_ASSIGNED },
          select: ["createdDate", "subStatus"],
          orderBy: { createdAt: "asc" },
        });

      return leadStatusHistory;
    },
  })
);
