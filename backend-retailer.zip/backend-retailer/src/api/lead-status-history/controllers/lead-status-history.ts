/**
 * lead-status-history controller
 */

import { factories } from '@strapi/strapi'

export default factories.createCoreController('api::lead-status-history.lead-status-history');
