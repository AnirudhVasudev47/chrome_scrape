/**
 * lead-status-history router
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::lead-status-history.lead-status-history');
