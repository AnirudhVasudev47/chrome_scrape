/**
 * localization service
 */

module.exports = {
    getLanguages: async (params) => {
      try {
        const localeValue = params.locale;
        const data = await strapi.entityService.findMany(
          "api::localization.localization",
          {
            filters: {},
            locale: localeValue,
          }
        );
        return data;
      } catch (error) {
        return error;
      }
    },
  };
  