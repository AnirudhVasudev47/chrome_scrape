/**
 * localization router
 */

export default {
    routes: [
      {
       method: 'GET',
       path: '/localization/:locale',
       handler: 'localization.getLanguages',
       config: {
         policies: [],
         middlewares: [],
       },
      },
    ],
  };
  