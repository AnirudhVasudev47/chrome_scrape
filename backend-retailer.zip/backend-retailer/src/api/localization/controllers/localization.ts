/**
 * localization controller
 */

module.exports = {
    async getLanguages(ctx, next) {
      try {
        const data = await strapi
          .service("api::localization.localization").getLanguages(ctx.request.params);
        ctx.body = data;
      } catch (err) {
        ctx.badRequest("Error encountered while fetching data in given language", { moreDetails: err });
      }
    },
  };