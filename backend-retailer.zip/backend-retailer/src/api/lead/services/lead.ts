/**
 * lead service
 */

import { factories } from "@strapi/strapi";
import { RESPONSE_MESSAGE, defaultPaginationConfig } from "../../../constants";
import {
  HttpStatusCode,
  LeadSourceEnum,
  LeadStatusEnum,
  LeadSubStatusEnum,
  LeadTypeEnum,
  SolarCategory,
  SolarCategorySapDivisionCode,
} from "../../../enums";
import {
  FetchLeadsRequestDto,
  CreateLeadRequestDto,
  LeadDto,
  FetchLeadsResponseDto,
  PaginationDto,
  FetchLeadDetailsResponseDto,
  FetchAssignedLeadsRequestDto,
  FetchAssignedLeadsResponseDto,
} from "../../../dtos";
import { currentFormattedDate } from "../../../utils/helperFuntions";

export default factories.createCoreService("api::lead.lead", ({ strapi }) => ({
  /**
   * Fetches lead ids based on provided category ids.
   * @param categoryIds - Array of category ids.
   * @returns - Array of lead ids.
   */
  async fetchLeadCodesByCategoryIds(categoryIds: string[]): Promise<string[]> {
    // Check if categoryIds array is provided and not empty
    if (categoryIds && categoryIds.length) {
      const leadProducts = await strapi.db
        .query("api::lead-product.lead-product")
        .findMany({
          select: ["leadCode"],
          where: { categoryId: categoryIds, soldProduct: false },
        });
      return leadProducts
        .map((leadProduct) => leadProduct.leadCode)
        .filter(Boolean);
    }
    // If categoryIds array is empty or not provided, return an empty array
    return [];
  },

  /**
   * Fetches leads based on provided lead ids, lead type, and pagination.
   * @param leadIds - Array of lead ids.
   * @param leadType - Lead type filter.
   * @param pagination - Pagination settings.
   * @returns - Array of leads.
   */
  async fetchLeadsByLeadIdsAndLeadType(
    leadCodes: string[],
    leadType: LeadTypeEnum[],
    pagination: PaginationDto,
    retailerId: string
  ): Promise<{ results: LeadDto[]; pagination: PaginationDto }> {
    const query = {
      filters: {
        ...(leadCodes.length && { leadCode: leadCodes }),
        ...(leadType.length && { leadType }),
        ...{ creatorId: retailerId, associatedId: null }, // fetch only leads added by retailer
      },
      pagination: {
        page: pagination.page || defaultPaginationConfig.page,
        pageSize: pagination.pageSize || defaultPaginationConfig.pageSize,
      },
      fields: [
        "leadCode",
        "leadId",
        "name",
        "email",
        "mobileNumber",
        "leadType",
        "pincode",
      ],
      sort: ["createdAt:desc"],
    };
    const response = await strapi.service("api::lead.lead").find(query);

    return response;
  },

  /**
   * Fetches category information for a given lead id.
   * @param leadId - Lead id.
   * @returns - Object containing category name.
   */
  async getCategoryByLeadCode(
    leadCode: string
  ): Promise<{ data: { categoryName: string } }> {
    const category = await strapi
      .service("api::lead-product.lead-product")
      .getCategoryByLeadCode(leadCode);
    if (!category) return null;
    return { data: { categoryName: category.categoryName } };
  },

  async getLeadCategoryName(leadCode: string): Promise<SolarCategory> {
    const leadCategory = await strapi
      .service("api::lead-product.lead-product")
      .getCategoryByLeadCode(leadCode);
    if (
      leadCategory &&
      leadCategory.sapDivisionCode ===
        SolarCategorySapDivisionCode.SOLAR_WATER_HEATER_CODE
    ) {
      return SolarCategory.SOLAR_WATER_HEATER;
    }
    return SolarCategory.SOLAR_POWER_SYSTEM;
  },

  async getAllLeads(
    payload: FetchLeadsRequestDto,
    loggedInUser
  ): Promise<FetchLeadsResponseDto | any> {
    const { categoryIds, leadType } = payload.filters;
    const { pagination: paginationFilter } = payload;
    const leadCodes = await this.fetchLeadCodesByCategoryIds(categoryIds);
    if (categoryIds.length && leadCodes.length === 0) {
      return {
        data: [],
        meta: {
          pagination: { ...paginationFilter, ...{ pageCount: 1, total: 0 } },
          filters: payload.filters,
        },
      };
    }

    const { results, pagination } = await this.fetchLeadsByLeadIdsAndLeadType(
      leadCodes,
      leadType,
      paginationFilter,
      loggedInUser.retailerId
    );

    const leadsWithCategories = await Promise.all(
      results.map(async (lead: LeadDto) => {
        const category = await this.getCategoryByLeadCode(lead.leadCode);
        return {
          ...lead,
          ...{ leadCategory: category ? category.data : null },
        };
      })
    );

    return {
      data: leadsWithCategories,
      meta: { pagination, filters: payload.filters },
    };
  },

  /**
   * Creates a new lead based on the provided payload and the logged-in user's information
   * and map the leadTypeId with payload
   * @param payload - The data required to create the lead, including lead details and category/subcategory IDs.
   * @param loggedInUser - The details of the logged-in user initiating the lead creation.
   * @returns The newly created lead.
   * @throws if there's an error during the lead creation process.
   */
  async createLead(payload: CreateLeadRequestDto, loggedInUser) {
    try {
      // Fetch the leadTypeId/recordTypeId from lead-type and map
      const leadType = await strapi
        .service("api::lead-type.lead-type")
        .getLeadTypeDetailsByLeadType(payload.leadType);

      // TODO: remove this code after aws app flow sync up
      const leadStatusHierarchy = await strapi.db
        .query("api::lead-status-hierarchy.lead-status-hierarchy")
        .findOne({
          where: { parentStatus: LeadSubStatusEnum.NEW_LEAD_ASSIGNED },
        });

      const data = {
        ...payload,
        ...{
          creatorId: loggedInUser.retailerId,
          leadSource: LeadSourceEnum.RETAILER,
          leadTypeId: leadType.leadTypeId,
          status: LeadStatusEnum.PARTNER_ASSIGNED, // TODO: remove this once we have app flow
          subStatus: LeadSubStatusEnum.NEW_LEAD_ASSIGNED, // TODO: remove this once we have app flow
          subStatusId: leadStatusHierarchy.parentId, // TODO: remove this once we have app flow
        },
      };

      let createdLead = await strapi.service("api::lead.lead").create({ data });

      /**
       * TODO: remvoe the leadId update part once data is sync with app flow,
       * doing for syncing the lead product image in "content-document-link" table
       **/
      createdLead = await strapi.db.query("api::lead.lead").update({
        where: { leadCode: createdLead.leadCode },
        data: { leadId: createdLead.leadCode },
      });

      // Map leadId with lead-product to associate lead with category
      await strapi.service("api::lead-product.lead-product").create({
        data: {
          leadCode: createdLead.leadCode,
          leadId: createdLead.leadId,
          categoryId: payload.categoryId,
          subCategoryId: payload.subCategoryId,
          soldProduct: false,
        },
      });
      return createdLead;
    } catch (error) {
      throw {
        status: HttpStatusCode.BAD_REQUEST,
        message: "Error while creating lead",
        error,
      };
    }
  },

  /**
   * Fetches the category and subcategory information for a lead based on leadId.
   * @param leadId - The lead id.
   * @returns - The category and subcategory information or null if lead not found.
   */
  async fetchCategoryAndSubCategoryByLeadCode(leadCode: string): Promise<{
    leadCategory: { categoryName: string };
    leadSubCategory: { categoryName: string };
  } | null> {
    const leadProduct = await strapi.db
      .query("api::lead-product.lead-product")
      .findOne({ where: { leadCode } });
    // const leadProduct = await strapi
    // .service("api::lead-product.lead-product")
    // .getCategoriesByLeadProductCode(leadCode);
    if (leadProduct) {
      const category = await await strapi
        .service("api::category.category")
        .getCategoryByCategoryId(leadProduct.categoryId);
      const subCategory = await await strapi
        .service("api::sub-category.sub-category")
        .getSubCategoryBySubCategoryId(leadProduct.subCategoryId);

      return {
        leadCategory: { categoryName: category.categoryName },
        leadSubCategory: { categoryName: subCategory.subCategoryName },
      };
    }
    return null;
  },

  /**
   * Fetches lead details based on leadId.
   * @param  leadId - The lead id.
   * @returns - Lead details.
   * @throws - Throws an error if lead with the specified id is not found.
   */
  async fetchLeadDetailsByLeadCode(
    leadCode: string
  ): Promise<FetchLeadDetailsResponseDto> {
    const leadDetails = await strapi.db.query("api::lead.lead").findOne({
      select: [
        "name",
        "email",
        "mobileNumber",
        "leadType",
        "pincode",
        "district",
        "salesOffice",
        "state",
        "zone",
        "country",
      ],
      where: { leadCode },
    });
    if (!leadDetails) {
      throw {
        status: HttpStatusCode.NOT_FOUND,
        message: `Lead with leadCode ${leadCode} not found.`,
      };
    }
    const category = await this.fetchCategoryAndSubCategoryByLeadCode(leadCode);
    return { data: { ...leadDetails, ...category } };
  },

  // Lead management
  async getLeadsAssignedToUser(
    payload: FetchAssignedLeadsRequestDto,
    loggedInUser
  ): Promise<FetchAssignedLeadsResponseDto> {
    const { status, subStatus } = payload.filters;
    const { pagination: paginationFilter } = payload;

    let whereClause = [];

    if (status && status.length) {
      whereClause.push({ status });
    }
    if (subStatus && subStatus.length) {
      whereClause.push({ subStatus });
    }
    const limit = paginationFilter.pageSize || defaultPaginationConfig.pageSize;
    const offset =
      paginationFilter.page && paginationFilter.page > 0
        ? (paginationFilter.page - 1) * limit // Calculate offset based on page number
        : 0;

    let [results, recordCount] = await strapi.db
      .query("api::lead.lead")
      .findWithCount({
        select: [
          "id",
          "leadCode",
          "name",
          "status",
          "receivedOn", // TODO: fetch date in history "lead allocation to the partner"
          "subStatus",
        ],
        where: {
          $or: whereClause,
          $and: [
            {
              // associatedId: loggedInUser.retailerId  // TODO: uncomment, fetch leads which is assigned to retailer
              creatorId: loggedInUser.retailerId,
            },
          ],
        },
        offset,
        limit,
        orderBy: { createdAt: "desc" },
      });

    const pagination = {
      page: paginationFilter.page,
      pageSize: limit,
      pageCount: Math.ceil(recordCount / limit),
      total: recordCount,
    };
    if (paginationFilter.page > limit) {
      results = [];
    }

    // Fetch categories for fetched leads using leadIds
    const leadsWithCategories = await Promise.all(
      results.map(async (lead: LeadDto) => {
        const category = await this.getCategoryByLeadCode(lead.leadCode);
        return {
          ...lead,
          ...{ leadCategory: category ? category.data : null },
        };
      })
    );

    return {
      data: leadsWithCategories,
      meta: { pagination, filters: payload.filters },
    };
  },

  async getAssignedLeadDetails(
    leadCode: string,
    loggedInUser
  ): Promise<FetchLeadDetailsResponseDto | any> {
    const leadRecord = await strapi.db.query("api::lead.lead").findOne({
      where: {
        //  associatedId: loggedInUser.retailerId  // TODO: uncomment, fetch leads which is assigned to retailer
        leadCode,
        creatorId: loggedInUser.retailerId,
      },
      select: [
        "leadCode",
        "leadId",
        "name",
        "email",
        "mobileNumber",
        "leadType",
        "pincode",
        "district",
        "state",
        "salesOffice",
        "zone",
        "country",
        "leadSource",
        "referredBy",
        "installationDate",
        "roofType",
        "shadeFreeRoofArea",
        "avgMonthlyElectricityBill",
        "enquiryOver10kw",
      ],
    });
    if (!leadRecord) {
      throw {
        status: HttpStatusCode.NOT_FOUND,
        message: `No Lead found with the leadCode ${leadCode}`,
      };
    }

    const associatedCategory = await this.fetchCategoryAndSubCategoryByLeadCode(
      leadRecord.leadCode
    );

    const leadDetails = {
      ...leadRecord,
      ...associatedCategory,
    };

    return {
      data: leadDetails,
    };
  },

  async getLeadStatus(leadCode: string, loggedInUser) {
    const leadDetails = await strapi.db.query("api::lead.lead").findOne({
      where: {
        //  associatedId: loggedInUser.retailerId  // TODO: uncomment, fetch leads which is assigned to retailer
        leadCode,
        creatorId: loggedInUser.retailerId,
      },
      select: [
        "leadId",
        "status",
        "subStatus",
        "subStatus2",
        "comment",
        "installationDate",
        "followUpDate",
      ],
    });
    if (!leadDetails) {
      throw {
        status: HttpStatusCode.NOT_FOUND,
        message: `No Lead found with the leadCode ${leadCode}`,
      };
    }
    const leadImage = await strapi
      .service("api::content-document-link.content-document-link")
      .getContentVersionByLinkedEntity(leadDetails.leadId);
    // to fetch the next sequential subStatus options
    const getStatusHierarchy = await strapi
      .service("api::lead-status-hierarchy.lead-status-hierarchy")
      .getStatusDetailsByName(leadDetails.subStatus);
    return {
      data: {
        ...leadDetails,
        ...{ image: leadImage, subStatusMetaData: getStatusHierarchy },
      },
    };
  },

  /**
   * Updates the status of a lead based on the provided request body.
   * Also updates the subStatus in the leadStatusFact table and logs the status change in the leadStatusHistory table.
   *
   * @param leadCode - uuid of the lead to update.
   * @param requestBody - The request body containing the updated lead status information.
   * @returns - An object containing the updated lead data and status code.
   * @throws - Throws an error if updating the lead status fails.
   */
  async updateLeadStatus(leadCode: string, requestBody) {
    try {
      // Update the status based on the (negative)subStatus
      const negativeSubStatusToUpdateStatus = [
        LeadSubStatusEnum.LEAD_NOT_ACCEPTED,
        LeadSubStatusEnum.LEAD_REJECTED,
        LeadSubStatusEnum.JUNK_OR_NOT_RELEVANT,
        LeadSubStatusEnum.NOT_CONVERTIBLE,
      ];
      if (negativeSubStatusToUpdateStatus.includes(requestBody.status)) {
        requestBody.status = LeadStatusEnum.ASSIGNED_BACK_TO_CALL_CENTER;
      }

      // Check if childId is not there then fetch the childId to map with lead
      if (!requestBody.childId) {
        const getStatusHierarchy = await strapi
          .service("api::lead-status-hierarchy.lead-status-hierarchy")
          .getStatusDetailsByChildStatus(requestBody.subStatus);
        if (getStatusHierarchy) {
          // Map current subStatusId to track the current subStatus from lead status hierarchy
          requestBody.subStatusId = getStatusHierarchy.childId;
        }
      } else {
        requestBody.subStatusId = requestBody.childId;
      }

      const updatedLead = await strapi.db.query("api::lead.lead").update({
        where: {
          leadCode,
        },
        data: requestBody,
      });

      if (updatedLead) {
        await strapi
          .service("api::lead-status-history.lead-status-history")
          .create({
            data: {
              ...requestBody,
              leadCode,
              ...{ createdDate: currentFormattedDate() },
            },
          });
      }

      return {
        status: HttpStatusCode.OK,
        data: updatedLead,
      };
    } catch (error) {
      throw {
        status: HttpStatusCode.BAD_REQUEST,
        message: `Error while updating lead status with leadCode ${leadCode}`,
        error,
      };
    }
  },

  async createOrUpdateLeadProducts(leadCode: string, requestBody) {
    const { total, leadProducts } = requestBody;
    try {
      if (leadProducts && leadProducts.length) {
        for (const leadProduct of leadProducts) {
          if (!leadProduct.leadProductCode) {
            // create
            await strapi.service("api::lead-product.lead-product").create({
              data: {
                ...leadProduct,
                ...{ leadCode, soldProduct: true },
              },
            });
          }
        }

        // Update the total in lead table
        await strapi.db.query("api::lead.lead").update({
          where: {
            leadCode,
          },
          data: {
            total,
          },
        });

        return {
          status: HttpStatusCode.OK,
          message: RESPONSE_MESSAGE["en"].SUCCESS,
        };
      }
    } catch (error) {
      throw {
        status: HttpStatusCode.BAD_REQUEST,
        message: `Error while updating lead product with leadCode ${leadCode}`,
        error,
      };
    }
  },

  async getLeadProducts(leadCode: string) {
    const lead = await strapi.db
      .query("api::lead.lead")
      .findOne({ select: ["total"], where: { leadCode } });
    if (!lead) {
      throw { status: HttpStatusCode.NOT_FOUND, message: "No lead found" };
    }
    try {
      const products = await strapi.db
        .query("api::lead-product.lead-product")
        .findMany({
          select: [
            "leadProductCode",
            "productSKU",
            "pricePerSKU",
            "quantity",
            "categoryId",
            "subCategoryId",
            "totalPricePerSKU",
          ],
          where: { leadCode, soldProduct: true },
        });

      if (!products || products.length === 0) {
        return {
          status: HttpStatusCode.NOT_FOUND,
          message: "No lead product found",
          data: { leadProducts: [] },
        };
      }

      const leadProducts = await Promise.all(
        products.map(async (leadProduct) => {
          const associatedCategory = await strapi
            .service("api::lead-product.lead-product")
            .getProductCategoriesByLeadProductCode(leadProduct.leadProductCode);
          return {
            ...{
              leadProductCode: leadProduct.leadProductCode,
              productSKU: leadProduct.productSKU,
              pricePerSKU: leadProduct.pricePerSKU,
              quantity: leadProduct.quantity,
              totalPricePerSKU: leadProduct.totalPricePerSKU,
            },
            ...associatedCategory,
          };
        })
      );

      return {
        status: HttpStatusCode.OK,
        data: { leadProducts, total: lead.total },
      };
    } catch (err) {}
  },

  async getCurrentSubStatusByLeadCode(leadCode: string) {
    const leadStatus = await strapi.db
      .query("api::lead.lead")
      .findOne({ select: ["subStatus", "subStatusId"], where: { leadCode } });
    return leadStatus;
  },
}));
