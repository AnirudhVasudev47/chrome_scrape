/**
 * lead controller
 */

import { factories } from "@strapi/strapi";
import {
  HttpStatusCode,
  LeadStatusEnum,
  LeadSubStatusEnum,
} from "../../../enums";

export default factories.createCoreController(
  "api::lead.lead",
  ({ strapi }) => ({
    async getLeadStatusFilters(ctx) {
      const { status: selectedStatus } = ctx.request.query;
      const partnerAssignedSubStatus = [
        LeadSubStatusEnum.NO_ANSWER,
        LeadSubStatusEnum.SWITCHED_OFF,
        LeadSubStatusEnum.PURCHASE_LATER,
        LeadSubStatusEnum.NEW_LEAD_ASSIGNED,
        LeadSubStatusEnum.LEAD_ACCEPTED,
        LeadSubStatusEnum.CATALOGUE_SHARED,
        LeadSubStatusEnum.SITE_SURVEY,
        LeadSubStatusEnum.SITE_NOT_READY_CONSTRUCTION,
        LeadSubStatusEnum.SITE_READY,
        LeadSubStatusEnum.WATER_TESTING_SWH,
        LeadSubStatusEnum.QUOTATION,
        LeadSubStatusEnum.DISTRIBUTION_CO_APPROVAL_SPS,
        LeadSubStatusEnum.PRODUCT_INSTALLED,
        LeadSubStatusEnum.DISTRIBUTION_CO_INSPECTION_SPS,
        LeadSubStatusEnum.COMMISSIONING_SPS_AND_SWH,
        LeadSubStatusEnum.AWAITING_PARTNER_ASSIGNMENT,
      ];

      const closedSubStatus = [
        LeadSubStatusEnum.ENQUIRY_OR_OTHER_CATEGORY,
        LeadSubStatusEnum.JUNK,
        LeadSubStatusEnum.DUPLICATE,
        LeadSubStatusEnum.NOT_CONVERTIBLE,
        LeadSubStatusEnum.PARTNER_FEEDBACK_VALID,
        LeadSubStatusEnum.PARTNER_FEEDBACK_INVALID,
        LeadSubStatusEnum.CONVERTED_AND_VERIFIED,
      ];

      let subStatus = [];
      if (
        selectedStatus &&
        selectedStatus.includes(LeadStatusEnum.PARTNER_ASSIGNED)
      ) {
        subStatus = subStatus.concat(partnerAssignedSubStatus);
      }
      if (selectedStatus && selectedStatus.includes(LeadStatusEnum.CLOSED)) {
        subStatus = subStatus.concat(closedSubStatus);
      }
      const status = [LeadStatusEnum.PARTNER_ASSIGNED, LeadStatusEnum.CLOSED];
      ctx.send({ data: { status, subStatus } }, HttpStatusCode.OK);
    },

    async getAllLeads(ctx) {
      const leads = await strapi
        .service("api::lead.lead")
        .getAllLeads(ctx.request.body, ctx.state.loggedInUser);
      ctx.send(leads, HttpStatusCode.OK);
    },

    async getCategoryByLeadCode(ctx) {
      try {
        const leadDetails = await strapi
          .service("api::lead.lead")
          .getCategoryByLeadCode(ctx.request.params.leadCode);
        ctx.send(leadDetails, HttpStatusCode.OK);
      } catch (error) {
        const { status = HttpStatusCode.BAD_REQUEST, ...rest } = error;
        ctx.send(
          {
            ...rest,
          },
          status
        );
      }
    },

    async createLead(ctx) {
      try {
        const createdLead = await strapi
          .service("api::lead.lead")
          .createLead(ctx.request.body.data, ctx.state.loggedInUser);
        ctx.send(createdLead, HttpStatusCode.CREATED);
      } catch (error) {
        const { status = HttpStatusCode.BAD_REQUEST, ...rest } = error;
        ctx.send(
          {
            ...rest,
          },
          status
        );
      }
    },

    async getLeadDetails(ctx) {
      try {
        const leadDetails = await strapi
          .service("api::lead.lead")
          .fetchLeadDetailsByLeadCode(ctx.request.params.leadCode);
        ctx.send(leadDetails, HttpStatusCode.OK);
      } catch (error) {
        const { status = HttpStatusCode.BAD_REQUEST, ...rest } = error;
        ctx.send(
          {
            ...rest,
          },
          status
        );
      }
    },

    // Lead management
    async getLeadsAssignedToUser(ctx) {
      try {
        const leadDetails = await strapi
          .service("api::lead.lead")
          .getLeadsAssignedToUser(ctx.request.body, ctx.state.loggedInUser);
        ctx.send(leadDetails, HttpStatusCode.OK);
      } catch (error) {
        const { status = HttpStatusCode.BAD_REQUEST, ...rest } = error;
        ctx.send(
          {
            ...rest,
          },
          status
        );
      }
    },

    async getAssignedLeadDetails(ctx) {
      try {
        const leadDetails = await strapi
          .service("api::lead.lead")
          .getAssignedLeadDetails(
            ctx.request.params.leadCode,
            ctx.state.loggedInUser
          );
        ctx.send(leadDetails, HttpStatusCode.OK);
      } catch (error) {
        const { status = HttpStatusCode.BAD_REQUEST, ...rest } = error;
        ctx.send(
          {
            ...rest,
          },
          status
        );
      }
    },

    async getLeadStatus(ctx) {
      try {
        const leadDetails = await strapi
          .service("api::lead.lead")
          .getLeadStatus(ctx.request.params.leadCode, ctx.state.loggedInUser);
        ctx.send(leadDetails, HttpStatusCode.OK);
      } catch (error) {
        const { status = HttpStatusCode.BAD_REQUEST, ...rest } = error;
        ctx.send(
          {
            ...rest,
          },
          status
        );
      }
    },

    async updateLeadStatus(ctx) {
      try {
        const leadDetails = await strapi
          .service("api::lead.lead")
          .updateLeadStatus(ctx.request.params.leadCode, ctx.request.body.data);
        ctx.send(leadDetails, HttpStatusCode.OK);
      } catch (error) {
        const { status = HttpStatusCode.BAD_REQUEST, ...rest } = error;
        ctx.send(
          {
            ...rest,
          },
          status
        );
      }
    },

    async createOrUpdateLeadProducts(ctx) {
      try {
        const updatedLead = await strapi
          .service("api::lead.lead")
          .createOrUpdateLeadProducts(
            ctx.request.params.leadCode,
            ctx.request.body.data
          );
        ctx.send(updatedLead, HttpStatusCode.OK);
      } catch (error) {
        const { status = HttpStatusCode.BAD_REQUEST, ...rest } = error;
        ctx.send(
          {
            ...rest,
          },
          status
        );
      }
    },

    async getLeadProducts(ctx) {
      try {
        const { status = HttpStatusCode.OK, ...rest } = await strapi
          .service("api::lead.lead")
          .getLeadProducts(ctx.request.params.leadCode);

        ctx.send(
          {
            ...rest,
          },
          status
        );
      } catch (error) {
        const { status = HttpStatusCode.BAD_REQUEST, ...rest } = error;
        ctx.send(
          {
            ...rest,
          },
          status
        );
      }
    },
  })
);
