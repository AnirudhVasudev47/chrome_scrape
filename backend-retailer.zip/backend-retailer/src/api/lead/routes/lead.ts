export default {
  routes: [
    {
      method: "GET",
      path: "/leads/status-filters",
      handler: "lead.getLeadStatusFilters",
    },
    {
      method: "POST",
      path: "/leads/filters",
      handler: "lead.getAllLeads",
    },
    {
      method: "POST",
      path: "/leads/",
      handler: "lead.createLead",
    },
    {
      method: "GET",
      path: "/leads/:leadCode",
      handler: "lead.getLeadDetails",
    },
    {
      method: "GET",
      path: "/leads/:leadCode/category",
      handler: "lead.getCategoryByLeadCode",
    },
    {
      method: "POST",
      path: "/assigned-leads",
      handler: "lead.getLeadsAssignedToUser",
    },
    {
      method: "GET",
      path: "/assigned-leads/:leadCode",
      handler: "lead.getAssignedLeadDetails",
    },
    {
      method: "GET",
      path: "/assigned-leads/:leadCode/status",
      handler: "lead.getLeadStatus",
    },
    {
      method: "PUT",
      path: "/assigned-leads/:leadCode/status",
      handler: "lead.updateLeadStatus",
    },
    {
      method: "GET",
      path: "/assigned-leads/:leadCode/products",
      handler: "lead.getLeadProducts",
    },
    {
      method: "POST",
      path: "/assigned-leads/:leadCode/products",
      handler: "lead.createOrUpdateLeadProducts",
    },
  ],
};
