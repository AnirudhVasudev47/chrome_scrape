/**
 * area-master router
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::area-master.area-master');
