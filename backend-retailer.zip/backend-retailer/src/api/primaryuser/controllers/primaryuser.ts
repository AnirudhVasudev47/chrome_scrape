/**
 * primaryuser controller
 */
import { factories } from "@strapi/strapi";
export default factories.createCoreController(
  "api::primaryuser.primaryuser",
  ({ strapi }) => ({
    async findRecord(ctx) {
      let { data, meta } = await super.find(ctx);
      return { data, meta };
    },
    async updateRecord(ctx) {
      const response = await super.update(ctx);
      return response;
    },
  })
)