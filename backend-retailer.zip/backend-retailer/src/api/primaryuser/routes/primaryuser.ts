/**
 * primaryuser router
 */
module.exports = {
  routes: [
    // {
    //   method: "GET",
    //   path: "/profile/personalDetails",
    //   handler: "primaryuser.find",
    // },
    //   {
    //     method: "GET",
    //     path: "/profile/bankKycDetails",
    //     handler: "primaryuser.find",
    //   },
    //   {
    //     method: "PUT",
    //     path: "/profile/profilePhoto",
    //     handler: "primaryuser.update",
    //   },{
    //       method: "PUT",
    //       path: "/profile/personalDetails",
    //       handler: "primaryuser.update",
    //     },{
    //       method: "PUT",
    //       path: "/profile/bankKycDetails",
    //       handler: "primaryuser.update",
    //     },
  ],
};
