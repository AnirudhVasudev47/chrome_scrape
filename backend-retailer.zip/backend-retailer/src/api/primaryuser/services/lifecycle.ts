import moment from "moment";
import Message from "../../../utils/constants/notificationConst"
import {addToInAppQueue} from "../../../utils/queue/queueService";

export const scheduleNotification = async ({strapi, data}) => {
	const {retailerId, mobileNumber, dateOfBirth, marriageAnniversary, storeAnniversary, retailerName} = data;

	const birthdayMessage = Message.birthdayMessage({name: retailerName, points: '50'})
	const anniversaryMessage = Message.anniversaryMessage({name: retailerName, points: '50'})
	const storeAnniversaryMessage = Message.storeAnniversaryMessage({name: retailerName, points: '50'})

	const birthdayObj = {
		data: {
			title: birthdayMessage.title,
			message: birthdayMessage.message,
			start: moment(dateOfBirth, 'YYYY-MM-DD'),
			hasEnding: false,
			repeat: 'Yearly'
		}
	}
	const storeAnniversaryObj = {
		data: {
			title: storeAnniversaryMessage.title,
			message: storeAnniversaryMessage.message,
			start: moment(storeAnniversary, 'YYYY-MM-DD'),
			hasEnding: false,
			repeat: 'Yearly'
		}
	}

	addPush(retailerId, birthdayObj, strapi);
	addSms(mobileNumber, birthdayObj, strapi);
	addInApp(retailerId, birthdayObj, birthdayMessage.icon, birthdayMessage.tag);

	addPush(retailerId, storeAnniversaryObj, strapi);
	addSms(mobileNumber, storeAnniversaryObj, strapi);
	addInApp(retailerId, storeAnniversaryObj, storeAnniversaryMessage.icon, storeAnniversaryMessage.tag);

	if (marriageAnniversary) {
		const anniversaryObj = {
			data: {
				title: anniversaryMessage.title,
				message: anniversaryMessage.message,
				start: moment(marriageAnniversary, 'YYYY-MM-DD'),
				hasEnding: false,
				repeat: 'Yearly'
			}
		}
		addPush(retailerId, anniversaryObj, strapi);
		addSms(mobileNumber, anniversaryObj, strapi);
		addInApp(retailerId, anniversaryObj, anniversaryMessage.icon, anniversaryMessage.tag);
	}
}

const addPush = async (to, data, strapi) => {
	data.data.type = 'Push Notification';
	data.data.to = to;

	await strapi
		.entityService
		.create("plugin::notification.notification", data);
}


const addSms = async (to, data, strapi) => {
	data.data.type = 'SMS'
	data.data.to = to;

	await strapi
		.entityService
		.create("plugin::notification.notification", data);
}

const addInApp = async (to, data, icon, tag) => {
	const {
		title,
		message,
		start,
		hasEnding,
		repeat,
	} = data.data

	let finObj = {
		title: title,
		description: message,
		isOpened: false,
		retailerId: to,
		date: start,
		tagName: tag,
		icon: icon,
		repeat: repeat,
		hasEnding: hasEnding,
		endDate: ""
	}

	addToInAppQueue(finObj)
}
