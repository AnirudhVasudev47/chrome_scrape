/**
 * primaryuser service
 */

import { factories } from "@strapi/strapi";

export default factories.createCoreService(
  "api::primaryuser.primaryuser",
  ({ strapi }) => ({
    async getPartnerNameByRetailerId(retailerId) {
      const retailerParner = await strapi.db
        .query("api::primaryuser.primaryuser")
        .findOne({ select: ["partnerName"], where: { retailerId } });

      return retailerParner;
    },

    async getUser(loggedInUser) {
      const retailerId = loggedInUser.retailerId;
      const response = await strapi.db
        .query("api::primaryuser.primaryuser")
        .findOne({
          select: ["retailerId"],
          where: { retailerId },
        });
      return response;
    },

    /**
     * Retrieves the area associated with the given retailer.
     *
     * @param retailerId - The ID of the retailer to fetch the area for.
     * @returns - The area object associated with the retailer, or null if not found.
     */
    async getRetailerUserArea(retailerId: string) {
      const retailer = await strapi.db
        .query("api::primaryuser.primaryuser")
        .findOne({
          select: ["areaMasterId"],
          where: { retailerId },
        });
      if (!retailer) {
        throw new Error(`Retailer not found with retailerId ${retailerId}`);
      }

      const retailerArea = await strapi.db
        .query("api::area-master.area-master")
        .findOne({ where: { areaMasterId: retailer.areaMasterId } });

      if (!retailerArea) {
        throw new Error("Retailer is not associated with any area");
      }
      return retailerArea;
    },
  })
);
