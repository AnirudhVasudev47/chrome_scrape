/**
 * content-document-link service
 */

import { factories } from "@strapi/strapi";

export default factories.createCoreService(
  "api::content-document-link.content-document-link",
  ({ strapi }) => ({
    async getContentDocumentByLinkedEntity(linkedEntityId: string) {
      const contentDocumentLink = await strapi.db
        .query("api::content-document-link.content-document-link")
        .findOne({
          where: { linkedEntityId },
        });

      if (contentDocumentLink) {
        const contentDocument = await strapi.db
          .query("api::content-document.content-document")
          .findOne({
            select: ["contentDocumentId", "title", "uploadedAt"],
            where: {
              contentDocumentId: contentDocumentLink.contentDocumentId,
            },
          });
        if (contentDocument) {
          return contentDocument;
        }
      }
      return null;
    },

    async getContentVersionByLinkedEntity(linkedEntityId: string) {
      const contentDocument = await this.getContentDocumentByLinkedEntity(
        linkedEntityId
      );

      if (contentDocument) {
        const contentVersion = await strapi.db
          .query("api::content-version.content-version")
          .findOne({
            where: {
              contentDocumentId: contentDocument.contentDocumentId,
            },
          });
        if (contentVersion) {
          return {
            contentUrl: contentVersion.contentUrl,
            versionData: contentVersion.versionData,
            title: contentDocument.title,
            uploadedAt: contentDocument.uploadedAt,
          };
        }
      }
      return null;
    },
  })
);
