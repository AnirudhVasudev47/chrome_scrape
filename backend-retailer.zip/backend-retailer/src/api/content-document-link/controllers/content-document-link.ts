/**
 * content-document-link controller
 */

import { factories } from '@strapi/strapi'

export default factories.createCoreController('api::content-document-link.content-document-link');
