/**
 * content-document-link router
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::content-document-link.content-document-link');
