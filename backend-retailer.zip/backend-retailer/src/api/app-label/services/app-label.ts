/**
 * app-label service
 */

import { factories } from "@strapi/strapi";

export default factories.createCoreService(
  "api::app-label.app-label",
  ({ strapi }) => ({
    async getLanguages(params) {
      try {
        const localeValue = params.locale;
        const data = await strapi.db
          .query("api::app-label.app-label")
          .findMany({
            where: { locale: localeValue },
          });
        return data;
      } catch (error) {
        return error;
      }
    },
  })
);
