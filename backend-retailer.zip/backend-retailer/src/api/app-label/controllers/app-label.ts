/**
 * app-label controller
 */

import { factories } from "@strapi/strapi";

export default factories.createCoreController(
  "api::app-label.app-label",
  ({ strapi }) => ({
    async find(ctx) {
      const data = await strapi
        .service("api::app-label.app-label")
        .getLanguages(ctx.request.query);
      return data;
    },
  })
);
