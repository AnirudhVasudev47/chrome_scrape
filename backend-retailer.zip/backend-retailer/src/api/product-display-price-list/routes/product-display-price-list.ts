/**
 * product-display-price-list router
 */

export default {
  routes: [
    {
      method: "GET",
      path: "/product-price-list/filters",
      handler: "product-display-price-list.getFilters",
    },
    {
      method: "POST",
      path: "/product-documents-search",
      handler: "product-display-price-list.getProductDocuments",
    },
    {
      method: "POST",
      path: "/product-videos-search",
      handler: "product-display-price-list.getProductVideos",
    },
    {
      method: "POST",
      path: "/price-list-search",
      handler: "product-display-price-list.getPriceList",
    },
  ],
};
