/**
 * product-display-price-list service
 */

import { factories } from "@strapi/strapi";
import {
  priceListContentType,
  productVideoContentType,
  productDocumentContentType,
} from "../../../constants";
import { HttpStatusCode } from "../../../enums";

export default factories.createCoreService(
  "api::product-display-price-list.product-display-price-list",
  ({ strapi }) => ({
    /**
     * Fetches sub-categories and SKU products based on the provided category ID.
     * @param categoryId - The ID of the category to fetch sub-categories and SKU products for.
     * @returns - A promise resolving to an object containing sub-categories, SKU products, and content types.
     */
    async fetchFilters(categoryId: string) {
      const subCategories = await strapi
        .service("api::sub-category.sub-category")
        .getSubCategoriesByCategoryId(categoryId);

      const SKUproducts = await strapi
        .service("api::skuproduct.skuproduct")
        .getSKUProductsByCategoryId(categoryId);

      return {
        data: {
          subCategories,
          SKUproducts,
          productDocumentContentType: productDocumentContentType,
          productVideoContentType: productVideoContentType,
        },
      };
    },

    /**
     * Updates the query parameters for fetching product documents based on retailer user area and other criteria.
     * @param query - The original query parameters for fetching product documents.
     * @param retailerId - The retailerId from the logged in user.
     * @returns - A promise resolving to the updated query parameters.
     */
    async updateQueryParamsForProductDocuments(query, retailerId: string) {
      const { zone, salesOffice } = await this.getRetailerUserArea(retailerId);
      query.filters = {
        ...query.filters,
        ...{
          salesOffice,
          zone,
        },
      };

      // If no document type filter is specified, add default documentType to fetch the records
      if (
        !query.filters?.documentType ||
        query.filters?.documentType.length === 0
      ) {
        query.filters = {
          ...query.filters,
          ...{ documentType: { $containsi: productDocumentContentType } },
        };
      }
      // Sort the results by subCategoryId in ascending order for pagination
      query.sort = ["subCategoryId:asc"];
      query.fields = ["subCategoryId", "productDisplayPriceListId"];

      if (query.filters.uploadedAt) {
        const filters = { uploadedAt: query.filters.uploadedAt };
        const linkedEntityIds = await this.fetchLinkedEntitiesByUploadedDate(
          filters
        );
        query.filters = {
          ...query.filters,
          ...{ productDisplayPriceListId: linkedEntityIds },
        };
      }
      return query;
    },

    /**
     * Fetches product documents based on the provided query parameters and retailer user ID.
     * @param query - The query parameters for fetching product documents.
     * @param retailerId - The retailerId from the logged in user.
     * @returns - A promise resolving to an object containing grouped product documents and pagination information.
     */
    async getProductDocuments(query, retailerId: string) {
      try {
        const appliedFilters = JSON.parse(JSON.stringify(query?.filters));
        const updatedQuery = await this.updateQueryParamsForProductDocuments(
          query,
          retailerId
        );
        const { results, pagination } = await strapi
          .service("api::product-display-price-list.product-display-price-list")
          .find(updatedQuery);

        const groupedProductDocuments = await this.groupRecordsBySubCategory(
          results,
          true
        );

        return {
          data: groupedProductDocuments,
          meta: { pagination, filters: appliedFilters },
        };
      } catch (error) {
        console.log("Error while getting product documents", error);
        throw { status: HttpStatusCode.BAD_REQUEST, error: { ...error } };
      }
    },

    /**
     * Updates the query parameters for fetching product data based on the retailer's information.
     * @param query - The query parameters to be updated.
     * @param retailerId - The ID of the retailer to fetch data for.
     * @returns - The updated query parameters.
     */
    async updateQueryParamsForProductVideo(query, retailerId: string) {
      // const appliedFilters = JSON.parse(JSON.stringify(query?.filters));

      const { zone, salesOffice } = await this.getRetailerUserArea(retailerId);
      query.filters = {
        ...query.filters,
        ...{
          salesOffice,
          zone,
        },
      };

      // If no document type filter is specified, add default documentType to fetch the records
      if (
        !query.filters?.documentType ||
        query.filters?.documentType.length === 0
      ) {
        query.filters = {
          ...query.filters,
          ...{ documentType: { $containsi: productVideoContentType } },
        };
      }
      // Sort the results by subCategoryId in ascending order for pagination
      query.sort = ["subCategoryId:asc"];
      query.fields = [
        "youtubeTitle",
        "youtubeLink",
        "youtubeCreatedAt",
        "subCategoryId",
      ];
      return query;
    },

    /**
     * Fetches product videos based on the provided query.
     * Results are sorted by subCategoryId in ascending order and only include specified fields.
     * The fetched product videos are grouped by sub-category.
     * @param query - The query parameters for fetching product videos.
     * @returns - An object containing grouped product videos and pagination information.
     */
    async getProductVideos(query, retailerId: string) {
      try {
        const appliedFilters = JSON.parse(JSON.stringify(query?.filters));
        const updatedQuery = await this.updateQueryParamsForProductVideo(
          query,
          retailerId
        );

        const { results, pagination } = await strapi
          .service("api::product-display-price-list.product-display-price-list")
          .find(updatedQuery);

        const groupedProductVideos = await this.groupRecordsBySubCategory(
          results
        );

        return {
          data: groupedProductVideos,
          meta: { pagination, filters: appliedFilters },
        };
      } catch (error) {
        console.log("Error while getting product videos", error);
        throw { status: HttpStatusCode.BAD_REQUEST, error: { ...error } };
      }
    },

    /**
     * Updates the query parameters for fetching price list records based on the retailer's area and other conditions.
     * @param query - The query parameters for fetching price list records.
     * @param retailerId - The retailerId from the logged in user.
     * @returns - A promise resolving to the updated query parameters.
     */
    async updateQueryParamsForPriceList(query, retailerId: string) {
      const { zone, salesOffice } = await this.getRetailerUserArea(retailerId);
      query.filters = {
        ...query.filters,
        ...{
          salesOffice,
          zone,
        },
        ...{ documentType: { $containsi: priceListContentType } },
      };

      // Sort the results by subCategoryId in ascending order for pagination
      query.sort = ["subCategoryId:asc"];
      query.fields = ["subCategoryId", "productDisplayPriceListId"];

      if (query.filters.uploadedAt) {
        const filters = { uploadedAt: query.filters.uploadedAt };
        const linkedEntityIds = await this.fetchLinkedEntitiesByUploadedDate(
          filters
        );
        query.filters = {
          ...query.filters,
          ...{ productDisplayPriceListId: linkedEntityIds },
        };
      }

      return query;
    },

    /**
     * Fetches price list records based on the provided query and retailer ID.
     * Results are grouped by sub-category and returned along with pagination information.
     * @param query - The query parameters for fetching price list records.
     * @param retailerId - The retailerId from the logged in user.
     * @returns - A promise resolving to grouped price list records and pagination information.
     */
    async getPriceList(query, retailerId: string) {
      try {
        const appliedFilters = JSON.parse(JSON.stringify(query?.filters));
        const updatedQuery = await this.updateQueryParamsForPriceList(
          query,
          retailerId
        );

        const { results, pagination } = await strapi
          .service("api::product-display-price-list.product-display-price-list")
          .find(updatedQuery);

        const groupedPriceList = await this.groupRecordsBySubCategory(
          results,
          true
        );
        return {
          data: groupedPriceList,
          meta: { pagination, filters: appliedFilters },
        };
      } catch (error) {
        console.log("Error while getting price list", error);
        throw { status: HttpStatusCode.BAD_REQUEST, error: { ...error } };
      }
    },

    /**
     * Fetches linked entity IDs associated with content documents uploaded on a specific date based on provided filters.
     * @param filters - Filters to specify the "uploadedAt" for fetching content documents.
     * @returns - A promise resolving to an array of linked entity IDs.
     */
    async fetchLinkedEntitiesByUploadedDate(filters) {
      const contentDocuments = await strapi.db
        .query("api::content-document.content-document")
        .findMany({ filters, select: ["contentDocumentId"] });
      if (contentDocuments.length) {
        const contentDocumentIds = contentDocuments.map(
          (contentDocument) => contentDocument.contentDocumentId
        );
        const associatedLinkedEntity = await strapi.db
          .query("api::content-document-link.content-document-link")
          .findMany({
            select: ["linkedEntityId"],
            where: { contentDocumentId: contentDocumentIds },
          });

        if (associatedLinkedEntity.length) {
          const linkedEntityIds = associatedLinkedEntity.map(
            (linkedEntity) => linkedEntity.linkedEntityId
          );
          return linkedEntityIds;
        }
      }
      return [];
    },

    /**
     * Retrieves the area associated with the retailer identified by the provided ID.
     * @param retailerId - The ID of the retailer.
     * @returns - A promise resolving to the area associated with the retailer.
     */
    async getRetailerUserArea(retailerId: string) {
      const retailerArea = await strapi
        .service("api::primaryuser.primaryuser")
        .getRetailerUserArea(retailerId);
      return retailerArea;
    },

    /**
     * Groups the provided array of data objects by sub-category.
     * @param data - The array of data objects to be grouped by sub-category.
     * @returns - An array containing objects grouped by sub-category, each containing
     *                    the sub-category ID, sub-category name, and an array of data objects
     *                    belonging to that sub-category.
     */
    async groupRecordsBySubCategory(data, fromDocument = false) {
      let groupedData = [];

      for (const curr of data) {
        const { subCategoryId, productDisplayPriceListId, ...rest } = curr;
        let entryObj = rest;

        // To call the contentDocument talble to fetch the associated uploaded content
        if (fromDocument) {
          const contentDocument = await this.fetchAssociatedContent(
            curr.productDisplayPriceListId
          );
          if (contentDocument) {
            entryObj = {
              ...entryObj,
              ...contentDocument,
            };
          }
        }
        const existingGroup = groupedData.find(
          (item) => item.subCategoryId === subCategoryId
        );
        if (existingGroup) {
          existingGroup.data.push(entryObj);
        } else {
          const { subCategoryName } = await strapi
            .service("api::sub-category.sub-category")
            .getSubCategoryById(subCategoryId);
          groupedData.push({
            subCategoryId,
            subCategoryName: subCategoryName || "",
            data: [entryObj],
          });
        }
      }

      return groupedData;
    },

    /**
     * Fetches content documents associated with the entity identified by the provided linkedEntityId.
     * @param linkedEntityId - The ID of the entity linked to the content documents.
     * @returns - A promise resolving to the fetched content documents.
     */
    async fetchAssociatedContent(linkedEntityId: string) {
      const contentDocument = await strapi
        .service("api::content-document-link.content-document-link")
        .getContentDocumentByLinkedEntity(linkedEntityId);
      return contentDocument;
    },
  })
);
