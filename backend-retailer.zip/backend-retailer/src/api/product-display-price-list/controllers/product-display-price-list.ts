/**
 * product-display-price-list controller
 */

import { factories } from "@strapi/strapi";
import { HttpStatusCode } from "../../../enums";

export default factories.createCoreController(
  "api::product-display-price-list.product-display-price-list",
  ({ strapi }) => ({
    async getFilters(ctx) {
      const productPriceListFilters = await strapi
        .service("api::product-display-price-list.product-display-price-list")
        .fetchFilters(ctx.request.query.categoryId);
      return productPriceListFilters;
    },

    async getProductDocuments(ctx) {
      try {
        const { status = HttpStatusCode.OK, ...rest } = await strapi
          .service("api::product-display-price-list.product-display-price-list")
          .getProductDocuments(
            ctx.request.body,
            ctx.state.loggedInUser.retailerId
          );
        ctx.send(
          {
            ...rest,
          },
          status
        );
      } catch (error) {
        const { status = HttpStatusCode.BAD_REQUEST, ...rest } = error;
        ctx.send(error, status);
      }
    },

    async getProductVideos(ctx) {
      try {
        const { status = HttpStatusCode.OK, ...rest } = await strapi
          .service("api::product-display-price-list.product-display-price-list")
          .getProductVideos(
            ctx.request.body,
            ctx.state.loggedInUser.retailerId
          );
        ctx.send(
          {
            ...rest,
          },
          status
        );
      } catch (error) {
        const { status = HttpStatusCode.BAD_REQUEST, ...rest } = error;
        ctx.send(error, status);
      }
    },

    async getPriceList(ctx) {
      try {
        const { status = HttpStatusCode.OK, ...rest } = await strapi
          .service("api::product-display-price-list.product-display-price-list")
          .getPriceList(ctx.request.body, ctx.state.loggedInUser.retailerId);
        ctx.send(
          {
            ...rest,
          },
          status
        );
      } catch (error) {
        const { status = HttpStatusCode.BAD_REQUEST, ...rest } = error;
        ctx.send(error, status);
      }
    },
  })
);
