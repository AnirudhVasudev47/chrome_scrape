/**
 * support controller
 */

import { factories } from "@strapi/strapi";
import {
  HttpStatusCode,
} from "../../../enums";

export default factories.createCoreController(
  "api::support.support",
  ({ strapi }) => ({
    async getAllSupportDetails(ctx) {
      const supporttypes = await strapi
        .service("api::support.support")
        .getAllSupportDetails(ctx.state.loggedInUser);
      ctx.send(supporttypes, HttpStatusCode.OK);
    },

    async getTicketHistory(ctx) {
      const supportdata = await strapi
        .service("api::support.support")
        .getTicketsHistory(ctx.request.body);
      ctx.send(supportdata, HttpStatusCode.OK);
    },

    async raiseTicket(ctx) {
      try {
      const response = await strapi
      .service("api::support.support")
      .raiseTicket(ctx.state.loggedInUser.retailerId, ctx.request.body);
    ctx.send(response, HttpStatusCode.OK);
  } catch (error) {
    const { status = HttpStatusCode.BAD_REQUEST, ...rest } = error;
    ctx.send(
      {
        ...rest,
      },
      status
    );
  }
  },

  })
);
