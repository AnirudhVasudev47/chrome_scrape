/**
 * support router
 */

export default {
  routes: [
    {
      method: "GET",
      path: "/support/details",
      handler: "support.getAllSupportDetails",
    },
    {
      method: "POST",
      path: "/support/raise-ticket",
      handler: "support.raiseTicket",
    },
    {
      method: "POST",
      path: "/support/ticket-history",
      handler: "support.getTicketHistory",
    },
  ],
};
