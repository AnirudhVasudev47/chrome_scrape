/**
 * support service
 */

import { factories } from "@strapi/strapi";
import {
  raiseTicketRequestDto,
  FetchTicketHistoryResponseDto,
} from "../../../dtos/support-dto";
import {OpenTicketStatuses, ClosedTicketStatuses, DateFilters, TicketStatuses} from "../../../constants/support";
import { PaginationDto } from "../../../dtos";
import { HttpStatusCode } from "../../../enums";
import * as fs from "fs";
import * as path from "path";
export default factories.createCoreService(
  "api::support.support",
  ({ strapi }) => ({
    async getAllSupportDetails(loggedInUser) {
      const productCategoryNames = await this.getCategoryName(
        loggedInUser.retailerId
      );
      const subTypes = await this.getSubTypes();
      const { supportTypeEnums, marketMaterialTypeEnums } =
        await this.getSupportTypeAndMarketMaterialType();
      const data = {
        data: {
          supportType: supportTypeEnums,
          subType: subTypes,
          marketMaterialType: marketMaterialTypeEnums,
          productCategory: productCategoryNames,
          status: TicketStatuses,
          dateFilter: DateFilters
        },
      };
      return data;
    },

    async getTicketsHistory(
      payload
    ): Promise<FetchTicketHistoryResponseDto> {
      let openTickets = [];
      let closedTickets = [];
      let openTicketStatuses = OpenTicketStatuses;
      let closedTicketStatuses = ClosedTicketStatuses;
      let response: FetchTicketHistoryResponseDto;
      const paginationFilter = payload.pagination;
      const { type, contentType, ticketStatus, customDate } = payload.filters;
      const { fromDate = "", toDate = "" } = customDate;
      const query = {
        fields: [
            "ticketCreatedDate",
            "ticketStatus",
            "ticketId",
            "supportType",
            "subType",
            "productCategory",
            "remarks",
        ],
        filters: {},
    };
    
    if (contentType && Array.isArray(contentType) && contentType.length > 0 && contentType.some((type) => type.trim() !== "")) {
        query.filters = { ...query.filters, ...{ supportType: contentType } };
    }
    
    if (ticketStatus && Array.isArray(ticketStatus) && ticketStatus.length > 0 && ticketStatus.some((type) => type.trim() !== "")) {
        query.filters = { ...query.filters, ...{ ticketStatus: ticketStatus } };
    }
    
    if (fromDate && toDate && fromDate.trim() !== "" && toDate.trim() !== "") {
        query.filters = {
            ...query.filters,
            ...{
                ticketCreatedDate: {
                    $between: [new Date(fromDate), new Date(toDate)],
                },
            },
        };
    }
        let { results: filteredSupportDetails, pagination } = await strapi
        .service("api::support.support")
        .find(query);
    let paginationValue = pagination;
    // Iterate over filteredSupportDetails to replace category ids with product category names
    // and categorize tickets based on status
    for (let ticket of filteredSupportDetails) {
        // Replace category ids with product category names
        let categoryId = ticket.productCategory;
        ticket.productCategory = await this.getCategoryNameByCategoryId(categoryId);
    
        // Group tickets based on status
        if (openTicketStatuses.includes(ticket.ticketStatus)) {
            openTickets.push(ticket);
        } else if (closedTicketStatuses.includes(ticket.ticketStatus)) {
            closedTickets.push(ticket);
        }
    }
    if (type === "OPEN_TICKET") {
       response = await this.getPaginatedTicketHistoryResponse(paginationValue, paginationFilter, openTickets, payload);
       return response;
    } else if (type === "CLOSED_TICKET") {
        response = await this.getPaginatedTicketHistoryResponse(paginationValue, paginationFilter, closedTickets,payload);
        return response;
    }
        response = await this.getPaginatedTicketHistoryResponse(paginationValue, paginationFilter, filteredSupportDetails, payload);
        return response;
    },

    async getPaginatedTicketHistoryResponse(pagination: PaginationDto, paginationFilter: PaginationDto, arr: any[], payload: any):Promise<FetchTicketHistoryResponseDto>  {
      if(arr.length === 0) {
        pagination.page = 1,
        pagination.pageCount = 1,
        pagination.pageSize = 10,
        pagination.total = 1;
      } else {
        pagination.page = paginationFilter.page;
        pagination.pageSize = paginationFilter.pageSize;
        const pageCount = Math.ceil(arr.length / pagination.pageSize);
        pagination.pageCount = pageCount;
        pagination.total = arr.length;
      }
      const paginatedResponse = await this.paginate(arr, pagination.page, pagination.pageSize);
      return {
        data: paginatedResponse,
        meta: { pagination, filters: payload.filters },
    };
    },

    async getCategoryNameByCategoryId(categoryId: string) {
      const categoryNameList = await strapi.db
        .query("api::category.category")
        .findMany({
          select: ["categoryName"],
          filters: {
            categoryId: categoryId,
          },
        });
      const categoryName = categoryNameList.map(
        (detail) => detail.categoryName
      );
      return categoryName[0];
    },

    async getCategoryName(retailerId: string) {
      const verifiedCategoryNameDetails = await strapi.db
        .query("api::retailer-category.retailer-category")
        .findMany({
          select: ["categoryId"],
          filters: {
            categoryRetailerId: retailerId,
          },
        });
      const categoryIds = verifiedCategoryNameDetails.map(
        (detail) => detail.categoryId
      );
      const verifiedCategoryNames = await strapi.db
        .query("api::category.category")
        .findMany({
          select: ["categoryId", "categoryName"],
          filters: {
            categoryId: categoryIds,
          },
        });
      return verifiedCategoryNames;
    },

    async raiseTicket(retailerId: string, requestBody: raiseTicketRequestDto) {
      //Product Category is only enabled for Product related and channel related support types
      if (
        requestBody.supportType === "Product related" ||
        requestBody.supportType === "Channel related"
      ) {
        if (requestBody.productCategory.length > 0) {
          for (let each of requestBody.productCategory) {
            const insertedRecord = await strapi.service("api::support.support").create({
              data: {
                retailerId: retailerId,
                supportType: requestBody.supportType,
                subType: requestBody.subType,
                productCategory: each,
                marketMaterialType: requestBody.marketMaterialType,
                comments: requestBody.comments,
                ticketCreatedDate: new Date(),
                ticketStatus: "New"
              },
            });
          }
          return {
            status: HttpStatusCode.OK,
            message: "Raised ticket successfully.",
          };
        } else {
          throw {
            status: HttpStatusCode.BAD_REQUEST,
            message: `No Product Category selected.`,
          };
        }
      } else {
        // If channel types are other than Product related and channel related, product category is not mandatory
        const insertedRecord = await strapi.service("api::support.support").create({
          data: {
            retailerId: retailerId,
            supportType: requestBody.supportType,
            subType: requestBody.subType,
            productCategory: requestBody.productCategory[0],
            marketMaterialType: requestBody.marketMaterialType,
            comments: requestBody.comments,
            ticketCreatedDate: new Date(),
            ticketStatus: "New"
          },
        });
        return {
          status: HttpStatusCode.OK,
          message: "Raised ticket successfully.",
        };
      }
    },

    async generateTicketId(insertedRecordId: number) {
    const str: string = "000000";
    const incrementedNumber = parseInt(str) + insertedRecordId;
    const incrementedString = incrementedNumber.toString().padStart(str.length, '0');
    return 'VG' + incrementedString;
    },

    async getSubTypes() {
      const groupSubTypeBySupportType: { [key: string]: string[] } = {};
      const details = await strapi.db
        .query("api::support-type-subtype-mapping.support-type-subtype-mapping")
        .findMany({
          select: ["supportType", "subType"],
        });

      for (const { supportType, subType } of details) {
        if (!groupSubTypeBySupportType[supportType]) {
          groupSubTypeBySupportType[supportType] = [];
        }
        groupSubTypeBySupportType[supportType].push(subType);
      }
      return groupSubTypeBySupportType;
    },

    async getSupportTypeAndMarketMaterialType() {
      const schemaJsonPath = path.join(
        __dirname,
        "../content-types/support/schema.json"
      );
      const schemaJsonString = fs.readFileSync(schemaJsonPath, "utf-8");
      const schemaJson = JSON.parse(schemaJsonString);
      const supportTypeEnums = schemaJson.attributes.supportType.enum;
      const marketMaterialTypeEnums =
        schemaJson.attributes.marketMaterialType.enum;
      return {
        supportTypeEnums: supportTypeEnums,
        marketMaterialTypeEnums: marketMaterialTypeEnums,
      };
    },

    async paginate(array: any[], page: number, pageSize: number) {
      const startIndex = (page - 1) * pageSize;
    return array.slice(startIndex, startIndex + pageSize);
  },    
  })
);
