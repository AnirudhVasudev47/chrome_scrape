/**
 * lead-product service
 */

import { factories } from "@strapi/strapi";

export default factories.createCoreService(
  "api::lead-product.lead-product",
  ({ strapi }) => ({
    async getCategoryByLeadCode(leadCode: string) {
      const leadProduct = await strapi.db
        .query("api::lead-product.lead-product")
        .findOne({ where: { leadCode, productSKU: null, soldProduct: false } });
      if (leadProduct) {
        const leadCategory = await strapi
          .service("api::category.category")
          .getCategoryByCategoryId(leadProduct.categoryId);
        return leadCategory;
      }
      return null;
    },

    async getAssociatedCategoryByLeadId(leadId: string) {
      const leadProduct = await strapi.db
        .query("api::lead-product.lead-product")
        .findOne({ where: { leadId, soldProduct: false } });
      if (!leadProduct) {
        throw new Error("No record found");
      }
      return leadProduct;
    },

    async updateProductByLeadProductCode(leadProductCode: string, payload) {
      await strapi.db.query("api::lead-product.lead-product").update({
        where: {
          leadProductCode,
        },
        data: payload,
      });
    },

    async getProductCategoriesByLeadProductCode(leadProductCode: string) {
      const leadProduct = await strapi.db
        .query("api::lead-product.lead-product")
        .findOne({ where: { leadProductCode } });
      if (leadProduct) {
        const category = await await strapi
          .service("api::category.category")
          .getCategoryByCategoryId(leadProduct.categoryId);
        const subCategory = await await strapi
          .service("api::sub-category.sub-category")
          .getSubCategoryBySubCategoryId(leadProduct.subCategoryId);

        return {
          leadCategory: { categoryName: category.categoryName },
          leadSubCategory: { categoryName: subCategory.subCategoryName },
        };
      }
      return null;
    },
  })
);
