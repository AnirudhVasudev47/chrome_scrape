/**
 * lead-product controller
 */

import { factories } from '@strapi/strapi'

export default factories.createCoreController('api::lead-product.lead-product');
