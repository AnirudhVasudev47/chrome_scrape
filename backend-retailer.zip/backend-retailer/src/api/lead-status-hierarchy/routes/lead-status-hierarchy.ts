/**
 * lead-status-hierarchy router
 */

export default {
  routes: [
    {
      method: "GET",
      path: "/lead-sub-status",
      handler: "lead-status-hierarchy.getLeadSubStatus",
    },
    {
      method: "GET",
      path: "/lead-sub-status2",
      handler: "lead-status-hierarchy.getLeadSubStatus2",
    },
    {
      method: "GET",
      path: "/lead-status-progress/:leadCode",
      handler: "lead-status-hierarchy.getLeadStatusProgress",
    },
  ],
};
