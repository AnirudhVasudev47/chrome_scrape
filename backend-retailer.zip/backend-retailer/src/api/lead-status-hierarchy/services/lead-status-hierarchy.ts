/**
 * lead-status-hierarchy service
 */

import { factories } from "@strapi/strapi";
import { LeadSubStatusEnum, SolarCategory } from "../../../enums";

export default factories.createCoreService(
  "api::lead-status-hierarchy.lead-status-hierarchy",
  ({ strapi }) => ({
    /**
     * Retrieves the sub-statuses for a lead based on the lead code in the request query.
     * @param ctx - The Koa context object representing the HTTP request and response.
     * @returns - An object containing the retrieved sub-status data and metadata.
     */
    async getLeadSubStatus(ctx) {
      // Retrieve the current lead status from the lead status fact table
      const leadStatusFact = await strapi
        .service("api::lead.lead")
        .getCurrentSubStatusByLeadCode(ctx.request.query.leadCode);

      if (leadStatusFact) {
        // Update query filters to fetch sub-statuses based on current sub-status id
        ctx.request.query.filters = {
          parentId: leadStatusFact.subStatusId,
          parentStatus: leadStatusFact.subStatus,
        };

        // Check if current sub-status is SITE_READY and update childStatus filter accordingly
        if (leadStatusFact.subStatus === LeadSubStatusEnum.SITE_READY) {
          const leadCategory = await strapi
            .service("api::lead.lead")
            .getLeadCategoryName(ctx.request.query.leadCode);

          // Set default childStatus filter value
          ctx.request.query.filters.childStatus = LeadSubStatusEnum.QUOTATION;

          // Update childStatus filter based on lead category
          if (leadCategory === SolarCategory.SOLAR_WATER_HEATER) {
            ctx.request.query["filters"]["childStatus"] =
              LeadSubStatusEnum.WATER_TESTING_SWH;
          }
        }
        const { results, meta } = await strapi
          .service("api::lead-status-hierarchy.lead-status-hierarchy")
          .find(ctx.request.query);
        return { data: results, meta };
      }
      return { data: [] };
    },

    async getStatusDetailsByName(parentStatus: string) {
      const status = await strapi.db
        .query("api::lead-status-hierarchy.lead-status-hierarchy")
        .findOne({
          select: ["parentId", "parentStatus", "isPositive"],
          where: { parentStatus },
        });

      if (!status) {
        throw new Error("Error while fetching the status");
      }
      return status;
    },

    async getStatusDetailsByChildStatus(childStatus: string) {
      const status = await strapi.db
        .query("api::lead-status-hierarchy.lead-status-hierarchy")
        .findOne({
          select: ["childId", "childStatus"],
          where: { childStatus },
        });

      if (!status) {
        throw new Error("Error while fetching the status");
      }
      return status;
    },

    async getPositiveStatusList() {
      const statusHierarchy = await strapi.db
        .query("api::lead-status-hierarchy.lead-status-hierarchy")
        .findMany({
          where: { isPositive: true },
          orderBy: { parentId: "asc" },
        });
      return statusHierarchy;
    },

    async retrieveSubstatusBasedOnAssignmentFlow(leadCode: string) {
      // Determines the lead category based on the lead code
      const leadCategory = await strapi
        .service("api::lead.lead")
        .getLeadCategoryName(leadCode);

      // Sets the category based on lead category
      const category =
        leadCategory === SolarCategory.SOLAR_WATER_HEATER
          ? LeadSubStatusEnum.WATER_TESTING_SWH
          : LeadSubStatusEnum.QUOTATION;
      return category;
    },

    /**
     * Retrieves the progress of lead status based on the lead code.
     * @param leadCode - The lead code of particular lead.
     * @returns - Array containing sub-status and date of progression.
     */
    async getLeadStatusProgress(leadCode: string) {
      // Fetches the positive status hierarchy
      const statusHierarchy = await this.getPositiveStatusList();

      const leadSubStatus = await this.retrieveSubstatusBasedOnAssignmentFlow(
        leadCode
      );

      // Retrieves the positive flow sequence based on the lead status
      const positiveFlowSequence = this.getSpecificPositiveFlowSequence(
        statusHierarchy,
        LeadSubStatusEnum.NEW_LEAD_ASSIGNED,
        leadSubStatus
      );

      const leadStatusHistory = await strapi
        .service("api::lead-status-history.lead-status-history")
        .getStatusHistoryByLeadCode(leadCode);

      const leadStatusProgress = [];

      for (const statusItem of positiveFlowSequence) {
        const latestSiteSurvey = this.findLatestEntryBySubStatus(
          leadStatusHistory,
          statusItem.childStatus
        );

        leadStatusProgress.push({
          subStatus: statusItem.childStatus,
          date: latestSiteSurvey?.createdDate || null,
        });
      }

      return { data: leadStatusProgress };
    },

    /**
     * Retrieves the positive flow sequence based on the selected status and condition.
     * @param statusHierarchy - The positive status hierarchy.
     * @param selectedSubStatus - The selected sub-status.
     * @param condition - The condition to check for whether the lead category is SWH or SPS
     * @returns - Positive flow sequence.
     */
    getSpecificPositiveFlowSequence(
      statusHierarchy,
      selectedSubStatus: string,
      condition: string
    ) {
      const sequence = [];
      // Object to keep track of the current sub-status and its ID
      let currentSubStatus = { name: selectedSubStatus, id: 1 }; // Iterates through the status hierarchy to construct the positive flow sequence
      while (currentSubStatus.name) {
        // Finds the child status based on the current sub-status and ID
        const childStatus = statusHierarchy.find(
          (status) =>
            status.parentStatus === currentSubStatus.name &&
            status.parentId === currentSubStatus.id &&
            status.isPositive
        );

        // If child status is found
        if (childStatus) {
          // If the current sub-status is "SITE_READY" and the condition matches
          if (
            currentSubStatus.name === LeadSubStatusEnum.SITE_READY &&
            condition !== LeadSubStatusEnum.SITE_READY
          ) {
            // Finds the child status based on the condition
            const conditionChild = statusHierarchy.find(
              (status) =>
                status.parentStatus === LeadSubStatusEnum.SITE_READY &&
                status.isPositive &&
                status.childStatus === condition
            );

            // Updates the current sub-status and its ID with the condition
            currentSubStatus.name = condition;
            currentSubStatus.id = conditionChild.childId;
          } else {
            // Updates the current sub-status and its ID with the child status
            currentSubStatus.name = childStatus.childStatus;
            currentSubStatus.id = childStatus.childId;

            // Pushes the child status to the sequence
            sequence.push({ childStatus: childStatus.childStatus });
          }
        } else {
          // Breaks the loop if child status is not found
          break;
        }
      }

      return sequence;
    },

    /**
     * Finds the latest entry in the history array with the specified subStatus.
     * @param history - The array containing the history of lead status entries.
     * @param subStatus - The subStatus to filter the history by.
     * @returns - The latest entry with the specified subStatus or null if not found.
     */
    findLatestEntryBySubStatus(history, subStatus: string) {
      // Filter the history array to include only items with the specified subStatus
      const filteredHistory = history.filter(
        (item) => item.subStatus === subStatus
      );

      // Sort the filtered array by the createdDate in descending order
      filteredHistory.sort((a, b) => {
        if (a.createdDate === null) return 1;
        if (b.createdDate === null) return -1;
        return (
          new Date(b.createdDate)?.getTime() -
          new Date(a.createdDate)?.getTime()
        );
      });

      // Pick the item with the greatest date
      return filteredHistory[0];
    },
  })
);
