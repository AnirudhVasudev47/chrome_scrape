/**
 * lead-status-hierarchy controller
 */

import { factories } from "@strapi/strapi";

export default factories.createCoreController(
  "api::lead-status-hierarchy.lead-status-hierarchy",
  ({ strapi }) => ({
    async getLeadSubStatus(ctx) {
      const statusList = await strapi
        .service("api::lead-status-hierarchy.lead-status-hierarchy")
        .getLeadSubStatus(ctx);
      return statusList;
    },

    async getLeadSubStatus2(ctx) {
      const { data, meta } = await super.find(ctx);
      return { data, meta };
    },

    async getLeadStatusProgress(ctx) {
      const leadProgress = await strapi
        .service("api::lead-status-hierarchy.lead-status-hierarchy")
        .getLeadStatusProgress(ctx.request.params.leadCode);
      return leadProgress;
    },
  })
);
