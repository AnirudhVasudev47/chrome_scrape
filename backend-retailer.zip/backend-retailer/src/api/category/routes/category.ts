export default {
  routes: [
    {
      method: "GET",
      path: "/categories",
      handler: "category.find",
    },
    {
      method: "GET",
      path: "/categories/solar",
      handler: "category.getSolarCategories",
    },
    {
      method: "GET",
      path: "/categories/list",
      handler: "category.getAllCategories",
    },
  ],
};
