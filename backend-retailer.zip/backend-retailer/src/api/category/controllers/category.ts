/**
 * category controller
 */

import { factories } from "@strapi/strapi";
import { solarCategorySapCode } from "../../../constants";

export default factories.createCoreController(
  "api::category.category",
  ({ strapi }) => ({
    async find(ctx, categoryId) {
      ctx.request.query = {
        filters: {
          categoryId: {
            $in: categoryId,
          },
        },
        fields: ["categoryName", "categoryId"],
      };
      let { data } = await super.find(ctx);
      const categoryData: any = {};
      data.forEach((e) => {
        categoryData[e.attributes.categoryId] = e.attributes.categoryName;
      });
      return categoryData;
    },

    async getSolarCategories(ctx) {
      ctx.request.query = {
        filters: { sapDivisionCode: solarCategorySapCode }, // to fetch the solar categories only based on sapDivisionCode
        fields: ["categoryId", "categoryName"],
      };
      const { data, meta } = await super.find(ctx);
      return { data, meta };
    },

    async getAllCategories(ctx) {
      const { data, meta } = await super.find(ctx);
      return { data, meta };
    },
  })
);
