/**
 * category service
 */

import { factories } from "@strapi/strapi";

export default factories.createCoreService(
  "api::category.category",
  ({ strapi }) => ({
    async getCategoryByCategoryId(categoryId: string) {
      const category = await strapi.db
        .query("api::category.category")
        .findOne({ where: { categoryId } });
      return category;
    },
    async getCategoryBycategoryIds(categoryIds){
      const categoryDetails = await strapi.db
      .query("api::category.category")
      .findMany({
        select: ["categoryName", "categoryId"],
        filters: {
          categoryId: categoryIds,
        },
      });
    return categoryDetails;
    }
  })
);
