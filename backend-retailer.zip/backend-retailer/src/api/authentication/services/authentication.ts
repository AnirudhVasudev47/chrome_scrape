/**
 * authentication service
 */

import { RESPONSE_MESSAGE } from "../../../constants";
import {
  HttpStatusCode,
  OTPPurposeEnum,
  UserActivationStatusEnum,
  UserRole,
  UserType,
} from "../../../enums";
import { decrypt, encrypt } from "../../../utils/encryptionDecryption";
import crypto from "crypto";

const locale = "en";

module.exports = {
  /**
   * Generates a six-digit OTP.
   * @returns The generated OTP.
   */
  generateOTP() {
    const array = new Uint32Array(1);
    crypto.getRandomValues(array);
    const tenDigitNumber = array[0];
    const sixDigitOTP = String(tenDigitNumber).slice(0, 6);
    return sixDigitOTP;
  },

  /**
   * Creates or updates the OTP record for the given user ID.
   * @param userId - The ID of the user.
   * @param payload - The payload containing OTP code and expiry time.
   * @param payload.otpCode - The OTP code.
   * @param payload.otpExpiryTime - The expiry time of the OTP.
   * @returns The created or updated OTP details.
   */
  async createOrUpdateOTP(
    userId: number,
    payload: { otpCode: number; otpExpiryTime: Date }
  ) {
    const checkIfRecordExists = await strapi.db
      .query("api::otp.otp")
      .findOne({ where: { userId } });

    let otpDetails = null;
    if (checkIfRecordExists) {
      otpDetails = await strapi.db.query("api::otp.otp").update({
        where: { userId },
        data: payload,
      });
    } else {
      otpDetails = await strapi.db.query("api::otp.otp").create({
        data: {
          ...{ userId },
          ...payload,
        },
      });
    }

    return otpDetails;
  },

  /**
   * Method for fetching the role from DB based on the roleName
   * @param name - role name coming from enum
   * @returns
   */
  async getRoleByName(name: String) {
    const role = await strapi.db
      .query("plugin::users-permissions.role")
      .findOne({ where: { name } });
    if (!role) {
      throw {
        status: HttpStatusCode.NOT_FOUND,
        message: RESPONSE_MESSAGE[locale].ROLE_NOT_FOUND,
      };
    }
    return role;
  },

  /**
   * Fetch user from primary table if exists return the user object else return null
   * @param mobileNumber
   * @returns
   */
  async findAndFetchPrimaryUser(mobileNumber: number) {
    const primaryUser = await strapi.db
      .query("api::primaryuser.primaryuser")
      .findOne({
        where: { mobileNumber },
        populate: {
          userId: true,
        },
      });
    if (!primaryUser) return null;
    return primaryUser;
  },

  /**
   * Fetch user from secondary table if exists return the user object else return null
   * @param mobileNumber
   * @returns
   */
  async fetchSecondaryUser(mobileNumber: number) {
    const secondaryUser = await strapi.db
      .query("api::secondaryuser.secondaryuser")
      .findOne({
        where: { mobileNumber },
        populate: {
          userId: true,
          parentId: true,
        },
      });
    if (!secondaryUser) return null;
    return secondaryUser;
  },

  /**
   * Mapping created userId with primary/secondary user table | mapping requires for authentication
   * @param tableName - contains the table - [Primary/Secondary]
   * @param id - id consisting the PK of primaryuser table or secondaryuser table
   * @param userId - created user id, need to be map with the primaary/secondary user table
   * @returns
   */
  async updateCurrentUserWithUserId(
    tableName: string,
    id: number,
    userId: number
  ) {
    await strapi.db
      .query(tableName)
      .update({ where: { id }, data: { userId } });
  },

  /**
   * Method for creating the records in user table if primary/secondary user aren't mapped with user table
   * @param user - contains user object from either primaryuser/secondaryuser table
   * @param userRole - contains role - [Primary/Secondary]
   * @returns - return the id (user table PK)
   */
  async findOrCreateUserWithRole(user, userRole: UserRole) {
    if (!user.userId) {
      /**
       * If userId is not mapped with user table,
       * Map and create a new user with the provided data and assign it to the Primary/Secondary role
       */
      const role = await this.getRoleByName(userRole);
      const createdUser = await strapi.db
        .query("plugin::users-permissions.user")
        .create({
          data: {
            username: user.mobileNumber,
            email: user.email || "temp@email.com", // not used/required
            password: crypto // not used/required
              .getRandomValues(new BigUint64Array(1))[0]
              .toString(36),
            role: role.id,
          },
        });
      // Update the primary/secondary user object with the newly generated user(id)
      await this.updateCurrentUserWithUserId(
        userRole === UserRole.PRIMARY_USER
          ? "api::primaryuser.primaryuser"
          : "api::secondaryuser.secondaryuser",
        user.id,
        createdUser.id
      );
      return createdUser.id;
    }
    return user.userId.id;
  },

  /**
   * Checking if user exists then process the find method and check if userId is mapped with primary/secondary user table or not
   * if user not exists throw error
   * @param mobileNumber
   * @returns
   */
  async isUserExist(mobileNumber: number) {
    const primaryUser = await this.findAndFetchPrimaryUser(mobileNumber);
    if (!primaryUser) {
      const secondaryUser = await this.fetchSecondaryUser(mobileNumber);
      if (!secondaryUser) {
        throw {
          status: HttpStatusCode.NOT_FOUND,
          message: RESPONSE_MESSAGE[locale].MOBILE_NUMBER_NOT_REGISTER,
        };
      }
      secondaryUser.userId = await this.findOrCreateUserWithRole(
        secondaryUser,
        UserRole.SECONDARY_USER
      );
      return secondaryUser;
    }
    primaryUser.userId = await this.findOrCreateUserWithRole(
      primaryUser,
      UserRole.PRIMARY_USER
    );
    return primaryUser;
  },

  /**
   * Check if user exceeded the threshold or not by checking the OTP attempts
   * @param userId - getting the records with mapping userId (FK | user table)
   */
  async isExceedingThresholdForSendOTP(userId: Number) {
    const otpDetails = await strapi.db.query("api::otp.otp").findOne({
      select: [
        "verifyOtpFailureCount",
        "verifyFailedAt",
        "resendOtpCount",
        "resendOtpFailedAt",
      ],
      where: { userId },
    });
    if (otpDetails) {
      const updatedFailureCount = (otpDetails.resendOtpCount || 0) + 1;
      const currentFailureTime = new Date();
      // Update OTPSentCount in the table if account is not locked
      if (updatedFailureCount <= 5) {
        await strapi.db.query("api::otp.otp").update({
          where: { userId },
          data: {
            resendOtpCount: updatedFailureCount,
            resendOtpFailedAt: currentFailureTime,
          },
        });
      }
      // If the account has been locked due to a verify failure
      await this.checkVerifyOtpMaxAttempts(otpDetails);
      // If the account has been locked due to resend otp maximun attempts
      await this.checkResendOtpMaxAttempts(otpDetails);
    }
    return true;
  },

  /**
   * Function to generate the OTP and encrypt the OTP
   * and save the encrypted OTP with key encryption
   * @param userId
   * @param deviceId - saving the deviceId for multiple login
   * @returns - return the generated OTP
   */
  async generateAndSaveOTPToDB(userId: number, deviceId: string) {
    // generateOTP
    const otp = this.generateOTP();
    // Get the current date and time and add otp expiry time(xx min from env) in current time
    const currentTime = new Date();
    const otpExpiryTime = new Date(
      currentTime.getTime() + Number(process.env.OTP_EXPIRES) * 60000
    );
    const { encrypted, iv, key } = encrypt(
      otp,
      process.env.ENCRYPTION_PASSWORD
    );
    const updatedOtp = this.createOrUpdateOTP(userId, {
      otpCode: encrypted,
      otpExpiryTime,
      deviceId,
      otpPurpose: OTPPurposeEnum.LOGIN,
      keyEncryption: key,
      ivString: iv,
    });
    if (!updatedOtp) {
      throw {
        status: HttpStatusCode.INTERNAL_SERVER,
        message: RESPONSE_MESSAGE[locale].ERROR_GENERATING_OTP,
      };
    }
    return otp;
  },

  /**
   * Service method to send OTP to a given mobile number.
   * @param mobileNumber - The mobile number to which OTP will be sent
   * @param deviceId - Device ID for tracking
   * @returns - Object containing status, message, and OTP if sent successfully.
   */
  async sendOTP(mobileNumber: number, deviceId = "") {
    try {
      // userExists
      const user = await this.isUserExist(mobileNumber);
      // isUserBlocked
      await this.checkAndUnblockAccount(user.userId);
      // check if threshold exceeded, if not update the OTPSentCount
      await this.isExceedingThresholdForSendOTP(user.userId);
      // generateAndSaveOTP to table
      const otp = await this.generateAndSaveOTPToDB(user.userId, deviceId);

      // trigger the sms notification-service for sending the OTP
      if (process.env.NODE_ENV === "production") {
        await strapi
          .service("api::notification-service.notification-service")
          .sendOtp({ mobileNumber, otp });
      }

      return {
        status: HttpStatusCode.CREATED,
        message: RESPONSE_MESSAGE[locale].OTP_SENT,
        ...(process.env.NODE_ENV !== "production" && { otp }),
        resendBlockDurationSeconds:
          process.env.RESEND_API_BLOCK_DURATION_SECONDS,
      };
    } catch (error) {
      console.log("Error while sending OTP", error);
      throw error;
    }
  },

  /**
   * Generates a refresh token for the provided user.
   * @param user The user object for which the refresh token is generated.
   * @param expiresIn The expiration time for the refresh token.
   * @returns The generated refresh token.
   */
  generateRefreshToken(user, expiresIn = process.env.REFRESH_TOKEN_EXPIRES) {
    return strapi.plugins["users-permissions"].services.jwt.issue(
      {
        tokenVersion: user.tokenVersion,
      },
      {
        subject: user.id.toString(),
        expiresIn,
      }
    );
  },

  /**
   * Generates an access token for the provided user.
   * @param user The user object for which the access token is generated.
   * @returns The generated access token.
   */
  generateAccessToken(user) {
    return strapi.plugins["users-permissions"].services.jwt.issue(
      {
        id: user.id,
      },
      {
        expiresIn: process.env.JWT_TOKEN_EXPIRES,
      }
    );
  },

  /**
   * Checks if the OTP has expired based on the provided expiry time.
   * @param otpExpiryTime The expiry time of the OTP.
   * @returns True if the OTP has expired, otherwise false.
   */
  isOtpExpired(otpExpiryTime: Date) {
    const currentDate = new Date();
    const expiryTime = new Date(otpExpiryTime);
    return currentDate > expiryTime;
  },

  /**
   * Determines the user type based on the provided user object.
   * @param user The user object for which the type is determined.
   * @returns The type of user (primary or secondary).
   */
  getUserType(user) {
    let userType = UserType.SECONDARY;
    if (user.retailerId) {
      userType = UserType.PRIMARY;
    }
    return userType;
  },

  /**
   * Checks if the maximum resend OTP attempts have been exceeded and if the account should be locked.
   * @param otpDetails The OTP details containing resend attempt information.
   * @returns True if the resend attempts are within limits, otherwise throws an error.
   */
  async checkResendOtpMaxAttempts(otpDetails) {
    const minutesSinceLastResendFailure = this.getDifferenceMinutes(
      otpDetails.resendOtpFailedAt,
      new Date()
    );

    if (
      otpDetails.resendOtpCount >= 4 &&
      minutesSinceLastResendFailure < Number(process.env.ACCOUNT_LOCKED_PERIOD)
    ) {
      throw {
        status: HttpStatusCode.FORBIDDEN,
        title: RESPONSE_MESSAGE[locale].ACCOUNT_LOCKED_TITLE,
        message: RESPONSE_MESSAGE[locale].ACCOUNT_LOCKED_BY_RESEND_FAILURE,
      };
    }

    if (otpDetails.resendOtpCount >= 3) {
      throw {
        status: HttpStatusCode.FORBIDDEN,
        title: RESPONSE_MESSAGE[locale].FAILURE_ATTEMPT_EXHAUSTED_TITLE,
        message: RESPONSE_MESSAGE[locale].FAILURE_ATTEMPT_BY_RESEND_FAILURE,
      };
    }

    return true;
  },

  /**
   * Checks if the maximum verify OTP attempts have been exceeded and if the account should be locked.
   * @param otpDetails The OTP details containing verify attempt information.
   * @returns True if the verify attempts are within limits, otherwise throws an error.
   */
  async checkVerifyOtpMaxAttempts(otpDetails) {
    const minutesSinceLastVerifyFailure = this.getDifferenceMinutes(
      otpDetails.verifyFailedAt,
      new Date()
    );

    if (
      otpDetails.verifyOtpFailureCount >= 4 &&
      minutesSinceLastVerifyFailure < Number(process.env.ACCOUNT_LOCKED_PERIOD)
    ) {
      throw {
        status: HttpStatusCode.FORBIDDEN,
        title: RESPONSE_MESSAGE[locale].ACCOUNT_LOCKED_TITLE,
        message: RESPONSE_MESSAGE[locale].ACCOUNT_LOCKED_DESC,
      };
    }

    // Check if attempts exhausted
    if (otpDetails.verifyOtpFailureCount >= 3) {
      throw {
        status: HttpStatusCode.FORBIDDEN,
        title: RESPONSE_MESSAGE[locale].FAILURE_ATTEMPT_EXHAUSTED_TITLE,
        message: RESPONSE_MESSAGE[locale].FAILURE_ATTEMPT_EXHAUSTED_DESC,
      };
    }

    return true;
  },

  /**
   * Generates access and refresh tokens for the provided user.
   * @param user The user object for which tokens are generated.
   * @returns An object containing the access and refresh tokens.
   */
  generateTokens(user) {
    const accessToken = this.generateAccessToken(user);
    const refreshToken = this.generateRefreshToken(user);
    return { accessToken, refreshToken };
  },

  /**
   * Service method to check and unblock the user account if it was previously blocked.
   * @param userId - The ID of the user account to check and unblock.
   * @param isVerifyOTP - Flag to indicate if this function is called during OTP verification.
   * @returns - Object containing OTP details if found, or null if OTP details not found and isVerifyOTP is false.
   * @throws - Throws an error if OTP details not found and isVerifyOTP is true.
   */
  async checkAndUnblockAccount(userId: Number, isVerifyOTP = false) {
    const otpDetails = await strapi.db.query("api::otp.otp").findOne({
      where: { userId },
    });
    // send null value when sendOTP calls this function to avoid throwing error, as user might perform firsttime login
    if (!isVerifyOTP && !otpDetails) return null;
    if (!otpDetails) {
      throw {
        status: HttpStatusCode.NOT_FOUND,
        message: RESPONSE_MESSAGE[locale].ERROR_VERIFYING_OTP,
      };
    }
    // Calculate the difference in milliseconds for 24 hours
    const currentTime = new Date();
    const accountLockThresholdTimestamp = new Date(
      currentTime.getTime() -
        Number(process.env.ACCOUNT_LOCKED_PERIOD) * 60 * 1000
    );
    // Check if either verifyFailedAt or resendOtpFailedAt is more than 24 hours ago
    if (
      new Date(otpDetails.verifyFailedAt) < accountLockThresholdTimestamp ||
      new Date(otpDetails.resendOtpFailedAt) < accountLockThresholdTimestamp
    ) {
      // Reset the values to the current time
      otpDetails.verifyFailedAt = currentTime;
      otpDetails.resendOtpFailedAt = currentTime;
      otpDetails.verifyOtpFailureCount = 0;
      otpDetails.resendOtpCount = 0;
      // Update the database with the new values
      await strapi.db.query("api::otp.otp").update({
        where: { userId },
        data: {
          verifyOtpFailureCount: 0,
          verifyFailedAt: currentTime,
          resendOtpCount: 0,
          resendOtpFailedAt: currentTime,
        },
      });
    }
    return otpDetails;
  },

  /**
   * Check if user exceeded the threshold or not by checking the wrong  OTP attempts count and last attempt timestamp
   * @param otpDetails - otp record of the  user from the database
   * @param userId - getting the records with mapping userId (FK | user table)
   * @param otp -  The provided One Time Password from payload
   * @returns
   */
  async isExceedingThresholdForVerifyOTP(
    otpDetails,
    userId: Number,
    otp: Number
  ) {
    const decryptedOTP = decrypt(
      otpDetails?.otpCode,
      otpDetails?.ivString,
      otpDetails?.keyEncryption
    );

    if (otp !== Number(decryptedOTP)) {
      const updatedFailureCount = (otpDetails?.verifyOtpFailureCount || 0) + 1;
      const currentFailureTime = new Date();
      // Update verifyOtpFailureCount in the table if account is not locked
      if (updatedFailureCount < 5) {
        await strapi.db.query("api::otp.otp").update({
          where: { userId },
          data: {
            verifyOtpFailureCount: updatedFailureCount,
            verifyFailedAt: currentFailureTime,
          },
        });
      }
      // If the account has been locked due to resend otp maximun attempts
      await this.checkResendOtpMaxAttempts(otpDetails);
      // If the account has been locked due to a verify failure
      await this.checkVerifyOtpMaxAttempts(otpDetails);
      throw {
        status: HttpStatusCode.NOT_FOUND,
        message: RESPONSE_MESSAGE[locale].OTP_NOT_MATCHED,
      };
    }

    if (this.isOtpExpired(otpDetails.otpExpiryTime)) {
      throw {
        status: HttpStatusCode.UNAUTHORIZED,
        message: RESPONSE_MESSAGE[locale].OTP_EXPIRED,
      };
    }

    return otpDetails;
  },

  /**
   * to reset the failure counts in OTP table
   * @param userId
   */
  async resetFailureCounts(userId: number) {
    await strapi.db.query("api::otp.otp").update({
      where: { userId },
      data: {
        verifyOtpFailureCount: 0,
        verifyFailedAt: null,
        resendOtpCount: 0,
        resendOtpFailedAt: null,
      },
    });
  },

  /**
   * Updates the activation status of the primary or secondary user based on their current status.
   * If the user's activation status is 'INVITATION_SENT', it updates it to 'LOGGED_IN'.
   * @param primaryOrSecondaryUser The primary or secondary user object whose activation status needs to be updated.
   */
  async updateUserActivationStatus(primaryOrSecondaryUser) {
    // Check if the activation status is 'INVITATION_SENT'
    if (
      primaryOrSecondaryUser.activationStatus ===
      UserActivationStatusEnum.INVITATION_SENT
    ) {
      let table = "api::primaryuser.primaryuser";
      if (this.getUserType(primaryOrSecondaryUser) === UserType.SECONDARY) {
        table = "api::secondaryuser.secondaryuser";
      }
      return await strapi.db.query(table).update({
        where: { id: primaryOrSecondaryUser.id },
        data: { activationStatus: UserActivationStatusEnum.LOGGED_IN },
      });
    }
    return primaryOrSecondaryUser;
  },

  /**
   * Generates access and refresh tokens for the given user and constructs the response object.
   * @param primaryOrSecondaryUser The user object retrieved from the database.
   * @returns An object containing the status, message, access token, refresh token, user ID, user type, retailer ID, and parent ID.
   */
  async generateTokenAndResponse(
    primaryOrSecondaryUser,
    accessToken,
    refreshToken,
    activationStatus: string
  ) {
    return {
      status: HttpStatusCode.CREATED,
      message: RESPONSE_MESSAGE[locale].SUCCESS,
      accessToken,
      refreshToken,
      id: primaryOrSecondaryUser.id,
      userType: this.getUserType(primaryOrSecondaryUser),
      profilePhoto: primaryOrSecondaryUser.profilePhoto,
      // sending the primaryUser data in success response
      ...(primaryOrSecondaryUser.retailerId && {
        retailerId: primaryOrSecondaryUser.retailerId,
      }),
      ...(primaryOrSecondaryUser.retailerName && {
        retailerName: primaryOrSecondaryUser.retailerName,
      }),
      ...(primaryOrSecondaryUser.storeName && {
        storeName: primaryOrSecondaryUser.storeName,
      }),
      // to send the secondaryUser data in success response
      ...(primaryOrSecondaryUser.name && {
        seondaryUserName: primaryOrSecondaryUser.name,
      }),
      ...(primaryOrSecondaryUser.parentId?.retailerId && {
        parentId: primaryOrSecondaryUser.parentId?.retailerId,
      }),
      activationStatus,
    };
  },

  /**
   * Verifies the OTP provided by the user.
   * @param payload An object containing the user's mobile number and OTP.
   * @returns An object containing the status, message, access token, refresh token, user ID, user type, retailer ID, and parent ID upon successful verification.
   * @throws An error if OTP verification fails or an error occurs during the process.
   */
  async verifyOTP(payload: { mobileNumber: number; otp: number }) {
    const { mobileNumber, otp } = payload;
    try {
      const primaryOrSecondaryUser = await this.isUserExist(mobileNumber);
      // Reset and update the failuteTime if failureTime difference is more than 24 hours
      const otpDetails = await this.checkAndUnblockAccount(
        primaryOrSecondaryUser.userId,
        true
      );
      // check if threshold exceeded, if not update the verifyOTPFailureCount
      await this.isExceedingThresholdForVerifyOTP(
        otpDetails,
        primaryOrSecondaryUser.userId,
        otp
      );
      // reset the failure count when all check pass
      await this.resetFailureCounts(primaryOrSecondaryUser.userId);
      // Update the user activation status
      const updatedUser = await this.updateUserActivationStatus(
        primaryOrSecondaryUser
      );
      // fetch the user details, generate the access/refresh token and map the user id when issuing the token
      const userDetails = await this.fetchUserById(
        primaryOrSecondaryUser.userId
      );
      const { accessToken, refreshToken } = this.generateTokens(userDetails);
      // generate the accessToken, refreshToken and response object
      const response = await this.generateTokenAndResponse(
        updatedUser,
        accessToken,
        refreshToken,
        primaryOrSecondaryUser.activationStatus
      );
      return response;
    } catch (err) {
      console.log("Error in verify OTP", err);
      throw err;
    }
  },

  /**
   * Calculates the difference in minutes between two given timestamps.
   * @param previousTime - The previous timestamp.
   * @param currentTime - The current timestamp.
   * @returns - The difference in minutes between the two timestamps.
   */
  getDifferenceMinutes(previousTime, currentTime) {
    const previousTimeDate =
      typeof previousTime === "string" ? new Date(previousTime) : previousTime;

    const timeDiffMillis = currentTime - previousTimeDate;
    return Math.floor(timeDiffMillis / (1000 * 60));
  },

  /**
   * Verifies the refresh token and extracts necessary information.
   * @param refreshToken - The refresh token to be verified.
   * @returns - An object containing the token version, expiry time, and subject ID.
   */
  async verifyRefreshToken(refreshToken: string) {
    // Verify the refresh token and retrieve token information
    return await strapi.plugins["users-permissions"].services.jwt.verify(
      refreshToken
    );
  },

  /**
   * Checks if the refresh token has expired.
   * @param  exp - The expiry time of the refresh token.
   * @throws  - Throws an error if the refresh token has expired.
   */
  checkRefreshTokenExpiration(exp: number) {
    // Check if the refresh token has expired
    if (Date.now() / 1000 > exp) {
      throw {
        status: HttpStatusCode.UNAUTHORIZED,
        message: RESPONSE_MESSAGE[locale].REFRESH_TOKEN_EXPIRED,
      };
    }
  },

  /**
   * Fetches user information based on the provided subject ID.
   * @param id - The subject ID extracted from the refresh token.
   * @returns - The user information fetched from the database.
   */
  async fetchUserById(id: number) {
    // Fetch user details from the database using the subject ID
    return await strapi.db
      .query("plugin::users-permissions.user")
      .findOne({ where: { id } });
  },

  /**
   * Checks if the token version in the database matches the one in the refresh token.
   * This will ensure that the refresh token hasn't been made invalid by a password change or similar.
   * @param tokenVersion - The token version extracted from the refresh token.
   * @param user - The user object fetched from the database.
   * @throws - Throws an error if the token version does not match.
   */
  checkTokenVersionMatch(tokenVersion: number, user) {
    // Check if the token version in the database matches the one in the refresh token
    if (tokenVersion !== user.tokenVersion) {
      throw {
        status: HttpStatusCode.UNAUTHORIZED,
        message: RESPONSE_MESSAGE[locale].INVALID_REFRESH_TOKEN,
      };
    }
  },

  /**
   * Updates the token version for the user in the database.
   * @param userId - The ID of the user whose token version needs to be updated.
   * @param user - The user object fetched from the database.
   * @returns - The updated user object.
   */
  async updateUserTokenVersion(userId: number, user) {
    // Update the user's token version in the database
    return await strapi.db.query("plugin::users-permissions.user").update({
      where: { id: userId },
      data: { tokenVersion: user.tokenVersion + 1 },
    });
  },

  /**
   * Calculates the remaining expiry time of the JWT token in seconds.
   * @param exp - The expiry time of the refresh token.
   * @returns - The remaining expiry time in seconds.
   */
  calculateRemainingExpiryTime(exp: number) {
    // Calculate the remaining JWT expiry time in seconds
    return Math.round(Math.max(0, exp - Date.now() / 1000));
  },

  /**
   * Verifies the refresh token and retrieves user information.
   * @param refreshToken - The refresh token to be verified.
   * @returns - An object containing the access token, refresh token, and success message.
   */
  async refreshToken(refreshToken: string) {
    try {
      // Verify the refresh token and extract necessary information
      const { tokenVersion, exp, sub } = await this.verifyRefreshToken(
        refreshToken
      );
      // Check if the refresh token has expired
      this.checkRefreshTokenExpiration(exp);
      // Fetch user based on the subject ID extracted from the token
      const user = await this.fetchUserById(sub);
      // Check if the token version in the database matches the one in the refresh token
      this.checkTokenVersionMatch(tokenVersion, user);
      // Update the user's token version in the database
      const updatedUser = await this.updateUserTokenVersion(sub, user);
      // Calculate the remaining JWT expiry time in seconds
      const remainingTimeSeconds = this.calculateRemainingExpiryTime(exp);
      // Return the success response with the new tokens
      return {
        status: HttpStatusCode.CREATED,
        message: RESPONSE_MESSAGE[locale].SUCCESS,
        accessToken: this.generateAccessToken(user),
        refreshToken: this.generateRefreshToken(
          updatedUser,
          String(remainingTimeSeconds) + "s"
        ),
      };
    } catch (error) {
      console.log("Error while generating tokens:", error);
      throw new Error(RESPONSE_MESSAGE[locale].INVALID_TOKEN);
    }
  },
};
