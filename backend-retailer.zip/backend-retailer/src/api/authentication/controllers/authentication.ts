/**
 * A set of functions called "actions" for `authentication`
 */

import { HttpStatusCode } from "../../../enums";
import { SendOTPSchema, VerifyOTPSchema } from "../../../validation";

module.exports = {
  async sendOTP(ctx) {
    try {
      await SendOTPSchema.validate(ctx.request.body, {
        stripUnknown: true,
        abortEarly: false,
      });

      const { status = HttpStatusCode.OK, ...rest } = await strapi
        .service("api::authentication.authentication")
        .sendOTP(
          ctx.request.body.mobileNumber,
          ctx.request.headers["device-id"] || ""
        );

      ctx.send(
        {
          ...rest,
        },
        status
      );
    } catch (error) {
      const { status = HttpStatusCode.BAD_REQUEST, ...rest } = error;
      ctx.send(
        {
          ...rest,
        },
        status
      );
    }
  },

  async verifyOTP(ctx) {
    try {
      await VerifyOTPSchema.validate(ctx.request.body, {
        stripUnknown: true,
        abortEarly: false,
      });

      const { status = HttpStatusCode.OK, ...rest } = await strapi
        .service("api::authentication.authentication")
        .verifyOTP(ctx.request.body);

      ctx.send(
        {
          ...rest,
        },
        status
      );
    } catch (error) {
      const { status = HttpStatusCode.BAD_REQUEST, ...rest } = error;
      ctx.send(
        {
          ...rest,
        },
        status
      );
    }
  },

  async refreshToken(ctx) {
    try {
      /**
       * Params should consist of:
       * token - string - jwt refresh token
       */
      const { status = HttpStatusCode.OK, ...rest } = await strapi
        .service("api::authentication.authentication")
        .refreshToken(ctx.request.body.token);

      ctx.send(
        {
          ...rest,
        },
        status
      );
    } catch (error) {
      const { status = HttpStatusCode.BAD_REQUEST, ...rest } = error;
      ctx.send(
        {
          ...rest,
        },
        status
      );
    }
  },
};
