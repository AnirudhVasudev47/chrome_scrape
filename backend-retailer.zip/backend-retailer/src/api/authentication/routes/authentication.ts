export default {
  routes: [
    {
      method: "POST",
      path: "/authentication/sendOTP",
      handler: "authentication.sendOTP",
      config: {
        policies: [],
        middlewares: [],
      },
    },
    {
      method: "POST",
      path: "/authentication/verifyOTP",
      handler: "authentication.verifyOTP",
      config: {
        policies: [],
        middlewares: [],
      },
    },
    {
      method: "POST",
      path: "/authentication/refreshToken",
      handler: "authentication.refreshToken",
      config: {
        policies: [],
        middlewares: [],
      },
    },
  ],
};
