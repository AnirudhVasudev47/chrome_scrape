/**
 * secondary-scheme-membership service
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreService('api::secondary-scheme-membership.secondary-scheme-membership',
({strapi}) => ({
    async getMappedMembers(ctx,secondarySchemeId){
        const userMappedWithscheme: any = await strapi.service("api::primaryuser.primaryuser").getUser(ctx.state.loggedInUser)
        const retailerId = userMappedWithscheme.retailerId;
        ctx.request.query = {
            fields: ["secondarySchemeId"],
            filters : {
                retailerId,
                secondarySchemeId
            }
        }
        const data = await super.find(ctx)
        return data;
    }
})
);
