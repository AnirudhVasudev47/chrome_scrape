/**
 * secondary-scheme-membership router
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::secondary-scheme-membership.secondary-scheme-membership');
