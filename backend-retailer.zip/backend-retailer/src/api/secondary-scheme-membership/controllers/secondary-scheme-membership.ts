/**
 * secondary-scheme-membership controller
 */

import { factories } from '@strapi/strapi'

export default factories.createCoreController('api::secondary-scheme-membership.secondary-scheme-membership',
({strapi}) => ({
    async getMappedMembers(ctx,secondarySchemeId){
        const response: any = await strapi.controller("api::primaryuser.primaryuser").getUser(ctx,"")
        const retailerId = response.data[0].attributes.retailerId;
        ctx.request.query = {
            fields: ["secondarySchemeId"],
            filters : {
                retailerId,
                secondarySchemeId
            }
        }
        const data = await super.find(ctx)
        return data;
    }
})
);
