/**
 * secondaryuser controller
 */

import { factories } from "@strapi/strapi";
import { UserActivationStatusEnum, UserType } from "../../../enums";
import { RESPONSE_MESSAGE } from "../../../constants";

export default factories.createCoreController(
  "api::secondaryuser.secondaryuser",
  ({ strapi }) => ({
    async getSecondaryUser(ctx) {
      const customQuery = {
        ...ctx.request.query,
        ...{
          populate: { parentId: { fields: ["retailerId", "retailerName"] } },
        },
      };
      const secondaryUser = await strapi
        .service("api::secondaryuser.secondaryuser")
        .getSecondaryUser(customQuery);
      return secondaryUser;
    },

    async findRecord(ctx) {
      const customQuery = {
        ...ctx.request.query,
        ...{
          populate: { parentId: { fields: ["retailerId", "retailerName"] } },
        },
      };
      const { results } = await strapi
        .service("api::secondaryuser.secondaryuser")
        .find(customQuery);
      return { data: results[0] || null };
    },
    async updateRecord(ctx) {
      const response = await super.update(ctx);
      return response;
    },

    /**
     * Find secondary users filtered by logged-in user's ID
     * @param ctx - Koa context object
     * @returns - Returns filtered secondary users data and metadata
     */
    async find(ctx) {
      const loggedInUserId =
        ctx.state.userType === UserType.PRIMARY
          ? ctx.state.loggedInUser.id
          : null;
      ctx.request.query = { filters: { parentId: loggedInUserId } };
      const secondaryUser = await strapi
        .service("api::secondaryuser.secondaryuser")
        .find(ctx.request.query);
      return { data: secondaryUser.results };
    },

    /**
     * Create a new secondary user and validate if paylaod consist the primary user's mobile number
     * @param ctx - Koa context object
     * @returns - Returns the response from the creation operation
     */
    async create(ctx) {
      try {
        const locale = "en";
        if (await this.isRetailerUser(ctx.request.body.data.mobileNumber)) {
          // throw an error when the user already exists as a primary user
          ctx.throw(
            400,
            RESPONSE_MESSAGE[locale].PRIMARY_USER_ALREADY_REGISTER
          );
        }
        ctx.request.body.data.parentId = ctx.state.loggedInUser.id;
        const createdUser = await strapi
          .service("api::secondaryuser.secondaryuser")
          .create(ctx.request.body);

        // Update the user's activation status once before calling SMS invitation.
        await strapi
          .service("api::secondaryuser.secondaryuser")
          .update(createdUser.id, {
            data: {
              activationStatus: UserActivationStatusEnum.INVITATION_TRIGGERED,
            },
          });

        // trigger the sms notification-service for sending the invite link
        if (process.env.NODE_ENV === "production") {
          await strapi
            .service("api::notification-service.notification-service")
            .sendInviteLink({
              details: [
                {
                  name: createdUser.name,
                  mobileNumber: createdUser.mobileNumber,
                },
              ],
            });
        }

        // Update the user's activation status once the SMS invitation has been successfully sent.
        await strapi
          .service("api::secondaryuser.secondaryuser")
          .update(createdUser.id, {
            data: {
              activationStatus: UserActivationStatusEnum.INVITATION_SENT,
            },
          });
        return createdUser;
      } catch (error) {
        ctx.throw(400, error);
      }
    },

    /**
     * Temp Delete a secondary user
     * @param ctx - Koa context object
     * @returns - Returns the response from the deletion operation
     */
    async delete(ctx) {
      const response = await strapi
        .service("api::secondaryuser.secondaryuser")
        .deleteSecondaryUser(ctx.request.query.id);
      return response;
    },

    /**
     * Check if a user with the given mobile number already exists as a primary user
     * @param mobileNumber - The mobile number to check
     * @returns - Returns true if the user exists as a primary user, otherwise false
     */
    async isRetailerUser(mobileNumber) {
      const primaryUser = await strapi.db
        .query("api::primaryuser.primaryuser")
        .findOne({ where: { mobileNumber } });
      if (primaryUser) return true;
      return false;
    },
  })
);
