/**
 * secondaryuser service
 */

import { factories } from "@strapi/strapi";

export default factories.createCoreService(
  "api::secondaryuser.secondaryuser",
  ({ strapi }) => ({
    async getSecondaryUser(query) {
      const { results } = await strapi
        .service("api::secondaryuser.secondaryuser")
        .find(query);
      return { data: results[0] || null };
    },

    async deleteSecondaryUser(id: string) {
      const response = await strapi
        .service("api::secondaryuser.secondaryuser")
        .update(id, {
          isDeleted: true,
        });
      return response;
    },
  })
);
