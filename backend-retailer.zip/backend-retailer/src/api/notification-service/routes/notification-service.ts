export default {
  routes: [
    {
     method: 'POST',
     path: '/notification/send-invite',
     handler: 'notification-service.sendInviteLink',
     config: {
       policies: [],
       middlewares: [],
     },
    },
  ],
};
