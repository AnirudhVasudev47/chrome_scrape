/**
 * notification-service service
 */

import axios from "axios";
import {
  sendInviteLinkRequestDto,
  sendOtpRequest,
} from "../../../dtos/notification-service-dto";
import { SendInviteConst } from "../../../constants/notificationTemplate";
import { HttpStatusCode } from "../../../enums";
import { RESPONSE_MESSAGE } from "../../../constants";

const locale = "en";

module.exports = {
  async sendInviteLink(requestBody: sendInviteLinkRequestDto) {
    try {
      const successResponse = {
        status: "Success",
      };
      if (requestBody.details.length > 0) {
        for (let i = 0; i < requestBody.details.length; i++) {
          let currentName = requestBody.details[i].name;
          let currentMobileNumber = requestBody.details[i].mobileNumber;

          const message = SendInviteConst.inviteLinkMessage
            .replace("{0}", currentName)
            .replace("{1}", SendInviteConst.androidInviteLink)
            .replace("{2}", SendInviteConst.iosInviteLink);
          const encodedMsg = encodeURIComponent(message);
          const apiReq =
            SendInviteConst.notificationEndpoint +
            "?method=" +
            SendInviteConst.notificationMethod +
            "&send_to=" +
            currentMobileNumber +
            "&msg=" +
            encodedMsg +
            "=&msg_type=" +
            SendInviteConst.notificationMsgType +
            "&userid=" +
            SendInviteConst.notificationUserId +
            "&auth_scheme=" +
            SendInviteConst.notificationAuthScheme +
            "&password=" +
            SendInviteConst.notificationPassword +
            "&v=" +
            SendInviteConst.notificationVersion +
            "&format=" +
            SendInviteConst.notificationFormat;

          // Making a GET call to Gupshup SMS Endpoint
          axios.get(apiReq).then((response) => {
            const smsSent = this.updateDatabase(
              currentMobileNumber,
              response.data
            );
            if (!smsSent) {
              throw {
                status: HttpStatusCode.INTERNAL_SERVER,
                message: RESPONSE_MESSAGE[locale].ERROR_SENDING_INVITE_LINK,
              };
            }
          });
        }
      }
      return {
        data: [successResponse],
      };
    } catch (error) {
      return error;
    }
  },

  async createOrUpdateSms(
    mobileNumber: number,
    payload: {
      smsStatus: string;
      errorCode: number;
      errorMessage: string;
    }
  ) {
    const isRecordPresent = await strapi.db
      .query("api::sms.sms")
      .findOne({ where: { mobileNumber } });

    let record = null;
    if (isRecordPresent) {
      record = await strapi.db.query("api::sms.sms").update({
        where: { mobileNumber },
        data: payload,
      });
    } else {
      record = await strapi.db.query("api::sms.sms").create({
        data: {
          ...{ mobileNumber },
          ...payload,
        },
      });
    }
    return record;
  },

  async updateDatabase(mobileNumber: number, responseData) {
    if (JSON.stringify(responseData).includes("|")) {
      const value: string[] = responseData.split("|");
      let result;
      if (value[0].includes("success")) {
        result = this.createOrUpdateSms(mobileNumber, {
          smsStatus: "Success",
          errorCode: null,
          errorMessage: null,
        });
      } else {
        result = this.createOrUpdateSms(mobileNumber, {
          smsStatus: "Error",
          errorCode: value[1],
          errorMessage: value[2],
        });
      }
      return result;
    }
  },

  async sendOtp(requestBody: sendOtpRequest) {
    try {
      const successResponse = {
        status: RESPONSE_MESSAGE[locale].SUCCESS,
      };
      const message = SendInviteConst.sendOtpMessage.replace(
        "{0}",
        requestBody.otp + ""
      );
      const encodedMsg = encodeURIComponent(message);
      const apiReq =
        SendInviteConst.notificationEndpoint +
        "?method=" +
        SendInviteConst.notificationMethod +
        "&send_to=" +
        requestBody.mobileNumber +
        "&msg=" +
        encodedMsg +
        "=&msg_type=" +
        SendInviteConst.notificationMsgType +
        "&userid=" +
        SendInviteConst.notificationUserId +
        "&auth_scheme=" +
        SendInviteConst.notificationAuthScheme +
        "&password=" +
        SendInviteConst.notificationPassword +
        "&v=" +
        SendInviteConst.notificationVersion +
        "&format=" +
        SendInviteConst.notificationFormat;
      // Making a GET call to Gupshup SMS Endpoint
      try {
        const response = await axios.get(apiReq);
        if (response.data && JSON.stringify(response.data).includes("|")) {
          const value: string[] = response.data.split("|");
          console.log(value[0], value[2]);
          if (value[0].includes("error")) {
            console.log("Error");
            throw {
              status: HttpStatusCode.BAD_REQUEST,
              message: value[2],
            };
          }
          return { data: [successResponse] };
        }
      } catch (e) {
        return e;
      }
    } catch (error) {
      return error;
    }
  },
};
