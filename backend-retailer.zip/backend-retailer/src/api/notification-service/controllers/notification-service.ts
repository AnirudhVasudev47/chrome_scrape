/**
 * A set of functions called "actions" for `notification-service`
 */
import { HttpStatusCode } from "../../../enums";
import { RESPONSE_MESSAGE } from "../../../constants/locale";

const locale = "en";

module.exports = {
  async sendInviteLink(ctx, next) {
    try {
      const { status = HttpStatusCode.OK, ...rest } = await strapi
        .service("api::notification-service.notification-service")
        .sendInviteLink(ctx.request.body);
      ctx.send(
        {
          ...rest,
        },
        status
      );
    } catch (err) {
      ctx.badRequest(RESPONSE_MESSAGE[locale].ERROR_SENDING_INVITE_LINK, {
        moreDetails: err,
      });
    }
  },
};
