export default {
  routes: [
    {
      method: "GET",
      path: "/secondary-schemes/products",
      handler: "skuproduct.findEligibleProducts",
    },
    {
      method: "POST",
      path: "/secondary-schemes/products/sku",
      handler: "skuproduct.getListOfSkuProducts",
    },
    {
      method: "GET",
      path: "/sku-products",
      handler: "skuproduct.getSkuProductList",
    },
  ],
};
