/**
 * skuproduct controller
 */

import { factories } from "@strapi/strapi";

export default factories.createCoreController(
  "api::skuproduct.skuproduct",
  ({ strapi }) => ({
    async findEligibleProducts(ctx, next) {
      console.log("2.Eligible Products")
      try {
        const eligibleProducts = await strapi
          .service("api::skuproduct.skuproduct")
          .getAllEligibleProducts(ctx);
      console.log("3.Result from eligible products :::",eligibleProducts);
        return Object.entries(eligibleProducts).length
          ? eligibleProducts
          : { data: "Data Not Found" };
      } catch (err) {
        return err;
      }
    },

    async getListOfSkuProducts(ctx, next) {
      console.log("1.List of skus")
      ctx.request.body.skuProductFlag = true;
      const { subCategoryId, series } = ctx.request.body;
      let data: any = await this.findEligibleProducts(ctx, next);
      console.log("4.From list of skus data :::",data)
      if (!data.verify) {
        return data;
      }
      let skuSeriesDetails: any = {
        series: series,
        skuProductList: [],
      };
      try {
        let subCategoryFinal =
          data && data.result.data.length
            ? data.result.data.find(
                (subCategory) => subCategory.subCategoryId === subCategoryId
              )
            : null;
        if (subCategoryFinal && subCategoryFinal.skuProductDetail.length) {
          subCategoryFinal.skuProductDetail.forEach((skuProduct) => {
            if (skuProduct.series === series) {
              skuSeriesDetails.skuProductList.push({
                skuproductId: skuProduct.skuId,
                product: skuProduct.product,
              });
            }
          });
        }
        return skuSeriesDetails && skuSeriesDetails.skuProductList.length
          ? { data: skuSeriesDetails, meta: data.pagination }
          : { data: "No SkuProducts under this subCategoryId" };
      } catch (err) {
        return err;
      }
    },

    async getSkuProductList(ctx, next) {
      const { data, meta } = await super.find(ctx);
      return { data, meta };
    },
  })
);
