/**
 * skuproduct service
 */

import { factories } from "@strapi/strapi";
import { defaultPaginationConfig } from "../../../constants";

export default factories.createCoreService(
  "api::skuproduct.skuproduct",
  ({ strapi }) => ({
    async getAllEligibleProducts(ctx, next) {
      const skuProductFlag = ctx.request.body.skuProductFlag || false;
      let secondarySchemeId = "",
        categoryId = "",
        subCategoryId = "";
      const paginationFilter = ctx.request.body.pagination;
      if (skuProductFlag) {
        secondarySchemeId = ctx.request.body.secondarySchemeId;
        categoryId = ctx.request.body.categoryId;
        subCategoryId = ctx.request.body.subCategoryId;
      } else {
        //Getting secondarySchemeId & categoryId
        secondarySchemeId = ctx.request.query.secondarySchemeId;
        categoryId = ctx.request.query.categoryId;
      }
      try {
        if (!ctx.state.loggedInUser) {
          return { verify: false, result: "Please login to access." };
        }
      console.log("5.from service after try :::")

        const response: any = await this.getSecondarySchemeMembers(
          ctx,
          secondarySchemeId
        );
        if (!response.results.length) {
          return { data: "Not a valid user" };
        }
        const { data }: any = await strapi
          .service("api::secondary-scheme-product.secondary-scheme-product")
          .findSKUProducts(ctx, secondarySchemeId);

        let skuProductId = data.map(
          (eachskuProductId) => eachskuProductId.skuProduct
        );

        let { results: skuProduct, pagination }: any = paginationFilter
          ? await strapi.service("api::skuproduct.skuproduct").find({
              filters: {
                categoryId,
                subCategoryId,
                skuProduct: { $in: skuProductId },
              },
              pagination: {
                page: paginationFilter.page || defaultPaginationConfig.page,
                pageSize:
                  paginationFilter.pageSize || defaultPaginationConfig.pageSize,
              },
            })
          : await strapi.service("api::skuproduct.skuproduct").find({
              filters: {
                categoryId,
                skuProduct: { $in: skuProductId },
              },
            });
      console.log("6.Result :::",skuProduct,pagination)
        const category = await strapi
          .service("api::category.category")
          .getCategoryByCategoryId(categoryId);

        const categoryName = category.categoryName;

        const subCategoryName = await this.getSubcategoryNameBySubCategoryId(
          ctx,
          skuProduct
        );

        const result = await this.getResponse(
          skuProduct,
          secondarySchemeId,
          categoryId,
          categoryName,
          subCategoryName,
          skuProductFlag
        );
        return skuProductFlag ? { verify: true, result, pagination } : result;
      } catch (err) {
        return err;
      }
    },
    async getSecondarySchemeMembers(ctx, secondarySchemeId) {
      const response: any = await strapi
        .service("api::secondary-scheme-membership.secondary-scheme-membership")
        .getMappedMembers(ctx, secondarySchemeId);
      return response;
    },
    async getSubcategoryNameBySubCategoryId(ctx, skuProduct) {
      //Getting list of subcategoryIds
      const subCategoryIds = skuProduct.map(
        (eachSubcategory) => eachSubcategory.subCategoryId
      );
      const subCategoryName: any = await strapi
        .controller("api::sub-category.sub-category")
        .findSubCategoryBySubCategoryIds(ctx, subCategoryIds);
      return subCategoryName;
    },
    async getResponse(
      skuProduct,
      secondarySchemeId,
      categoryId,
      categoryName,
      subCategoryName,
      skuProductFlag
    ) {
      let eligibleProducts: any = {};
      //Structuring data by subcategory & skuproductdetails
      skuProduct.forEach((skuproductdata) => {
        let skuProductObject: any = {};
        let eligibleProductsData = skuproductdata;
        if (!eligibleProducts.category) {
          skuProductObject.secondarySchemeId = secondarySchemeId;
          skuProductObject.category = categoryName;
          skuProductObject.categoryId = categoryId;
          skuProductObject.data = [
            {
              subCategory: subCategoryName[eligibleProductsData.subCategoryId],
              subCategoryId: eligibleProductsData.subCategoryId,
              skuProductDetail: [
                {
                  skuId: eligibleProductsData.seriesCode,
                  series: eligibleProductsData.seriesDescription,
                },
              ],
            },
          ];
          if (skuProductFlag)
            skuProductObject.data[0].skuProductDetail[0].product =
              eligibleProductsData.skuProductName;
          eligibleProducts = skuProductObject;
          return;
        }
        let checkDuplicatesubCategory = eligibleProducts.data.find(
          ({ subCategory }) =>
            subCategory === subCategoryName[eligibleProductsData.subCategoryId]
        );
        if (!checkDuplicatesubCategory) {
          let skuProductObj = skuProductFlag
            ? {
                skuId: eligibleProductsData.seriesCode,
                series: eligibleProductsData.seriesDescription,
                product: eligibleProductsData.skuProductName,
              }
            : {
                skuId: eligibleProductsData.seriesCode,
                series: eligibleProductsData.seriesDescription,
              };
          (skuProductObject.subCategory =
            subCategoryName[eligibleProductsData.subCategoryId]),
            (skuProductObject.subCategoryId =
              eligibleProductsData.subCategoryId),
            (skuProductObject.skuProductDetail = [skuProductObj]);
          eligibleProducts.data.push(skuProductObject);
          return;
        }
        skuProductObject.skuId = eligibleProductsData.seriesCode;
        skuProductObject.series = eligibleProductsData.seriesDescription;
        if (skuProductFlag)
          skuProductObject.product = eligibleProductsData.skuProductName;
        checkDuplicatesubCategory.skuProductDetail.push(skuProductObject);
        return;
      });
      return eligibleProducts;
    },

    async getSKUProductsByCategoryId(categoryId: string) {
      const skuProducts = await strapi.db
        .query("api::skuproduct.skuproduct")
        .findMany({
          select: ["subCategoryId", "skuProductName", "skuProduct"],
          where: { categoryId },
        });
      return skuProducts;
    },
  })
);
