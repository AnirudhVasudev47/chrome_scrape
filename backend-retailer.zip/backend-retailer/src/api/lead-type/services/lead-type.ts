/**
 * lead-type service
 */

import { factories } from "@strapi/strapi";
import { LeadTypeEnum } from "../../../enums";

export default factories.createCoreService(
  "api::lead-type.lead-type",
  ({ strapi }) => ({
    /**
     * Retrieves lead type details by lead type.
     * @param leadType - The lead type to retrieve details for.
     * @returns The lead type details.
     * @throws Error if no record is found with the specified lead type.
     */
    async getLeadTypeDetailsByLeadType(leadType: LeadTypeEnum) {
      const leadTypeRecord = await strapi.db
        .query("api::lead-type.lead-type")
        .findOne({ where: { leadType } });
      if (!leadTypeRecord) {
        throw new Error(`No record found with leadType ${leadType}`);
      }
      return leadTypeRecord;
    },
  })
);
