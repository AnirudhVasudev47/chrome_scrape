/**
 * secondary-scheme controller
 */

import { factories } from "@strapi/strapi";
import { HttpStatusCode } from "../../../enums";

export default factories.createCoreController(
  "api::secondary-scheme.secondary-scheme",
  ({ strapi }) => ({
    async getAllSecondarySchemes(ctx) {
      try {
        const secondarySchemes = await strapi
          .service("api::secondary-scheme.secondary-scheme")
          .getAllSecondarySchemes(ctx.request.body, ctx.state.loggedInUser);
        ctx.send(secondarySchemes, HttpStatusCode.OK);
      } catch (error) {
        const { status = HttpStatusCode.BAD_REQUEST, ...rest } = error;
        ctx.send(
          {
            ...rest,
          },
          status
        );
      }
    },
    async getSchemeDetails(ctx) {
      try {
        const schemeDetails = await strapi
          .service("api::secondary-scheme.secondary-scheme")
          .getSchemeDetails(ctx.request.params.schemeId, ctx.state.loggedInUser);
        ctx.send(schemeDetails, HttpStatusCode.OK);
      } catch (error) {
        const { status = HttpStatusCode.BAD_REQUEST, ...rest } = error;
        ctx.send(
          {
            ...rest,
          },
          status
        );
      }
    },
    async getAllSecondarySchemeNamesBySchemeId(ctx){
      const schemes = await strapi.service("api::secondary-scheme.secondary-scheme").getAllSecondarySchemeNamesBySchemeId(ctx)
      return schemes
    },

    async downloadScheme(ctx) {
      const pdf = await strapi.service("api::secondary-scheme.secondary-scheme")
                  .downloadScheme(ctx);
      return pdf;
    },

    async termsAndConditions(ctx) {
      try {
        console.log("In controller");
        const termsAndConditionsData = await strapi.service("api::secondary-scheme.secondary-scheme").
                                  termsAndConditions(ctx);
        ctx.send(termsAndConditionsData, HttpStatusCode.OK);
      } catch (error) {
        const { status = HttpStatusCode.BAD_REQUEST, ...rest } = error;
        ctx.send(
          {
            ...rest,
          },
          status
        );
      }
    }
  })
);
