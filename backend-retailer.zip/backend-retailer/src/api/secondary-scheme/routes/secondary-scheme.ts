export default {
    routes: [
      {
        method: "POST",
        path: "/secondary-schemes",
        handler: "secondary-scheme.getAllSecondarySchemes",
      },
      {
        method: "GET",
        path: "/secondary-schemes/detail/:schemeId",
        handler: "secondary-scheme.getSchemeDetails",
      },
      {
        method: "GET",
        path: "/secondary-schemes/filters",
        handler: "secondary-scheme.getAllSecondarySchemeNamesBySchemeId",
      },
      {
        method: "GET",
        path: "/secondary-schemes/scheme-download",
        handler: "secondary-scheme.downloadScheme",
      },
      {
        method: "GET",
        path: "/secondary-schemes/tnc",
        handler: "secondary-scheme.termsAndConditions",
      }
    ],
  };
  
