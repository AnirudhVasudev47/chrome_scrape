/**
 * secondary-scheme service
 */

import { factories } from "@strapi/strapi";
import { defaultPaginationConfig } from "../../../constants";
import {
  FetchAllSecondarySchemesRequestDto,
  DateDto,
  SecondarySchemeDto,
  SchemeDetailsDto,
  SecondarySchemeResponse,
  FetchAllSecondarySchemesResponseDto,
  FetchSecondarySchemesResponseDto,
} from "../../../dtos/secondary-schemes-dto";
import { PaginationDto } from "../../../dtos";
import { HttpStatusCode } from "../../../enums";
import PDFDocument from "pdfkit";

export default factories.createCoreService(
  "api::secondary-scheme.secondary-scheme",
  ({ strapi }) => ({
    /**
     *
     * @param payload - Has pagination details along with filters that need to be applied on schemes.
     * @param loggedInUser - The details of the logged-in user who is fetching secondary schemes.
     * @returns the list of secondary scheme details
     */
    async getAllSecondarySchemes(
      payload: FetchAllSecondarySchemesRequestDto,
      loggedInUser
    ): Promise<FetchSecondarySchemesResponseDto> {
      const paginationFilter = payload.pagination;
      const { schemeStatus, customDate, categoryIds, schemeNameIds } =
        payload.filters;
      let { schemeIds, skuProduct } = await this.fetchSchemeIdsByCategoryIds(
        categoryIds,
        schemeNameIds,
        loggedInUser.retailerId
      );
      const schemes = await this.fetchSchemesBySchemeIds(
        schemeIds,
        schemeStatus,
        customDate,
        paginationFilter
      );
      const { results: categoryDetails, pagination } =
        await this.fetchCategoryNamesFromSchemes(
          schemes,
          skuProduct,
          paginationFilter
        );
      const { totalSchemes, output } = await this.groupSchemesByCategory(
        categoryDetails,
        schemes
      );
      if (totalSchemes === 0) {
        pagination.pageCount = 1;
      } else {
        const pageCount = Math.ceil(totalSchemes / pagination.pageSize);
        pagination.pageCount = pageCount;
        pagination.total = totalSchemes;
      }
      return {
        data: output,
        meta: { pagination, filters: payload.filters },
      };
    },

    /**
     * Fetches schemes by scheme Ids
     * @param schemeIds -List of scheme ids
     * @param schemeStatus - scheme statsu
     * @param customDate - a DateDto with fromDate and toDate
     * @param paginationFilter - pagination settings
     * @returns scheme details
     */
    async fetchSchemesBySchemeIds(
      schemeIds: string[],
      schemeStatus: string,
      customDate: DateDto,
      paginationFilter: PaginationDto
    ): Promise<any> {
      try {
        const { fromDate = "", toDate = "" } = customDate;
        const query = {
          filters: {
            ...(schemeIds.length && { secondarySchemeId: schemeIds }),
            ...(schemeStatus && { status: schemeStatus }),
            ...(fromDate &&
              toDate && {
                targetActivationDate: {
                  $between: [new Date(fromDate), new Date(toDate)],
                },
              }),
          },
        };
        // Querying sku product table based in skuProduct
        const schemeDetails = await strapi
          .service("api::secondary-scheme.secondary-scheme")
          .find(query);
        return schemeDetails.results;
      } catch (error) {
        console.log(
          "Error encountered while fetching schemes from scheme ids : ",
          error
        );
      }
    },

    /**
     * Fetches schemeids based on category ids
     * @param categoryIds list of category ids
     * @param schemeNameIds list of scheme ids
     * @param retailerId The id of the logged-in user who is fetching secondary schemes.
     * @returns list of scheme ids
     */
    async fetchSchemeIdsByCategoryIds(
      categoryIds: string[],
      schemeNameIds: string[],
      retailerId: string
    ): Promise<any> {
      // get skuproduct from sku products based on categoryIds
      if (categoryIds && categoryIds.length) {
        // check if the user is DMS Verified
        const verifiedCategoryDetails = await strapi.db
          .query("api::retailer-category.retailer-category")
          .findMany({
            select: ["categoryId"],
            filters: {
              categoryId: categoryIds,
              dmsVerified: "yes",
            },
          });
        const verifiedCategories = verifiedCategoryDetails.map(
          (category) => category.categoryId
        );
        if (verifiedCategories.length !== 0) {
          const skuProducts = await strapi.db
            .query("api::skuproduct.skuproduct")
            .findMany({
              select: ["skuProduct", "categoryName"],
              filters: {
                categoryId: verifiedCategories,
              },
            });
          const skuProductNames = skuProducts.map(
            (product) => product.skuProduct
          );
          // Filter out duplicate product names
          let uniqueSkuProducts: string[] = new Array();
          uniqueSkuProducts = skuProductNames.filter(
            (productName, index, array) => {
              return array.indexOf(productName) === index;
            }
          );
          // get scheme id from scheme products based on sku product
          const schemeIds = await strapi.db
            .query("api::secondary-scheme-product.secondary-scheme-product")
            .findMany({
              select: ["secondarySchemeProductsId"],
              filters: {
                skuProduct: uniqueSkuProducts,
              },
            });
          const ids = schemeIds.map(
            (schemeId) => schemeId.secondarySchemeProductsId
          );
          let filteredIds: string[];
          //check filtered scheme ids from ids
          if (schemeNameIds.length !== 0) {
            filteredIds = ids.filter((value) => schemeNameIds.includes(value));
          } else {
            filteredIds = ids;
          }
          // checking if the scheme ids are of logged in retailer
          const schemeIdsOfRetailer = await strapi.db
            .query(
              "api::secondary-scheme-membership.secondary-scheme-membership"
            )
            .findMany({
              select: ["secondarySchemeId"],
              filters: {
                retailerId: retailerId,
                secondarySchemeId: filteredIds,
              },
            });
          let idList: string[] = new Array();
          idList = schemeIdsOfRetailer.map(
            (schemeId) => schemeId.secondarySchemeId
          );
          return { schemeIds: idList, skuProduct: uniqueSkuProducts };
        } else {
          throw {
            status: HttpStatusCode.BAD_REQUEST,
            message: `Category ids are not DMS Verified.`,
          };
        }
      } else {
        let skuProduct: string[] = new Array();
        const schemeIds = await this.fetchSchemeIdsfromRetailerId(
          retailerId,
          schemeNameIds
        );
        return { schemeIds, skuProduct };
      }
      // If categoryIds array is empty or not provided, return an empty array
      //return [];
    },

    /**
     * Fetching category names from scheme ids
     * @param scheme list of schemes
     * @param paginationFilter - pagination settings
     * @returns list of category names
     */
    async fetchCategoryNamesFromSchemes(
      schemes: any,
      skuProducts: string[],
      paginationFilter: PaginationDto
    ): Promise<any> {
      const schemeIds: string[] = new Array();
      for (let key in schemes) {
        schemeIds.push(schemes[key].secondarySchemeId);
      }
      const categoryIds = await strapi.db
        .query("api::secondary-scheme-product.secondary-scheme-product")
        .findMany({
          select: ["skuProduct", "secondarySchemeProductsId"],
          filters: {
            secondarySchemeProductsId: schemeIds,
          },
        });
      const categoryIdsArray = categoryIds.map(
        (categoryId) => categoryId.skuProduct
      );
      let filteredSkuProducts: string[];
      //check filtered scheme ids from ids
      if (skuProducts.length !== 0) {
        filteredSkuProducts = categoryIdsArray.filter((value) =>
          skuProducts.includes(value)
        );
      } else {
        filteredSkuProducts = categoryIdsArray;
      }
      const { results, pagination }: any = await strapi
        .service("api::skuproduct.skuproduct")
        .find({
          select: ["skuProduct", "categoryName", "categoryId"],
          filters: {
            skuProduct: filteredSkuProducts,
          },
          pagination: {
            page: paginationFilter.page || defaultPaginationConfig.page,
            pageSize:
              paginationFilter.pageSize || defaultPaginationConfig.pageSize,
          },
        });
      return { results, pagination };
    },

    /**
     * fetches scheme ids from sku products
     * @param skuProducts list of sku products
     * @returns list of scheme ids
     */
    async fetchSchemeIdsBySkuProducts(
      skuProducts: string,
      schemeIdsList: string[]
    ): Promise<string[]> {
      const schemeIds = await strapi.db
        .query("api::secondary-scheme-product.secondary-scheme-product")
        .findMany({
          select: ["skuProduct", "secondarySchemeProductsId"],
          filters: {
            skuProduct: skuProducts,
            secondarySchemeProductsId: schemeIdsList,
          },
        });
      if (!schemeIds) {
        throw {
          status: HttpStatusCode.NOT_FOUND,
          message: `No scheme ids found for sku product ${skuProducts}`,
        };
      }
      return schemeIds.map((schemeId) => schemeId.secondarySchemeProductsId);
    },

    /**
     * fetches schemes based on scheme id
     * @param schemeIds list of scheme ids
     * @returns schemes
     */
    async fetchSchemeFromSchemeId(
      schemeIds: string[]
    ): Promise<SecondarySchemeDto[]> {
      const schemes = await strapi
        .service("api::secondary-scheme.secondary-scheme")
        .find({
          filters: {
            secondarySchemeId: schemeIds,
          },
          fields: [
            "secondarySchemeId",
            "name",
            "targetActivationDate",
            "endDate",
            "schemeType",
          ],
        });
      if (!schemes) {
        throw new Error(`Scheme with id ${schemeIds} not found.`);
      }
      return schemes.results;
    },

    /**
     * groups schemes by category names
     * @param categoryNames list of category names
     * @returns list of schemes group by category name
     */
    async groupSchemesByCategory(
      categoryNames: any,
      schemes: any
    ): Promise<SecondarySchemeResponse> {
      const schemeIds: string[] = new Array();
      for (let key in schemes) {
        schemeIds.push(schemes[key].secondarySchemeId);
      }
      const groupedProductsBySkuProduct: {
        [key: string]: SchemeDetailsDto | SchemeDetailsDto[];
      } = {};
      let groupCategories: { [key: string]: [string, SecondarySchemeDto[]] } =
        {};
      //Grouping the category id, skuproduct and category names based on category name
      categoryNames.forEach((item) => {
        if (!groupedProductsBySkuProduct[item.categoryName]) {
          groupedProductsBySkuProduct[item.categoryName] = {
            categoryId: item.categoryId,
            skuProduct: item.skuProduct,
          };
        } else {
          if (Array.isArray(groupedProductsBySkuProduct[item.categoryName])) {
            (
              groupedProductsBySkuProduct[
                item.categoryName
              ] as SchemeDetailsDto[]
            ).push({
              categoryId: item.categoryId,
              skuProduct: item.skuProduct,
            });
          } else {
            groupedProductsBySkuProduct[item.categoryName] = [
              groupedProductsBySkuProduct[
                item.categoryName
              ] as SchemeDetailsDto,
              {
                categoryId: item.categoryId,
                skuProduct: item.skuProduct,
              },
            ];
          }
        }
      });
      // grouping by category
      groupCategories = await this.groupByCategories(
        groupedProductsBySkuProduct,
        schemeIds
      );
      const { totalSchemes, output } = await this.transformOutput(
        groupCategories
      );
      return { totalSchemes, output };
    },

    /**
     * fetches scheme ids from retailer id
     * @param retailerId The details of the logged-in user who is fetching secondary schemes.
     * @returns list of scheme ids
     */
    async fetchSchemeIdsfromRetailerId(
      retailerId: string,
      schemeNameIds: string[]
    ): Promise<string[]> {
      const schemeIds = await strapi.db
        .query("api::secondary-scheme-membership.secondary-scheme-membership")
        .findMany({
          select: ["secondarySchemeId"],
          filters: {
            retailerId: retailerId,
            secondarySchemeId: schemeNameIds,
          },
        });
      return schemeIds.map((schemeId) => schemeId.secondarySchemeId);
    },

    async transformOutput(groupCategories): Promise<SecondarySchemeResponse> {
      const output: FetchAllSecondarySchemesResponseDto[] = [];
      let schemes: SecondarySchemeDto[];
      let totalSchemes = 0;
      for (const categoryKey of Object.keys(groupCategories)) {
        const categoryId = groupCategories[categoryKey][0] as string;
        schemes = [];
        totalSchemes = totalSchemes + groupCategories[categoryKey][1].length;
        for (let i = 0; i < groupCategories[categoryKey][1].length; i++) {
          const schemeObj = groupCategories[categoryKey][1][
            i
          ] as SecondarySchemeDto;
          schemes.push(schemeObj);
        }
        output.push({
          category: categoryKey,
          categoryId: categoryId,
          schemes: schemes,
        });
      }
      return { totalSchemes, output };
    },

    async groupByCategories(
      groupedProductsBySkuProduct,
      schemeIdsList: string[]
    ): Promise<{ [key: string]: [string, SecondarySchemeDto[]] }> {
      const groupCategories: { [key: string]: [string, SecondarySchemeDto[]] } =
        {};
      for (const category in groupedProductsBySkuProduct) {
        if (Array.isArray(groupedProductsBySkuProduct[category])) {
          const detailsArray = groupedProductsBySkuProduct[
            category
          ] as SchemeDetailsDto[];
          for (const detail of detailsArray) {
            const schemeIds: string[] = await this.fetchSchemeIdsBySkuProducts(
              detail.skuProduct,
              schemeIdsList
            );
            const schemes: SecondarySchemeDto[] =
              await this.fetchSchemeFromSchemeId(schemeIds);
            if (category in groupCategories) {
              // If the category already exists in groupCategories, push the new record to the existing array
              groupCategories[category].push(detail.categoryId, schemes);
            } else {
              // If the category doesn't exist in groupCategories, create a new array with the new record
              groupCategories[category] = [detail.categoryId, schemes];
            }
          }
        } else {
          const schemeIds: string[] = await this.fetchSchemeIdsBySkuProducts(
            groupedProductsBySkuProduct[category]["skuProduct"],
            schemeIdsList
          );
          const schemes: SecondarySchemeDto[] =
            await this.fetchSchemeFromSchemeId(schemeIds);
          if (category in groupCategories) {
            // If the category already exists in groupCategories, push the new record to the existing array
            groupCategories[category].push([
              groupedProductsBySkuProduct[category]["categoryId"],
              schemes,
            ]);
          } else {
            // If the category doesn't exist in groupCategories, create a new array with the new record
            groupCategories[category] = [
              groupedProductsBySkuProduct[category]["categoryId"],
              schemes,
            ];
          }
        }
      }
      return groupCategories;
    },

    async getSchemeDetails(schemeId: string, loggedInUser) {
      const schemeIdsOfRetailer = await this.verifyRetailerId(
        loggedInUser.retailerId
      );
      if (schemeIdsOfRetailer.includes(schemeId)) {
        const slabDetails = await this.getSlabDetailsFromSchemeId(schemeId);
        return {
          data: {
            slabDetails,
          },
        };
      } else {
        throw {
          status: HttpStatusCode.BAD_REQUEST,
          message: `Scheme Id ${schemeId} is not related to retalier id ${loggedInUser.retailerId}.`,
        };
      }
    },

    async getSlabDetailsFromSchemeId(schemeId: string) {
      try {
        const slabDetails = await strapi.db
          .query("api::secondary-scheme-slab.secondary-scheme-slab")
          .findMany({
            select: [
              "slabThresholdFrom",
              "slabThresholdTo",
              "slabCriteriaUOM",
              "rewardType",
              "focName",
              "rewardUnit",
              "rewardToBeEarned",
            ],
            filters: {
              scheme: schemeId,
            },
          });
        return slabDetails;
      } catch (error) {
        console.log(
          "Error encountered while fetching slab details by scheme id. ",
          error
        );
      }
    },

    async verifyRetailerId(retailerId: string) {
      const schemeIds = await strapi.db
        .query("api::secondary-scheme-membership.secondary-scheme-membership")
        .findMany({
          select: ["secondarySchemeId"],
          filters: {
            retailerId: retailerId,
          },
        });
      return schemeIds.map((schemeId) => schemeId.secondarySchemeId);
    },

    async getAllSecondarySchemeNamesBySchemeId(ctx) {
      const schemeNames = await strapi.db
        .query("api::secondary-scheme.secondary-scheme")
        .findMany({
          select: ["secondarySchemeId", "name"],
        });
      return schemeNames;
    },
    async findSchemeData(ctx, secondarySchemeId) {
      ctx.request.query = {
        filters: { secondarySchemeId },
      };
      const result = await super.find(ctx);
      return result;
    },

    async downloadScheme(ctx) {
      try {
        const blobData = {
          slabDetails: [
            {
              slabThresholdFrom: 15,
              slabThresholdTo: 25,
              slabCriteriaUOM: "Volume",
              rewardType: "Tour",
              focName: null,
              rewardUnit: 1,
              rewardToBeEarned: "Tour",
            },
          ],
        };

        // Create a new PDF document
        const doc = new PDFDocument();

        // Add your data to the PDF document
        doc.text(JSON.stringify(blobData, null, 2));

        // Generate the PDF document to a buffer
        const buffer: Buffer = await new Promise((resolve, reject) => {
          const buffers: Uint8Array[] = [];
          doc.on("data", buffers.push.bind(buffers));
          doc.on("end", () => resolve(Buffer.concat(buffers)));
          doc.end();
        });

        // Convert the binary PDF data to base64
        const base64Data = buffer.toString("base64");

        // Set the appropriate MIME type and content disposition
        ctx.set("Content-Type", "application/octet-stream");
        ctx.set("Content-Disposition", 'attachment; filename="blobData.pdf"');

        // Send the PDF data as the response body
        ctx.body = base64Data;
      } catch (error) {
        throw {
          status: HttpStatusCode.INTERNAL_SERVER,
          message: `Error generating PDF.`,
        };
      }
    },

    async termsAndConditions(ctx) {
      const termsAndConditionsData = await strapi.db
        .query("api::secondary-scheme.secondary-scheme")
        .findMany({
          select: ["termsAndConditions", "updatedAt"],
        });
      for (let data in termsAndConditionsData) {
        if (
          termsAndConditionsData[data] &&
          termsAndConditionsData[data].termsAndConditions !== null
        ) {
          if (
            termsAndConditionsData[data].termsAndConditions[0] &&
            termsAndConditionsData[data].termsAndConditions[0].children[0] &&
            termsAndConditionsData[data].termsAndConditions[0].children[0].text
          ) {
            return {
              html: termsAndConditionsData[data].termsAndConditions[0]
                .children[0].text,
              lastUpdatedDate: termsAndConditionsData[data].updatedAt,
            };
          }
        }
      }
    },
  })
);
