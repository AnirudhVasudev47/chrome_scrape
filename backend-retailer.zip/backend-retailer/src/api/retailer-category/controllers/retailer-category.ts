/**
 * retailer-category controller
 */

import { factories } from '@strapi/strapi'

export default factories.createCoreController('api::retailer-category.retailer-category',
({strapi}) => ({
    async getDmsVerifiedCategories(ctx){
        const categories = await strapi.service("api::retailer-category.retailer-category").getDmsVerifiedCategories(ctx)
        return categories
    }
})
);
