export default {
    routes: [
      {
        method: "GET",
        path: "/retailer-categories/categoryNames",
        handler: "retailer-category.getDmsVerifiedCategories",
      },
    ],
  };
  