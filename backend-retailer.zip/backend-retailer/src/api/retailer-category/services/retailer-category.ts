/**
 * retailer-category service
 */

import { factories } from "@strapi/strapi";

export default factories.createCoreService(
  "api::retailer-category.retailer-category",
  ({ strapi }) => ({
    async getSapActiveCategories(loggedInUserId) {
      const sapActiveCategories = await strapi.db
        .query("api::retailer-category.retailer-category")
        .findMany({
          where: {
            sapActive: true,
            retailerId: loggedInUserId,
          },
          select: [
            "invoiceDate",
            "categoryId",
            "retailerPartnerId",
            "relation",
          ],
        });
      return sapActiveCategories;
    },

    async getDmsVerifiedCategories(ctx) {
      const categories = await strapi
        .service("api::retailer-category.retailer-category")
        .find({
          fields: ["categoryId"],
          filters: { dmsVerified: "yes" },
        });
      const categoryIds = categories.results.map(
        (categoryId) => categoryId.categoryId
      );
      if (categoryIds.length) {
        const categoryDetails = await strapi
          .service("api::category.category")
          .getCategoryBycategoryIds(categoryIds);
        return categoryDetails;
      }
    },

    async getProductCategoriesByRetailerId(loggedInUserId) {
      const categories = await strapi.db
        .query("api::retailer-category.retailer-category")
        .findMany({
          select: ["categoryId"],
          where: { categoryRetailerId: loggedInUserId.retailerId },
        });
      const categoryIds = categories.map((categoryId) => categoryId.categoryId);
      if (categoryIds.length) {
        const categoryDetails = await strapi
          .service("api::category.category")
          .getCategoryBycategoryIds(categoryIds);
        return categoryDetails;
      }
    },
  })
);
