/**
 * A set of functions called "actions" for `profile`
 */

import { UserRole } from "../../../enums";
import { modifiedStrapiResponse } from "../../../utils/helperFuntions";
module.exports = {
  async getPersonalDetails(ctx, next) {
    let loggedInUserId = ctx.state.loggedInUser.id,
      table = null,
      fields = null,
      filters = { id: loggedInUserId };
    if (ctx.state.user.role?.name === UserRole.PRIMARY_USER) {
      table = "api::primaryuser.primaryuser";
      fields = [
        "retailerName",
        "retailerId",
        "mobileNumber",
        "alternateMobileNo",
        "email",
        "loggedInDate",
        "invitationDate",
        "activationStatus",
        "blockStatus",
        "dateOfBirth",
        "gender",
        "maritalStatus",
        "marriageAnniversary",
        "profilePhoto",
      ];
    } else {
      table = "api::secondaryuser.secondaryuser";
      fields = ["name", "mobileNumber", "profilePhoto"];
      filters = { ...filters, ...{ isDeleted: false } };
    }
    ctx.request.query = { filters, fields };
    try {
      const response: any = await strapi
        .controller(table)
        .findRecord(ctx, next);
      ctx.body = modifiedStrapiResponse(response.data);
    } catch (err) {
      ctx.body = err;
    }
  },

  /**
   * Updating the personal/profilePhoto accordingly
   * @param ctx
   * @param next
   */
  async update(ctx, next) {
    let loggedInUserId = null,
      table = null;
    if (ctx.state.user.role?.name === UserRole.PRIMARY_USER) {
      table = "api::primaryuser.primaryuser";
      loggedInUserId = ctx.state.loggedInUser.id;
    } else {
      table = "api::secondaryuser.secondaryuser";
      loggedInUserId = ctx.state.loggedInUser.id;
    }
    ctx.request.params.id = loggedInUserId;
    try {
      const response = await strapi.controller(table).updateRecord(ctx, next);
      ctx.body = response;
      // TODO: send the message only instead Updated object
    } catch (err) {
      ctx.body = err;
    }
  },

  async getBusinessDetails(ctx, next) {
    let loggedInUserId = null;
    if (ctx.state.user.role?.name === UserRole.PRIMARY_USER) {
      loggedInUserId = ctx.state.loggedInUser.id;
    } else {
      ctx.throw(401, "Unauthorized");
    }

    const fields = [
      "salespersonName",
      "salespersonPhoneNumber",
      "storeName",
      "storeAddressLine1",
      "storeAddressLine2",
      "landmark",
      "pincode",
      "city",
      "district",
      "state",
      "invitationDate",
    ];
    ctx.request.query = { filters: { id: loggedInUserId }, fields };
    try {
      const primaryUser: any = await strapi
        .controller("api::primaryuser.primaryuser")
        .findRecord(ctx, next);
      const response = modifiedStrapiResponse(primaryUser.data);
      // TODO: change the service method and call the method from productCatgory only
      const productCategories = await strapi
        .service("api::retailer-category.retailer-category")
        .getProductCategoriesByRetailerId(loggedInUserId);

      ctx.body = {
        data: { ...response.data, ...{ categoryNames: productCategories } },
      };
    } catch (err) {
      ctx.body = err;
    }
  },

  async getBankKycDetails(ctx, next) {
    let loggedInUserId = null;
    if (ctx.state.user.role?.name === UserRole.PRIMARY_USER) {
      loggedInUserId = ctx.state.loggedInUser.id;
    } else {
      ctx.throw(401, "Unauthorized");
    }
    const fields = [
      "gstIn",
      "gstStatus",
      "bussinessPanCardNo",
      "aadharNumber",
      "accountNumber",
      "accountHolderName",
      "bankName",
      "ifscCode",
    ];
    ctx.request.query = { filters: { id: loggedInUserId }, fields };
    try {
      const response: any = await strapi
        .controller("api::primaryuser.primaryuser")
        .findRecord(ctx, next);
      ctx.body = modifiedStrapiResponse(response.data);
    } catch (err) {
      ctx.body = err;
    }
  },

  async updateBankKycDetails(ctx, next) {
    let loggedInUserId = null;
    if (ctx.state.user.role?.name === UserRole.PRIMARY_USER) {
      loggedInUserId = ctx.state.loggedInUser.id;
    } else {
      ctx.throw(401, "Unauthorized");
    }
    // TODO: check and validate the aadhar number with calling the API
    ctx.request.params.id = loggedInUserId;
    try {
      const response = await strapi
        .controller("api::primaryuser.primaryuser")
        .updateRecord(ctx, next);
      ctx.body = response;
    } catch (err) {
      ctx.body = err;
    }
  },

  async getDealtCategories(ctx, next) {
    let loggedInUserId = null;
    if (ctx.state.user.role?.name === UserRole.PRIMARY_USER) {
      loggedInUserId = ctx.state.loggedInUser.id;
    } else {
      ctx.throw(401, "Unauthorized");
    }

    try {
      const dealtCategories = [];
      const retailerCategories = await strapi
        .service("api::retailer-category.retailer-category")
        .getSapActiveCategories(loggedInUserId);

      if (retailerCategories && retailerCategories.length) {
        for (const rCategory of retailerCategories) {
          const { partnerName } = await strapi
            .service("api::primaryuser.primaryuser")
            .getPartnerNameByRetailerId(rCategory.retailerPartnerId);

          const retailerCategorySalesAssociation = await strapi.db
            .query("api::sales-user-category.sales-user-category")
            .findOne({ where: { categoryId: rCategory.categoryId } });

          const { categoryName } = await strapi
            .service("api::category.category")
            .getCategoryByCategoryId(rCategory.categoryId);
          let salesUser = { name: "", mobileNumber: "" };
          if (retailerCategorySalesAssociation) {
            salesUser = await strapi.db
              .query("api::sales-user.sales-user")
              .findOne({
                select: ["name", "mobileNumber"],
                where: {
                  salesUserId: retailerCategorySalesAssociation.salesUserId,
                },
              });
          }

          dealtCategories.push({
            categoryName: categoryName || "",
            partnerName,
            relation: rCategory.relation,
            invoiceDate: rCategory.invoiceDate,
            salesPersonName: salesUser.name,
            salesPersonContact: salesUser.mobileNumber,
          });
        }
      }

      ctx.body = {
        data: dealtCategories,
      };
    } catch (err) {
      console.log("Error while fetching dealt categories", err);
      ctx.body = err;
    }
  },
};
