export default {
  routes: [
    {
      method: "GET",
      path: "/profile/personalDetails",
      handler: "profile.getPersonalDetails",
    },
    {
      method: "PUT",
      path: "/profile/personalDetails",
      handler: "profile.update",
    },
    {
      method: "PUT",
      path: "/profile/profilePhoto",
      handler: "profile.update",
    },
    {
      method: "GET",
      path: "/profile/businessDetails",
      handler: "profile.getBusinessDetails",
    },
    {
      method: "GET",
      path: "/profile/bankKycDetails",
      handler: "profile.getBankKycDetails",
    },
    {
      method: "PUT",
      path: "/profile/bankKycDetails",
      handler: "profile.updateBankKycDetails",
    },
    {
      method: "GET",
      path: "/profile/dealt-categories",
      handler: "profile.getDealtCategories",
    },
  ],
};
