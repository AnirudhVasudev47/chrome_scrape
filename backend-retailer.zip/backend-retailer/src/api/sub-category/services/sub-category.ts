/**
 * sub-category service
 */

import { factories } from "@strapi/strapi";

export default factories.createCoreService(
  "api::sub-category.sub-category",
  ({ strapi }) => ({
    async getSubCategoryBySubCategoryId(subCategoryId: string) {
      const subCategory = await strapi.db
        .query("api::sub-category.sub-category")
        .findOne({ where: { subCategoryId } });
      return subCategory;
    },

    async getSubCategoriesByCategoryId(
      categoryId: string,
      fields = ["subCategoryId", "subCategoryName"]
    ) {
      const subCategories = await strapi.db
        .query("api::sub-category.sub-category")
        .findMany({ where: { categoryId }, select: fields });
      return subCategories;
    },

    async getSubCategoryById(
      subCategoryId: string,
      fields = ["subCategoryId", "subCategoryName"]
    ) {
      const subCategory = await strapi.db
        .query("api::sub-category.sub-category")
        .findOne({ where: { subCategoryId }, select: fields });
      return subCategory;
    },
  })
);
