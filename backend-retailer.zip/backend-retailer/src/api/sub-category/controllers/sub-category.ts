/**
 * sub-category controller
 */

import { factories } from "@strapi/strapi";

export default factories.createCoreController(
  "api::sub-category.sub-category",
  ({ strapi }) => ({
    async findSubCategoryBySubCategoryIds(ctx,subCategoryId) {
      ctx.request.query = {
        filters: {
          subCategoryId: {
            $in: subCategoryId,
          }
        },
        fields : ["subCategoryName","subCategoryId"]
      };
      let { data } = await super.find(ctx);
      const subCategoryData: any = {}
      data.forEach((e) => {
        subCategoryData[e.attributes.subCategoryId] = e.attributes.subCategoryName
      });
      return subCategoryData;
    },
  })
);
