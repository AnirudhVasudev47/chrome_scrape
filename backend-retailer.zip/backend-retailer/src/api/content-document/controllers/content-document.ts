/**
 * content-document controller
 */

import { factories } from "@strapi/strapi";

export default factories.createCoreController(
  "api::content-document.content-document",
  ({ strapi }) => ({
    async create(ctx) {
      const data = await strapi
        .service("api::content-document.content-document")
        .uploadDocument(ctx.request.body);
      return data;
    },
  })
);
