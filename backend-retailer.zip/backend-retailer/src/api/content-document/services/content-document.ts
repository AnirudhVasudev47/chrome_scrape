/**
 * content-document service
 */

import { factories } from "@strapi/strapi";
import { currentFormattedDate } from "../../../utils/helperFuntions";

export default factories.createCoreService(
  "api::content-document.content-document",
  ({ strapi }) => ({
    async uploadDocument({ data }) {
      let createdContentDocument = await strapi
        .service("api::content-document.content-document")
        .create({
          data: {
            title: data.title,
            uploadedAt: currentFormattedDate(),
          },
        });

      /**
       * TODO:  once data is sync with app flow,
       * doing for syncing the lead product image in "content-document-link" table
       **/
      createdContentDocument = await strapi.db
        .query("api::content-document.content-document")
        .update({
          where: {
            contentDocumentCode: createdContentDocument.contentDocumentCode,
          },
          data: {
            contentDocumentId: createdContentDocument.contentDocumentCode,
          },
        });

      if (createdContentDocument) {
        await strapi
          .service("api::content-document-link.content-document-link")
          .create({
            data: {
              contentDocumentId: createdContentDocument.contentDocumentId,
              linkedEntityId: data.linkedEntityId,
            },
          });
        await strapi.service("api::content-version.content-version").create({
          data: {
            contentDocumentId: createdContentDocument.contentDocumentId,
            versionData: data.versionData,
            contentUrl: data.contentUrl || "",
          },
        });
      }
      return createdContentDocument;
    },
  })
);
