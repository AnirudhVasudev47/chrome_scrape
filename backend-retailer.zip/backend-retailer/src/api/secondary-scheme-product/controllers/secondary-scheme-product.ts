/**
 * secondary-scheme-product controller
 */

import { factories } from "@strapi/strapi";

export default factories.createCoreController("api::secondary-scheme-product.secondary-scheme-product");
