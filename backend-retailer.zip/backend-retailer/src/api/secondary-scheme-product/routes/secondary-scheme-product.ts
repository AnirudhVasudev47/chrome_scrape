/**
 * secondary-scheme-product router
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::secondary-scheme-product.secondary-scheme-product');
