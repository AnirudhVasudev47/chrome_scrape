/**
 * secondary-scheme-product service
 */

import { factories } from "@strapi/strapi";
import { defaultPaginationConfig } from "../../../constants";

export default factories.createCoreService(
  "api::secondary-scheme-product.secondary-scheme-product",
  ({ strapi }) => ({
    async findSKUProducts(ctx, secondarySchemeId) {
        const data = await strapi.db.query("api::secondary-scheme-product.secondary-scheme-product").findMany({
            select : ["skuProduct"],
            where : {secondarySchemeProductsId : secondarySchemeId}
        })
        return { data };
      },
  })
);
