/**
 * secondary-scheme-slab router
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::secondary-scheme-slab.secondary-scheme-slab');
