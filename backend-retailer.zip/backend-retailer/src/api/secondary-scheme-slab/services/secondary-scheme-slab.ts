/**
 * secondary-scheme-slab service
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreService('api::secondary-scheme-slab.secondary-scheme-slab');
