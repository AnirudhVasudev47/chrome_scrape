/**
 * support-type-subtype-mapping router
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::support-type-subtype-mapping.support-type-subtype-mapping');
