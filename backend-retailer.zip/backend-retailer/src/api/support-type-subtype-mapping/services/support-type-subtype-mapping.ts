/**
 * support-type-subtype-mapping service
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreService('api::support-type-subtype-mapping.support-type-subtype-mapping');
