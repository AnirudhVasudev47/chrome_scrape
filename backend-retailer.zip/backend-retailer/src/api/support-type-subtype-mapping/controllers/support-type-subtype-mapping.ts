/**
 * support-type-subtype-mapping controller
 */

import { factories } from '@strapi/strapi'

export default factories.createCoreController('api::support-type-subtype-mapping.support-type-subtype-mapping');
