/**
 * notification-type controller
 */

import { factories } from '@strapi/strapi'

export default factories.createCoreController('api::notification-type.notification-type');
