/**
 * user-device controller
 */

import {factories} from '@strapi/strapi'

export default factories.createCoreController('api::user-device.user-device',
  ({strapi}) => ({
    async find(ctx) {
      ctx.request.query = {
        populate: '*',
        filters: {
          retailerId: ctx.state.loggedInUser.retailerId
        }
      }
      const {data, meta} = await super.find(ctx);
      return {data, meta};
    }
  })
);
