export const MOBILE_NUMBER_REGEX = /^[6789]\d{9}$/;
export const OTP_REGEX = /^\d{6}$/;
