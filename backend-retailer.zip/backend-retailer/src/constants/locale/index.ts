import * as en from "./en.json";
import * as hi from "./hi.json";

enum Language {
  EN = "en",
  HI = "hi",
}

type ResponseMessage = {
  [key in Language]: { [key: string]: string };
};

export const RESPONSE_MESSAGE: ResponseMessage = {
  [Language.EN]: en,
  [Language.HI]: hi,
};
