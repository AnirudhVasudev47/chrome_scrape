import {
  ProductAndPriceListContentType,
  SolarCategorySapDivisionCode,
} from "../enums";

export const defaultPaginationConfig = {
  page: 1,
  pageSize: 10,
};

export const solarCategorySapCode = [
  SolarCategorySapDivisionCode.SOLAR_WATER_HEATER_CODE,
  SolarCategorySapDivisionCode.SOLAR_POWER_SYSTEM_CODE,
];

export const productDocumentContentType = [
  ProductAndPriceListContentType.PRODUCT_TRAINING,
  ProductAndPriceListContentType.PRODUCT_FLYER,
  ProductAndPriceListContentType.PRODUCT_BROCHURE,
  ProductAndPriceListContentType.PRODUCT_SCHEME,
];

export const productVideoContentType = [
  ProductAndPriceListContentType.PRODUCT_TRAINING,
  ProductAndPriceListContentType.PRODUCT_DEMO,
  ProductAndPriceListContentType.PRODUCT_AD,
];

export const priceListContentType =
  ProductAndPriceListContentType.PRODUCT_PRICE_LIST_BOOK;
