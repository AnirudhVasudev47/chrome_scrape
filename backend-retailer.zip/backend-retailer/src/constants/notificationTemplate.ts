export enum SendInviteConst {
    notificationEndpoint = 'http://enterprise.smsgupshup.com/GatewayAPI/rest',
    notificationMethod = 'sendMessage',
    notificationMessage = 'Dear Customer thank you for calling V-Guard. All lines are busy. Please register your complaint in the attached link http://www.vguard.in/home/customer-care',
    notificationMsgType = 'TEXT',
    notificationUserId = '2000120010',
    notificationPassword = 'bgxtmsVfj',
    notificationAuthScheme = 'plain',
    notificationVersion = '1.1',
    notificationFormat = 'text',
    
    inviteLinkMessage = `Hello {0}, Welcome to the V-Guard program for retailers. Please use the link below to download the app -
    Android - {1}
    iOS - {2}
    Regards,
    V-Guard`,
    androidInviteLink = 'https://play.google.com/store/apps/details?id=com.tfl.vguardretailer&hl=en_GB&gl=US',
    iosInviteLink = 'https://apps.apple.com/in/app/v-guard-rishta/id1592806799',
    
    sendOtpMessage = `Dear Member, Use code {0} to login into your account. Never share your OTP with anyone. Team V-Guard Rishta!`}