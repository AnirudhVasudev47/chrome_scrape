export const OpenTicketStatuses = ["New", "Working", "Merged", "Pending"];
export const ClosedTicketStatuses = ["Success", "Failed", "Resolved"];
export const DateFilters = [
  "Last Week",
  "Custom Range",
  "Last Month",
  "Last Quarter",
];
export const TicketStatuses = [...OpenTicketStatuses, ...ClosedTicketStatuses];
