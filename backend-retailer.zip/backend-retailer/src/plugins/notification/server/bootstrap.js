'use strict';

const {beforeCreate, afterCreate, afterDelete} = require("./content-types/notification/lifecycles");
const {initAdmin} = require('./util/firebase')

module.exports = ({strapi}) => {
	// bootstrap phase

	initAdmin();
	console.log('this is run ');

	strapi.db.lifecycles.subscribe((event) => {
		if (event.model.uid === 'plugin::notification.notification') {
			if (event.action === 'beforeCreate') {
				beforeCreate(event)
			}
			if (event.action === 'afterCreate') {
				afterCreate(event)
			}
			if (event.action === 'afterDelete') {
				afterDelete(event)
			}
		} else if (event.model.uid === 'plugin::notification.config') {
			if (event.action === 'afterCreate') {
				initAdmin();
			}
		}
	});
};
