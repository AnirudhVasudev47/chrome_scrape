const Queue = require('bull');
const short = require("short-uuid");

const notificationEmailQueue = new Queue('notification_email_queue', {
	redis: {
		host: '127.0.0.1',
		port: 6379,
	}
});
const notificationSmsQueue = new Queue('notification_sms_queue', {
	redis: {
		host: '127.0.0.1',
		port: 6379,
	}
});
const notificationPushQueue = new Queue('notification_push_queue', {
	redis: {
		host: '127.0.0.1',
		port: 6379,
	}
});

const NOTIFYJOB = short.generate()

const addToQueue = async (data = null) => {
	if (data !== null) {
		// let data = {
		//   "id": 1,
		//   "type": "Push Notification",
		//   "to": "c3432weqqw",
		//   "title": "qweqweqwe",
		//   "message": "qweqweqweqwe",
		//   "start": "2024-03-13T19:15:00.000Z",
		//   "end": "2024-03-21T19:15:00.000Z",
		//   "createdAt": "2024-03-10T19:04:19.431Z",
		//   "updatedAt": "2024-03-13T02:32:20.426Z",
		//   "uuid": "qweqweqweqwe",
		//   "hasEnding": false,
		//   "repeat": 'None'
		// }
		let cronString = getCronString(data.start, data.repeat)
		const options = {
			attempts: 3,
			repeat: {
				cron: cronString,
			},
		};

		switch (data.type.toLowerCase()) {
			case 'push notification':
				notificationPushQueue.add(NOTIFYJOB, data, options).then(async resp => {
					console.log('New event added')
					console.log('resp: ', resp)
					const jobKey = resp.opts.repeat.key;
					await strapi
						.entityService
						.update("plugin::notification.notification", data.id, {
							data: {
								jobId: jobKey,
							}
						});
				}).catch(e => {
					console.log('error: ', e)
				});
				break;
			case 'sms':
				notificationSmsQueue.add(NOTIFYJOB, data, options).then(async resp => {
					console.log('New event added')
					const jobKey = resp.opts.repeat.key;
					await strapi
						.entityService
						.update("plugin::notification.notification", data.id, {
							data: {
								jobId: jobKey,
							}
						});
				}).catch(e => {
					console.log('error: ', e)
				});
				break;
			case 'email':
				notificationEmailQueue.add(NOTIFYJOB, data, options).then(async resp => {
					console.log('New event added')
					const jobKey = resp.opts.repeat.key;
					await strapi
						.entityService
						.update("plugin::notification.notification", data.id, {
							data: {
								jobId: jobKey,
							}
						});
				}).catch(e => {
					console.log('error: ', e)
				});
				break;
			default:
				return;
		}
	}
}

const deleteFromQueue = async (data = null) => {
	if (data !== null) {
		switch (data.type.toLowerCase()) {
			case 'push notification':
				await notificationPushQueue.removeRepeatableByKey(data.jobId)
				break;
			case 'sms':
				await notificationSmsQueue.removeRepeatableByKey(data.jobId);
				break;
			case 'email':
				await notificationEmailQueue.removeRepeatableByKey(data.jobId);
				break;
			default:
				return;
		}
	}
}

notificationPushQueue.process(NOTIFYJOB, async (job) => {
	const {sendPush} = require("../services/send_push");
	const now = new Date();
	let data = job.data
	const endDate = new Date(data.end);

	if (data.hasEnding && now > endDate) {
		console.log('ending job!!')
		await notificationPushQueue.removeRepeatableByKey(job.opts.repeat.key);
	}

	await sendPush(data);
})

notificationEmailQueue.process(NOTIFYJOB, async (job) => {
	const {sendEmail} = require("../services/send_email");
	const now = new Date();
	let data = job.data
	const endDate = new Date(data.end);

	if (data.hasEnding && now > endDate) {
		console.log('ending job!!')
		await notificationEmailQueue.removeRepeatableByKey(job.opts.repeat.key);
	}

	await sendEmail(data);
})

notificationSmsQueue.process(NOTIFYJOB, async (job) => {
	const {sendSms} = require("../services/send_sms");
	const now = new Date();
	let data = job.data
	const endDate = new Date(data.end);

	if (data.hasEnding && now > endDate) {
		console.log('ending job!!')
		await notificationSmsQueue.removeRepeatableByKey(job.opts.repeat.key);
	}

	await sendSms(data);
})

// ------------------------------- Helper Function ------------------------------- //

const getCronString = (date, occurrence) => {

	const scheduleDate = new Date(date);

	const minute = scheduleDate.getMinutes();
	const hour = scheduleDate.getHours();
	const dayOfMonth = scheduleDate.getDate();
	const month = scheduleDate.getMonth() + 1; // getMonth() returns 0-11
	const dayOfWeek = scheduleDate.getDay(); // getDay() returns 0-6 (0 for Sunday)

	let cronString;
	switch (occurrence.toLowerCase()) {
		case 'none':
			cronString = `${minute} ${hour} ${dayOfMonth} ${month} *`;
			break;
		case 'monthly':
			cronString = `${minute} ${hour} ${dayOfMonth} * *`;
			break;
		case 'weekly':
			cronString = `${minute} ${hour} * * ${dayOfWeek}`;
			break;
		case 'daily':
			cronString = `${minute} ${hour} * * *`;
			break;
		case 'yearly':
			cronString = `${minute} ${hour} ${dayOfMonth} ${month} *`;
			break;
		default:
			throw new Error('Unsupported occurrence type');
	}

	return cronString;
}


module.exports = {
	addToQueue,
	deleteFromQueue
};
