'use strict';

module.exports = ({ strapi }) => {
  // register phase
};
