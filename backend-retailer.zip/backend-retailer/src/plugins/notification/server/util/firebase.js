const initAdmin = async () => {

	const resp = await strapi
		.entityService
		.findMany("plugin::notification.config", {
			fields: ['title', 'value'],
			filters: {
				title: {
					$eq: 'config',
				},
			},
		})

	if (resp.length !== 0) {
		const data = resp[0].value

		const admin = require('firebase-admin');

		let serviceAccount = JSON.parse(data.firebase);
		if (admin.apps.length === 0)
			admin.initializeApp({
				credential: admin.credential.cert(serviceAccount)
			});
	}
}

module.exports = {
  initAdmin
}
