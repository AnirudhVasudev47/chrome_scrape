module.exports = ([
	{
		method: "GET",
		path: "/",
		handler: "myNotificationController.index",
		config: {
			policies: [],
			auth: false,
		},
	},

	{
		method: "GET",
		path: "/config",
		handler: "myNotificationController.getConfig",
		config: {
			policies: [],
			auth: false,
		},
	},

	{
		method: "POST",
		path: "/config/update",
		handler: "myNotificationController.updateConfig",
		config: {
			policies: [],
			auth: false,
		},
	},

	{
		method: "GET",
		path: "/find",
		handler: "myNotificationController.find",
		config: {
			policies: [],
			auth: false,
		},
	},

	{
		method: "GET",
		path: "/find/:id",
		handler: "myNotificationController.findOne",
		config: {
			policies: [],
			auth: false,
		},
	},

	{
		method: "POST",
		path: "/create",
		handler: "myNotificationController.create",
		config: {
			policies: [],
			auth: false,
		},
	},

	{
		method: "DELETE",
		path: "/delete/:id",
		handler: "myNotificationController.delete",
		config: {
			policies: [],
			auth: false,
		},
	},

	{
		method: "PUT",
		path: "/update/:id",
		handler: "myNotificationController.update",
		config: {
			policies: [],
			auth: false,
		},
	},

]);
