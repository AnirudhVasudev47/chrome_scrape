module.exports = {
    beforeCreate(event) {
        const {data, where, select, populate} = event.params;
    },

    afterCreate(event) {
        const {addToQueue} = require("../../queues/queue-service");
        const {result, params} = event;

        addToQueue(result).then(r => {
            console.log('result: ', result)
        });
    },

    afterDelete(event) {
        const {deleteFromQueue} = require("../../queues/queue-service");
        const {result, params} = event;

      deleteFromQueue(result).then(r => {
            console.log('result: ', result)
        });
    },
};
