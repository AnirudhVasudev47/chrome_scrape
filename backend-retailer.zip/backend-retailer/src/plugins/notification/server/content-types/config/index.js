const schema = require('./schema.json');

module.exports = {
  schema,
}
