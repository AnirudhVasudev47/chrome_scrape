'use strict';
const notification = require('./notification')
const config = require('./config')
module.exports = {
	notification,
	config
};
