const sendEmail = async (jobData) => {
  console.log('Email triggered, data: ',jobData)

  return true;
}

module.exports = {sendEmail};
