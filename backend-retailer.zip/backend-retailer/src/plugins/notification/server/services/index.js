'use strict';

const notificationService = require('./notification-service');


module.exports = {
  notificationService,
};
