const sendPush = async (jobData) => {
	// let data = {
	//   "id": 1,
	//   "type": "Push Notification",
	//   "to": "c3432weqqw",
	//   "title": "qweqweqwe",
	//   "message": "qweqweqweqwe",
	//   "start": "2024-03-13T19:15:00.000Z",
	//   "end": "2024-03-21T19:15:00.000Z",
	//   "createdAt": "2024-03-10T19:04:19.431Z",
	//   "updatedAt": "2024-03-13T02:32:20.426Z",
	//   "uuid": "qweqweqweqwe",
	//   "hasEnding": false,
	//   "repeat": 'None'
	// }

	const resp = await strapi
		.entityService
		.findMany("plugin::notification.config", {
			fields: ['title', 'value'],
			filters: {
				title: {
					$eq: 'config',
				},
			},
		})

	console.log('Push triggered, data: ', jobData)
	if (resp.length !== 0) {


		const admin = require('firebase-admin');

		console.log('Push triggered, data: ', jobData)

		let to = await getUserDevices();

		const message = {
			notification: {
				title: jobData.title,
				body: jobData.message
			},
		};
		admin.messaging().sendEachForMulticast({
			tokens: to,
			notification: message.notification,
		})
			.then((response) => {
				console.log('Successfully sent message:', response);
			})
			.catch((error) => {
				console.log('Error sending message:', error);
			});


		return true;
	}
}

const getUserDevices = async () => {
	const deviceArr = await strapi.entityService.findMany('api::user-device.user-device', {
		filters: {title: 'Hello World'},
		populate: '*'
	})
	let deviceList = [];

	deviceArr.map((device) => {
		deviceList.push(device.fcmToken)
	})

	return deviceList;
}


module.exports = {sendPush};
