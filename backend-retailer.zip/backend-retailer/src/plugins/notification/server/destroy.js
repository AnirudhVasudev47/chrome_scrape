'use strict';

module.exports = ({ strapi }) => {
  // destroy phase
};
