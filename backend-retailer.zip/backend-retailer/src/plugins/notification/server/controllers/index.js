'use strict';

const myNotificationController = require('./notification-controller');

module.exports = {
  myNotificationController,
};
