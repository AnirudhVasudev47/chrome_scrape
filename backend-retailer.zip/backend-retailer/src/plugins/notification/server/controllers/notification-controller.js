'use strict';

module.exports = ({strapi}) => ({

	index() {
		return 'Welcome to Strapi 🚀';
	},

	async getConfig(ctx) {
		try {
			const result = await strapi
				.entityService
				.findMany("plugin::notification.config", {
					fields: ['title', 'value'],
					filters: {
						title: {
							$eq: 'config',
						},
					},
				})

			return result;
		} catch (err) {
			ctx.throw(500, err);
		}
	},


	async updateConfig(ctx) {
		try {
			const resp = await strapi
				.entityService
				.findMany("plugin::notification.config", {
					fields: ['title', 'value'],
					filters: {
						title: {
							$eq: 'config',
						},
					},
				})

			console.log('data: ', ctx.request.body, '\nresult: ', resp)

			let result;

			if (resp.length === 0) {
				result = await strapi.entityService.create('plugin::notification.config', {
					data: {
						title: 'config',
						value: ctx.request.body
					},
				});
			} else {
				result = await strapi.entityService.update('plugin::notification.config', resp[0].id, {
					data: {
						title: 'config',
						value: ctx.request.body
					},
				});
			}

			return result;
		} catch (err) {
			ctx.throw(500, err);
		}
	},

	async find(ctx) {
		try {
			return await strapi
				.entityService
				.findMany("plugin::notification.notification", ctx.query)
		} catch (err) {
			ctx.throw(500, err);
		}
	},

	async findOne(ctx) {
		try {
			return await strapi
				.entityService
				.findOne("plugin::notification.notification", ctx.params.id)
		} catch (err) {
			ctx.throw(500, err);
		}
	},

	async delete(ctx) {
		try {
			return await strapi
				.entityService
				.delete("plugin::notification.notification", ctx.params.id);
		} catch (err) {
			ctx.throw(500, err);
		}
	},

	async create(ctx) {
		try {
			return await strapi
				.entityService
				.create("plugin::notification.notification", ctx.request.body);
		} catch (err) {
			ctx.throw(500, err);
		}
	},

	async update(ctx) {
		try {
			return await strapi
				.entityService
				.update("plugin::notification.notification", ctx.params.id, ctx.request.body);
		} catch (err) {
			ctx.throw(500, err);
		}
	},
});
