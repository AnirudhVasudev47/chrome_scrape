/**
 *
 * PluginIcon
 *
 */

import React from 'react';
import { Bell } from '@strapi/icons';

const PluginIcon = () => <Bell />;

export default PluginIcon;
