import React, {useEffect, useState} from "react";
import {
	Button,
	DateTimePicker,
	GridLayout,
	ModalBody,
	ModalFooter,
	ModalHeader,
	ModalLayout,
	SingleSelect,
	SingleSelectOption,
	Textarea,
	TextInput,
	ToggleInput,
	Typography,
	Tabs, Tab, TabGroup, TabPanels, TabPanel, Box, JSONInput, Loader
} from "@strapi/design-system";
import notificationRequests from "../../api/notification";

const ModalConfigPlugin = ({data, isNew = true, onClose, onFinish}) => {

	const [form, setForm] = useState({
		isLoading: true,
		data: {
			firebase: '',
			redis_host: '',
			redis_port: '',
			sms_userId: '',
			sms_password: '',
		}
	})
	const updateForm = (fieldName, data) => {
		return setForm({
			...form,
			data: {
				...form.data,
				[fieldName]: data,
			}
		})
	}

	useEffect(() => {
		const fetchData = async () => {
			const config = await notificationRequests.getPluginConfig();

			if (config.length !== 0) {
				console.log("config: ", config[0].value)
				let confObj = config[0].value;
				setForm({
					...form,
					isLoading: false,
					data: confObj,
				})
			} else {
				setForm({
					...form,
					isLoading: false,
				})
			}
		}

		fetchData()

	}, [])

	return (
		<ModalLayout onClose={onClose} labelledBy="title">
			<ModalHeader>
				<Typography fontWeight="bold" textColor="neutral800" as="h2" id="title">
					Configure the pluign
				</Typography>
			</ModalHeader>
			<ModalBody>
				{form.isLoading
					? <div
						style={{
							display: "flex",
							flexDirection: "column",
							alignItems: "center",
							justifyContent: "center",
						}}>
						<Loader/>
						<h3 style={{
							color: 'white'
						}}>Loading...</h3>
					</div>
					: <Box padding={8} background="primary100">
						<TabGroup label="Some stuff for the label" id="tabs"
								  onTabChange={selected => console.log(selected)}>
							<Tabs>
								<Tab>Redis Config</Tab>
								<Tab>Firebase Config</Tab>
								<Tab>SMS</Tab>
								<Tab>Email</Tab>
							</Tabs>
							<TabPanels>
								<TabPanel>
									<Box color="neutral800" padding={4} background="neutral0">
										<TextInput placeholder="Enter the host URL of the Redis server" label="Host"
												   name="host" value={form.data.redis_host} hint=" "
												   onChange={e => updateForm('redis_host', e.target.value)}/>
										<TextInput placeholder="Enter the port of the Redis server" label="Port"
												   name="port" value={form.data.redis_port}
												   onChange={e => updateForm('redis_port', e.target.value)}/>
									</Box>
								</TabPanel>
								<TabPanel>
									<Box color="neutral800" padding={4} background={"neutral0"}>
										<JSONInput value={form.data.firebase} label="JSON"
												   minHeight="235px" error={''}
												   onChange={(value) => updateForm('firebase', value)}/>
									</Box>
								</TabPanel>
								<TabPanel>
									<Box color="neutral800" padding={4} background="neutral0">
										<TextInput placeholder="Enter the user id" label="User ID"
												   name="userId" value={form.data.sms_userId} hint=" "
												   onChange={e => updateForm('sms_userId', e.target.value)}/>
										<TextInput placeholder="Enter the password" label="Password"
												   name="password" value={form.data.sms_password}
												   onChange={e => updateForm('sms_password', e.target.value)}/>
									</Box>
								</TabPanel>
							</TabPanels>
						</TabGroup>
					</Box>}
			</ModalBody>
			<ModalFooter startActions={<Button onClick={onClose} variant="tertiary">
				Cancel
			</Button>} endActions={<>
				<Button onClick={() => onFinish(form.data)}>Finish</Button>
			</>}/>
		</ModalLayout>
	)
}

export default ModalConfigPlugin;
