/*
 *
 * HomePage
 *
 */

import React, {useEffect, useState} from 'react';
// import PropTypes from 'prop-types';
import pluginPkg from "../../../../package.json";
import {BaseHeaderLayout, Button, ContentLayout, EmptyStateLayout, Layout, Box, Flex} from '@strapi/design-system';
import {LoadingIndicatorPage} from "@strapi/helper-plugin";
import {Puzzle} from "@strapi/icons";
import ModalConfigPlugin from "../../components/ModalConfigPlugin";
import NotificationTable from "../../components/NotificationTable";
import EmptyIcon from "../../components/PluginIcon/EmptyIcon";
import notificationRequests from "../../api/notification";

const HomePage = () => {
	const [notificationStatus, setNotificationStatus] = useState({
		isLoading: true,
		isModalVisible: false,
	})
	const [notificationList, setNotificationList] = useState([])

	const fetchData = async () => {
		if (notificationStatus.isLoading === false) setNotificationStatus({
			...notificationStatus,
			isLoading: true
		});

		try {
			const notifications = await notificationRequests.getAllNotifications();

			setNotificationList([
				...notifications
			]);
		} catch (error) {
			console.log('error fetching notifications', error);
		} finally {
			setNotificationStatus({
				...notificationStatus,
				isLoading: false
			});
		}
	};

	async function editPluginConfig(id, data) {
		await notificationRequests.editPluginConfig(id, data);
		await fetchData();
	}

	const onAddNotification = () => setNotificationStatus({
		...notificationStatus,
		isModalVisible: true,
	})

	useEffect(() => {
		fetchData();
	}, []);

	if (notificationStatus.isLoading) return <LoadingIndicatorPage/>;

	return (
		<Layout>
			<BaseHeaderLayout
				primaryAction={
					<Flex gap={3}>
						<Button startIcon={<Puzzle/>} onClick={onAddNotification}>Configure</Button>
					</Flex>
				}
				title="Notification Plugin"
				as="h2"/>
			<ContentLayout>
				{notificationList.length === 0
					? <Box padding={8} background={"neutral100"}>
						<EmptyStateLayout
							icon={<EmptyIcon/>} content="You don't have any notification yet..."/>
					</Box>
					: <>
						<NotificationTable data={notificationList}/>
					</>}
			</ContentLayout>
			{notificationStatus.isModalVisible
				? <ModalConfigPlugin
					onFinish={(form) => editPluginConfig(form)}
					onClose={() => setNotificationStatus({
						...notificationStatus,
						isModalVisible: false,
					})}/>
				: null
			}
		</Layout>
	);
};

export default HomePage;
