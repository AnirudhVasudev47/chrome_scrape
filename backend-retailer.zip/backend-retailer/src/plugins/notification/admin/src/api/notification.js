import {request} from "@strapi/helper-plugin";

const notificationRequests = {
	getAllNotifications: async () => {
		return await request("/notification/find", {
			method: "GET",
		});
	},
	getPluginConfig: async () => {
		return await request("/notification/config", {
			method: "GET"
		});
	},
	editPluginConfig: async (data) => {
		return await request("/notification/config/update", {
			method: "POST",
			body: data,
		});
	},
};

export default notificationRequests;
