# Strapi plugin notification

A quick description of notification.
