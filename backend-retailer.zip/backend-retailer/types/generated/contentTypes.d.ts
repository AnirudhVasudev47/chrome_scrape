import type { Schema, Attribute } from '@strapi/strapi';

export interface AdminPermission extends Schema.CollectionType {
  collectionName: 'admin_permissions';
  info: {
    name: 'Permission';
    description: '';
    singularName: 'permission';
    pluralName: 'permissions';
    displayName: 'Permission';
  };
  pluginOptions: {
    'content-manager': {
      visible: false;
    };
    'content-type-builder': {
      visible: false;
    };
  };
  attributes: {
    action: Attribute.String &
      Attribute.Required &
      Attribute.SetMinMaxLength<{
        minLength: 1;
      }>;
    actionParameters: Attribute.JSON & Attribute.DefaultTo<{}>;
    subject: Attribute.String &
      Attribute.SetMinMaxLength<{
        minLength: 1;
      }>;
    properties: Attribute.JSON & Attribute.DefaultTo<{}>;
    conditions: Attribute.JSON & Attribute.DefaultTo<[]>;
    role: Attribute.Relation<'admin::permission', 'manyToOne', 'admin::role'>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'admin::permission',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'admin::permission',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface AdminUser extends Schema.CollectionType {
  collectionName: 'admin_users';
  info: {
    name: 'User';
    description: '';
    singularName: 'user';
    pluralName: 'users';
    displayName: 'User';
  };
  pluginOptions: {
    'content-manager': {
      visible: false;
    };
    'content-type-builder': {
      visible: false;
    };
  };
  attributes: {
    firstname: Attribute.String &
      Attribute.SetMinMaxLength<{
        minLength: 1;
      }>;
    lastname: Attribute.String &
      Attribute.SetMinMaxLength<{
        minLength: 1;
      }>;
    username: Attribute.String;
    email: Attribute.Email &
      Attribute.Required &
      Attribute.Private &
      Attribute.Unique &
      Attribute.SetMinMaxLength<{
        minLength: 6;
      }>;
    password: Attribute.Password &
      Attribute.Private &
      Attribute.SetMinMaxLength<{
        minLength: 6;
      }>;
    resetPasswordToken: Attribute.String & Attribute.Private;
    registrationToken: Attribute.String & Attribute.Private;
    isActive: Attribute.Boolean &
      Attribute.Private &
      Attribute.DefaultTo<false>;
    roles: Attribute.Relation<'admin::user', 'manyToMany', 'admin::role'> &
      Attribute.Private;
    blocked: Attribute.Boolean & Attribute.Private & Attribute.DefaultTo<false>;
    preferedLanguage: Attribute.String;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<'admin::user', 'oneToOne', 'admin::user'> &
      Attribute.Private;
    updatedBy: Attribute.Relation<'admin::user', 'oneToOne', 'admin::user'> &
      Attribute.Private;
  };
}

export interface AdminRole extends Schema.CollectionType {
  collectionName: 'admin_roles';
  info: {
    name: 'Role';
    description: '';
    singularName: 'role';
    pluralName: 'roles';
    displayName: 'Role';
  };
  pluginOptions: {
    'content-manager': {
      visible: false;
    };
    'content-type-builder': {
      visible: false;
    };
  };
  attributes: {
    name: Attribute.String &
      Attribute.Required &
      Attribute.Unique &
      Attribute.SetMinMaxLength<{
        minLength: 1;
      }>;
    code: Attribute.String &
      Attribute.Required &
      Attribute.Unique &
      Attribute.SetMinMaxLength<{
        minLength: 1;
      }>;
    description: Attribute.String;
    users: Attribute.Relation<'admin::role', 'manyToMany', 'admin::user'>;
    permissions: Attribute.Relation<
      'admin::role',
      'oneToMany',
      'admin::permission'
    >;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<'admin::role', 'oneToOne', 'admin::user'> &
      Attribute.Private;
    updatedBy: Attribute.Relation<'admin::role', 'oneToOne', 'admin::user'> &
      Attribute.Private;
  };
}

export interface AdminApiToken extends Schema.CollectionType {
  collectionName: 'strapi_api_tokens';
  info: {
    name: 'Api Token';
    singularName: 'api-token';
    pluralName: 'api-tokens';
    displayName: 'Api Token';
    description: '';
  };
  pluginOptions: {
    'content-manager': {
      visible: false;
    };
    'content-type-builder': {
      visible: false;
    };
  };
  attributes: {
    name: Attribute.String &
      Attribute.Required &
      Attribute.Unique &
      Attribute.SetMinMaxLength<{
        minLength: 1;
      }>;
    description: Attribute.String &
      Attribute.SetMinMaxLength<{
        minLength: 1;
      }> &
      Attribute.DefaultTo<''>;
    type: Attribute.Enumeration<['read-only', 'full-access', 'custom']> &
      Attribute.Required &
      Attribute.DefaultTo<'read-only'>;
    accessKey: Attribute.String &
      Attribute.Required &
      Attribute.SetMinMaxLength<{
        minLength: 1;
      }>;
    lastUsedAt: Attribute.DateTime;
    permissions: Attribute.Relation<
      'admin::api-token',
      'oneToMany',
      'admin::api-token-permission'
    >;
    expiresAt: Attribute.DateTime;
    lifespan: Attribute.BigInteger;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'admin::api-token',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'admin::api-token',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface AdminApiTokenPermission extends Schema.CollectionType {
  collectionName: 'strapi_api_token_permissions';
  info: {
    name: 'API Token Permission';
    description: '';
    singularName: 'api-token-permission';
    pluralName: 'api-token-permissions';
    displayName: 'API Token Permission';
  };
  pluginOptions: {
    'content-manager': {
      visible: false;
    };
    'content-type-builder': {
      visible: false;
    };
  };
  attributes: {
    action: Attribute.String &
      Attribute.Required &
      Attribute.SetMinMaxLength<{
        minLength: 1;
      }>;
    token: Attribute.Relation<
      'admin::api-token-permission',
      'manyToOne',
      'admin::api-token'
    >;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'admin::api-token-permission',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'admin::api-token-permission',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface AdminTransferToken extends Schema.CollectionType {
  collectionName: 'strapi_transfer_tokens';
  info: {
    name: 'Transfer Token';
    singularName: 'transfer-token';
    pluralName: 'transfer-tokens';
    displayName: 'Transfer Token';
    description: '';
  };
  pluginOptions: {
    'content-manager': {
      visible: false;
    };
    'content-type-builder': {
      visible: false;
    };
  };
  attributes: {
    name: Attribute.String &
      Attribute.Required &
      Attribute.Unique &
      Attribute.SetMinMaxLength<{
        minLength: 1;
      }>;
    description: Attribute.String &
      Attribute.SetMinMaxLength<{
        minLength: 1;
      }> &
      Attribute.DefaultTo<''>;
    accessKey: Attribute.String &
      Attribute.Required &
      Attribute.SetMinMaxLength<{
        minLength: 1;
      }>;
    lastUsedAt: Attribute.DateTime;
    permissions: Attribute.Relation<
      'admin::transfer-token',
      'oneToMany',
      'admin::transfer-token-permission'
    >;
    expiresAt: Attribute.DateTime;
    lifespan: Attribute.BigInteger;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'admin::transfer-token',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'admin::transfer-token',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface AdminTransferTokenPermission extends Schema.CollectionType {
  collectionName: 'strapi_transfer_token_permissions';
  info: {
    name: 'Transfer Token Permission';
    description: '';
    singularName: 'transfer-token-permission';
    pluralName: 'transfer-token-permissions';
    displayName: 'Transfer Token Permission';
  };
  pluginOptions: {
    'content-manager': {
      visible: false;
    };
    'content-type-builder': {
      visible: false;
    };
  };
  attributes: {
    action: Attribute.String &
      Attribute.Required &
      Attribute.SetMinMaxLength<{
        minLength: 1;
      }>;
    token: Attribute.Relation<
      'admin::transfer-token-permission',
      'manyToOne',
      'admin::transfer-token'
    >;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'admin::transfer-token-permission',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'admin::transfer-token-permission',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface PluginUploadFile extends Schema.CollectionType {
  collectionName: 'files';
  info: {
    singularName: 'file';
    pluralName: 'files';
    displayName: 'File';
    description: '';
  };
  pluginOptions: {
    'content-manager': {
      visible: false;
    };
    'content-type-builder': {
      visible: false;
    };
  };
  attributes: {
    name: Attribute.String & Attribute.Required;
    alternativeText: Attribute.String;
    caption: Attribute.String;
    width: Attribute.Integer;
    height: Attribute.Integer;
    formats: Attribute.JSON;
    hash: Attribute.String & Attribute.Required;
    ext: Attribute.String;
    mime: Attribute.String & Attribute.Required;
    size: Attribute.Decimal & Attribute.Required;
    url: Attribute.String & Attribute.Required;
    previewUrl: Attribute.String;
    provider: Attribute.String & Attribute.Required;
    provider_metadata: Attribute.JSON;
    related: Attribute.Relation<'plugin::upload.file', 'morphToMany'>;
    folder: Attribute.Relation<
      'plugin::upload.file',
      'manyToOne',
      'plugin::upload.folder'
    > &
      Attribute.Private;
    folderPath: Attribute.String &
      Attribute.Required &
      Attribute.Private &
      Attribute.SetMinMax<{
        min: 1;
      }>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'plugin::upload.file',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'plugin::upload.file',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface PluginUploadFolder extends Schema.CollectionType {
  collectionName: 'upload_folders';
  info: {
    singularName: 'folder';
    pluralName: 'folders';
    displayName: 'Folder';
  };
  pluginOptions: {
    'content-manager': {
      visible: false;
    };
    'content-type-builder': {
      visible: false;
    };
  };
  attributes: {
    name: Attribute.String &
      Attribute.Required &
      Attribute.SetMinMax<{
        min: 1;
      }>;
    pathId: Attribute.Integer & Attribute.Required & Attribute.Unique;
    parent: Attribute.Relation<
      'plugin::upload.folder',
      'manyToOne',
      'plugin::upload.folder'
    >;
    children: Attribute.Relation<
      'plugin::upload.folder',
      'oneToMany',
      'plugin::upload.folder'
    >;
    files: Attribute.Relation<
      'plugin::upload.folder',
      'oneToMany',
      'plugin::upload.file'
    >;
    path: Attribute.String &
      Attribute.Required &
      Attribute.SetMinMax<{
        min: 1;
      }>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'plugin::upload.folder',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'plugin::upload.folder',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface PluginContentReleasesRelease extends Schema.CollectionType {
  collectionName: 'strapi_releases';
  info: {
    singularName: 'release';
    pluralName: 'releases';
    displayName: 'Release';
  };
  options: {
    draftAndPublish: false;
  };
  pluginOptions: {
    'content-manager': {
      visible: false;
    };
    'content-type-builder': {
      visible: false;
    };
  };
  attributes: {
    name: Attribute.String & Attribute.Required;
    releasedAt: Attribute.DateTime;
    actions: Attribute.Relation<
      'plugin::content-releases.release',
      'oneToMany',
      'plugin::content-releases.release-action'
    >;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'plugin::content-releases.release',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'plugin::content-releases.release',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface PluginContentReleasesReleaseAction
  extends Schema.CollectionType {
  collectionName: 'strapi_release_actions';
  info: {
    singularName: 'release-action';
    pluralName: 'release-actions';
    displayName: 'Release Action';
  };
  options: {
    draftAndPublish: false;
  };
  pluginOptions: {
    'content-manager': {
      visible: false;
    };
    'content-type-builder': {
      visible: false;
    };
  };
  attributes: {
    type: Attribute.Enumeration<['publish', 'unpublish']> & Attribute.Required;
    entry: Attribute.Relation<
      'plugin::content-releases.release-action',
      'morphToOne'
    >;
    contentType: Attribute.String & Attribute.Required;
    release: Attribute.Relation<
      'plugin::content-releases.release-action',
      'manyToOne',
      'plugin::content-releases.release'
    >;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'plugin::content-releases.release-action',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'plugin::content-releases.release-action',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface PluginNotificationNotification extends Schema.CollectionType {
  collectionName: 'notifications';
  info: {
    singularName: 'notification';
    pluralName: 'notifications';
    displayName: 'Notification';
    description: '';
  };
  options: {
    draftAndPublish: false;
  };
  attributes: {
    jobId: Attribute.String;
    type: Attribute.Enumeration<
      ['Push Notification', 'InApp Notification', 'SMS', 'Email']
    > &
      Attribute.Required;
    link: Attribute.String;
    icon: Attribute.String;
    to: Attribute.String & Attribute.Required;
    title: Attribute.String;
    message: Attribute.Text & Attribute.Required;
    start: Attribute.DateTime & Attribute.Required;
    end: Attribute.DateTime;
    repeat: Attribute.Enumeration<['None', 'Monthly', 'Weekly', 'Yearly']> &
      Attribute.Required;
    hasEnding: Attribute.Boolean & Attribute.DefaultTo<false>;
    retailerId: Attribute.String;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'plugin::notification.notification',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'plugin::notification.notification',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface PluginNotificationConfig extends Schema.CollectionType {
  collectionName: 'configs';
  info: {
    singularName: 'config';
    pluralName: 'configs';
    displayName: 'Config';
  };
  options: {
    draftAndPublish: false;
    comment: '';
  };
  attributes: {
    title: Attribute.String;
    value: Attribute.JSON;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'plugin::notification.config',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'plugin::notification.config',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface PluginI18NLocale extends Schema.CollectionType {
  collectionName: 'i18n_locale';
  info: {
    singularName: 'locale';
    pluralName: 'locales';
    collectionName: 'locales';
    displayName: 'Locale';
    description: '';
  };
  options: {
    draftAndPublish: false;
  };
  pluginOptions: {
    'content-manager': {
      visible: false;
    };
    'content-type-builder': {
      visible: false;
    };
  };
  attributes: {
    name: Attribute.String &
      Attribute.SetMinMax<{
        min: 1;
        max: 50;
      }>;
    code: Attribute.String & Attribute.Unique;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'plugin::i18n.locale',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'plugin::i18n.locale',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface PluginUsersPermissionsPermission
  extends Schema.CollectionType {
  collectionName: 'up_permissions';
  info: {
    name: 'permission';
    description: '';
    singularName: 'permission';
    pluralName: 'permissions';
    displayName: 'Permission';
  };
  pluginOptions: {
    'content-manager': {
      visible: false;
    };
    'content-type-builder': {
      visible: false;
    };
  };
  attributes: {
    action: Attribute.String & Attribute.Required;
    role: Attribute.Relation<
      'plugin::users-permissions.permission',
      'manyToOne',
      'plugin::users-permissions.role'
    >;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'plugin::users-permissions.permission',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'plugin::users-permissions.permission',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface PluginUsersPermissionsRole extends Schema.CollectionType {
  collectionName: 'up_roles';
  info: {
    name: 'role';
    description: '';
    singularName: 'role';
    pluralName: 'roles';
    displayName: 'Role';
  };
  pluginOptions: {
    'content-manager': {
      visible: false;
    };
    'content-type-builder': {
      visible: false;
    };
  };
  attributes: {
    name: Attribute.String &
      Attribute.Required &
      Attribute.SetMinMaxLength<{
        minLength: 3;
      }>;
    description: Attribute.String;
    type: Attribute.String & Attribute.Unique;
    permissions: Attribute.Relation<
      'plugin::users-permissions.role',
      'oneToMany',
      'plugin::users-permissions.permission'
    >;
    users: Attribute.Relation<
      'plugin::users-permissions.role',
      'oneToMany',
      'plugin::users-permissions.user'
    >;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'plugin::users-permissions.role',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'plugin::users-permissions.role',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface PluginUsersPermissionsUser extends Schema.CollectionType {
  collectionName: 'up_users';
  info: {
    name: 'user';
    description: '';
    singularName: 'user';
    pluralName: 'users';
    displayName: 'User';
  };
  options: {
    draftAndPublish: false;
  };
  attributes: {
    username: Attribute.String &
      Attribute.Required &
      Attribute.Unique &
      Attribute.SetMinMaxLength<{
        minLength: 3;
      }>;
    provider: Attribute.String;
    resetPasswordToken: Attribute.String & Attribute.Private;
    confirmationToken: Attribute.String & Attribute.Private;
    confirmed: Attribute.Boolean & Attribute.DefaultTo<false>;
    blocked: Attribute.Boolean & Attribute.DefaultTo<false>;
    role: Attribute.Relation<
      'plugin::users-permissions.user',
      'manyToOne',
      'plugin::users-permissions.role'
    >;
    email: Attribute.Email &
      Attribute.Required &
      Attribute.SetMinMaxLength<{
        minLength: 6;
      }>;
    password: Attribute.Password &
      Attribute.Private &
      Attribute.SetMinMaxLength<{
        minLength: 6;
      }>;
    tokenVersion: Attribute.Integer &
      Attribute.Private &
      Attribute.DefaultTo<1>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'plugin::users-permissions.user',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'plugin::users-permissions.user',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiAppLabelAppLabel extends Schema.CollectionType {
  collectionName: 'app_labels';
  info: {
    singularName: 'app-label';
    pluralName: 'app-labels';
    displayName: 'App Label';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  pluginOptions: {
    i18n: {
      localized: true;
    };
  };
  attributes: {
    key: Attribute.String &
      Attribute.Required &
      Attribute.SetPluginOptions<{
        i18n: {
          localized: false;
        };
      }>;
    label: Attribute.String &
      Attribute.Required &
      Attribute.SetPluginOptions<{
        i18n: {
          localized: true;
        };
      }>;
    dynamicText: Attribute.String &
      Attribute.SetPluginOptions<{
        i18n: {
          localized: true;
        };
      }>;
    appLabelCode: Attribute.UID &
      Attribute.CustomField<'plugin::strapi-advanced-uuid.uuid'>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::app-label.app-label',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::app-label.app-label',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    localizations: Attribute.Relation<
      'api::app-label.app-label',
      'oneToMany',
      'api::app-label.app-label'
    >;
    locale: Attribute.String;
  };
}

export interface ApiAppNotificationAppNotification
  extends Schema.CollectionType {
  collectionName: 'app_notifications';
  info: {
    singularName: 'app-notification';
    pluralName: 'app-notifications';
    displayName: 'App Notification';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    title: Attribute.String;
    description: Attribute.Text;
    isOpened: Attribute.Boolean;
    retailerId: Attribute.String;
    date: Attribute.DateTime;
    notificationType: Attribute.Relation<
      'api::app-notification.app-notification',
      'manyToOne',
      'api::notification-type.notification-type'
    >;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::app-notification.app-notification',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::app-notification.app-notification',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiAreaMasterAreaMaster extends Schema.CollectionType {
  collectionName: 'area_masters';
  info: {
    singularName: 'area-master';
    pluralName: 'area-masters';
    displayName: 'Area Master';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    pincode: Attribute.String & Attribute.Required;
    district: Attribute.String & Attribute.Required;
    state: Attribute.String & Attribute.Required;
    area: Attribute.String & Attribute.Required;
    country: Attribute.String & Attribute.Required;
    displayName: Attribute.String;
    externalId: Attribute.String;
    name: Attribute.String;
    salesOffice: Attribute.String;
    zone: Attribute.String & Attribute.Required;
    areaMasterId: Attribute.String;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::area-master.area-master',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::area-master.area-master',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiCategoryCategory extends Schema.CollectionType {
  collectionName: 'categories';
  info: {
    singularName: 'category';
    pluralName: 'categories';
    displayName: 'Categories';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    categoryCode: Attribute.UID &
      Attribute.CustomField<'plugin::strapi-advanced-uuid.uuid'>;
    categoryId: Attribute.String & Attribute.Required;
    categoryName: Attribute.String & Attribute.Required;
    sapDivisionCode: Attribute.String;
    subCategories: Attribute.Relation<
      'api::category.category',
      'oneToMany',
      'api::sub-category.sub-category'
    >;
    logo: Attribute.Text;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::category.category',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::category.category',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiContentDocumentContentDocument
  extends Schema.CollectionType {
  collectionName: 'content_documents';
  info: {
    singularName: 'content-document';
    pluralName: 'content-documents';
    displayName: 'Content Document';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    contentDocumentId: Attribute.String;
    title: Attribute.String;
    uploadedAt: Attribute.Date;
    contentDocumentCode: Attribute.UID &
      Attribute.CustomField<'plugin::strapi-advanced-uuid.uuid'>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::content-document.content-document',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::content-document.content-document',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiContentDocumentLinkContentDocumentLink
  extends Schema.CollectionType {
  collectionName: 'content_document_links';
  info: {
    singularName: 'content-document-link';
    pluralName: 'content-document-links';
    displayName: 'Content Document Link';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    contentDocumentId: Attribute.String & Attribute.Required;
    linkedEntityId: Attribute.String & Attribute.Required;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::content-document-link.content-document-link',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::content-document-link.content-document-link',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiContentVersionContentVersion extends Schema.CollectionType {
  collectionName: 'content_versions';
  info: {
    singularName: 'content-version';
    pluralName: 'content-versions';
    displayName: 'Content Version';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    contentVersionCode: Attribute.UID &
      Attribute.CustomField<'plugin::strapi-advanced-uuid.uuid'>;
    contentDocumentId: Attribute.String;
    contentUrl: Attribute.String;
    versionData: Attribute.Text;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::content-version.content-version',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::content-version.content-version',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiFeatureFeature extends Schema.CollectionType {
  collectionName: 'features';
  info: {
    singularName: 'feature';
    pluralName: 'features';
    displayName: 'Feature';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  pluginOptions: {
    i18n: {
      localized: true;
    };
  };
  attributes: {
    name: Attribute.String &
      Attribute.Required &
      Attribute.SetPluginOptions<{
        i18n: {
          localized: true;
        };
      }>;
    visibleForSecondaryUser: Attribute.Boolean &
      Attribute.Required &
      Attribute.SetPluginOptions<{
        i18n: {
          localized: true;
        };
      }> &
      Attribute.DefaultTo<true>;
    logo: Attribute.Text &
      Attribute.SetPluginOptions<{
        i18n: {
          localized: true;
        };
      }>;
    path: Attribute.String &
      Attribute.SetPluginOptions<{
        i18n: {
          localized: true;
        };
      }>;
    order: Attribute.Integer;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::feature.feature',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::feature.feature',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    localizations: Attribute.Relation<
      'api::feature.feature',
      'oneToMany',
      'api::feature.feature'
    >;
    locale: Attribute.String;
  };
}

export interface ApiLeadLead extends Schema.CollectionType {
  collectionName: 'leads';
  info: {
    singularName: 'lead';
    pluralName: 'leads';
    displayName: 'Leads';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    leadCode: Attribute.UID &
      Attribute.CustomField<'plugin::strapi-advanced-uuid.uuid'>;
    leadId: Attribute.String & Attribute.Unique;
    name: Attribute.String & Attribute.Required;
    email: Attribute.Email & Attribute.Required;
    mobileNumber: Attribute.String & Attribute.Required;
    leadType: Attribute.Enumeration<['Channel', 'Institutional', 'B2C']> &
      Attribute.Required;
    leadTypeId: Attribute.String;
    pincode: Attribute.String & Attribute.Required;
    district: Attribute.String;
    salesOffice: Attribute.String;
    state: Attribute.String;
    zone: Attribute.String;
    country: Attribute.String;
    leadSource: Attribute.Enumeration<
      [
        'Call Center',
        'Dealer',
        'Digital Aggregator',
        'Employee',
        'E-Tender',
        'Exhibition',
        'Influencer',
        'Marketing Activity',
        'News Paper Ad',
        'Other',
        'Social Media',
        'Website',
        'RUM',
        'Microsite',
        'Microsites',
        'Lead-Microsite',
        'Customer Portal',
        'LAS',
        'Retailer'
      ]
    >;
    referredBy: Attribute.String;
    installationDate: Attribute.Date;
    followUpDate: Attribute.Date;
    roofType: Attribute.String;
    shadeFreeRoofArea: Attribute.String;
    avgMonthlyElectricityBill: Attribute.Decimal;
    enquiryOver10kw: Attribute.Enumeration<['Yes', 'No']>;
    total: Attribute.Decimal;
    creatorId: Attribute.String;
    associatedId: Attribute.String;
    status: Attribute.Enumeration<
      [
        'New',
        'Assigned to call center',
        'Closed',
        'Qualified',
        'Partner assigned',
        'Assigned back to call center'
      ]
    >;
    subStatus: Attribute.Enumeration<
      [
        'Unreachable',
        'New lead',
        'No answer',
        'Switched off',
        'Purchase later',
        'Enquiry/Other category',
        'Junk',
        'Duplicate',
        'Awaiting partner assignment',
        'New lead assigned',
        'Lead accepted',
        'Catalogue shared',
        'Not convertible',
        'Customer feedback',
        'Partner feedback valid',
        'Partner feedback invalid',
        'Site survey',
        'Site not ready (construction)',
        'Site ready',
        'Water testing (SWH)',
        'Quotation',
        'Distribution co approval SPS',
        'Product installed',
        'Distribution co inspection SPS',
        'Commissioning (SPS and SWH)',
        'Converted',
        'Invalid sale',
        'Invalid sale confirmed',
        'Converted and verified',
        'Junk / Not relevant',
        'Await partner reassignment',
        'Lead not accepted',
        'Lead rejected',
        'Awaiting assignment by PIC'
      ]
    >;
    subStatusId: Attribute.Integer;
    subStatus2: Attribute.Enumeration<
      [
        'Need to reassign lead',
        'Product gap',
        'Price',
        'No requirement',
        'Installation challenges',
        'Purchased competitor brand',
        'Purchase other VG brand',
        'Others',
        'No purchase',
        'Feedback pending',
        'Feedback pending and closed',
        'Feedback collected and closed',
        'Feedback awaiting due date',
        'Water testing failed',
        'Non-availabilty',
        'Rejected by Distribution co.',
        'Other (with a comment box)'
      ]
    >;
    comment: Attribute.Text;
    receivedOn: Attribute.Date;
    areaMasterId: Attribute.String;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<'api::lead.lead', 'oneToOne', 'admin::user'> &
      Attribute.Private;
    updatedBy: Attribute.Relation<'api::lead.lead', 'oneToOne', 'admin::user'> &
      Attribute.Private;
  };
}

export interface ApiLeadProductLeadProduct extends Schema.CollectionType {
  collectionName: 'lead_products';
  info: {
    singularName: 'lead-product';
    pluralName: 'lead-products';
    displayName: 'Lead Products';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    leadProductCode: Attribute.UID &
      Attribute.CustomField<'plugin::strapi-advanced-uuid.uuid'>;
    leadCode: Attribute.String & Attribute.Required;
    leadId: Attribute.String;
    productSKU: Attribute.String;
    categoryId: Attribute.String;
    subCategoryId: Attribute.String;
    pricePerSKU: Attribute.Integer;
    quantity: Attribute.Integer;
    soldProduct: Attribute.Boolean & Attribute.DefaultTo<false>;
    totalPricePerSKU: Attribute.Decimal;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::lead-product.lead-product',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::lead-product.lead-product',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiLeadStatusHierarchyLeadStatusHierarchy
  extends Schema.CollectionType {
  collectionName: 'lead_status_hierarchies';
  info: {
    singularName: 'lead-status-hierarchy';
    pluralName: 'lead-status-hierarchies';
    displayName: 'Lead Status Hierarchy';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    parentId: Attribute.Integer & Attribute.Required;
    parentStatus: Attribute.Enumeration<
      [
        'Unreachable',
        'New lead',
        'No answer',
        'Switched off',
        'Purchase later',
        'Enquiry/Other category',
        'Junk',
        'Duplicate',
        'Awaiting partner assignment',
        'New lead assigned',
        'Lead accepted',
        'Catalogue shared',
        'Not convertible',
        'Customer feedback',
        'Partner feedback valid',
        'Partner feedback invalid',
        'Site survey',
        'Site not ready (construction)',
        'Site ready',
        'Water testing (SWH)',
        'Quotation',
        'Distribution co approval SPS',
        'Product installed',
        'Distribution co inspection SPS',
        'Commissioning (SPS and SWH)',
        'Converted',
        'Invalid sale',
        'Invalid sale confirmed',
        'Converted and verified',
        'Junk / Not relevant',
        'Await partner reassignment',
        'Lead not accepted',
        'Lead rejected',
        'Awaiting assignment by PIC'
      ]
    > &
      Attribute.Required;
    childId: Attribute.Integer;
    childStatus: Attribute.Enumeration<
      [
        'Unreachable',
        'New lead',
        'No answer',
        'Switched off',
        'Purchase later',
        'Enquiry/Other category',
        'Junk',
        'Duplicate',
        'Awaiting partner assignment',
        'New lead assigned',
        'Lead accepted',
        'Catalogue shared',
        'Not convertible',
        'Customer feedback',
        'Partner feedback valid',
        'Partner feedback invalid',
        'Site survey',
        'Site not ready (construction)',
        'Site ready',
        'Water testing (SWH)',
        'Quotation',
        'Distribution co approval SPS',
        'Product installed',
        'Distribution co inspection SPS',
        'Commissioning (SPS and SWH)',
        'Converted',
        'Invalid sale',
        'Invalid sale confirmed',
        'Converted and verified',
        'Junk / Not relevant',
        'Await partner reassignment',
        'Lead not accepted',
        'Lead rejected',
        'Awaiting assignment by PIC',
        'Need to reassign lead',
        'Product gap',
        'Price',
        'No requirement',
        'Installation challenges',
        'Purchased competitor brand',
        'Purchase other VG brand',
        'Others',
        'No purchase',
        'Feedback pending',
        'Feedback pending and closed',
        'Feedback collected and closed',
        'Feedback awaiting due date',
        'Water testing failed',
        'Non-availabilty',
        'Rejected by Distribution co.',
        'Other (with a comment box)'
      ]
    >;
    hasSubStatus2: Attribute.Boolean & Attribute.DefaultTo<false>;
    isPositive: Attribute.Boolean & Attribute.DefaultTo<false>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::lead-status-hierarchy.lead-status-hierarchy',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::lead-status-hierarchy.lead-status-hierarchy',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiLeadStatusHistoryLeadStatusHistory
  extends Schema.CollectionType {
  collectionName: 'lead_status_histories';
  info: {
    singularName: 'lead-status-history';
    pluralName: 'lead-status-histories';
    displayName: 'Lead Status History';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    leadStatusHistoryCode: Attribute.UID &
      Attribute.CustomField<'plugin::strapi-advanced-uuid.uuid'>;
    status: Attribute.Enumeration<
      [
        'New',
        'Assigned to call center',
        'Closed',
        'Qualified',
        'Partner assigned',
        'Assigned back to call center'
      ]
    > &
      Attribute.Required;
    subStatus: Attribute.Enumeration<
      [
        'Unreachable',
        'New lead',
        'No answer',
        'Switched off',
        'Purchase later',
        'Enquiry/Other category',
        'Junk',
        'Duplicate',
        'Awaiting partner assignment',
        'New lead assigned',
        'Lead accepted',
        'Catalogue shared',
        'Not convertible',
        'Customer feedback',
        'Partner feedback valid',
        'Partner feedback invalid',
        'Site survey',
        'Site not ready (construction)',
        'Site ready',
        'Water testing (SWH)',
        'Quotation',
        'Distribution co approval SPS',
        'Product installed',
        'Distribution co inspection SPS',
        'Commissioning (SPS and SWH)',
        'Converted',
        'Invalid sale',
        'Invalid sale confirmed',
        'Converted and verified',
        'Junk / Not relevant',
        'Await partner reassignment',
        'Lead not accepted',
        'Lead rejected',
        'Awaiting assignment by PIC'
      ]
    > &
      Attribute.Required;
    subStatus2: Attribute.Enumeration<
      [
        'Need to reassign lead',
        'Product gap',
        'Price',
        'No requirement',
        'Installation challenges',
        'Purchased competitor brand',
        'Purchase other VG brand',
        'Others',
        'No purchase',
        'Feedback pending',
        'Feedback pending and closed',
        'Feedback collected and closed',
        'Feedback awaiting due date',
        'Water testing failed',
        'Non-availabilty',
        'Rejected by Distribution co.',
        'Other (with a comment box)'
      ]
    >;
    comment: Attribute.Text;
    leadCode: Attribute.String & Attribute.Required;
    createdDate: Attribute.Date;
    leadId: Attribute.String;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::lead-status-history.lead-status-history',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::lead-status-history.lead-status-history',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiLeadTypeLeadType extends Schema.CollectionType {
  collectionName: 'lead_types';
  info: {
    singularName: 'lead-type';
    pluralName: 'lead-types';
    displayName: 'Lead Types';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    leadTypeId: Attribute.String;
    leadType: Attribute.String;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::lead-type.lead-type',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::lead-type.lead-type',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiLocalizationLocalization extends Schema.CollectionType {
  collectionName: 'localizations';
  info: {
    singularName: 'localization';
    pluralName: 'localizations';
    displayName: 'Localization';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  pluginOptions: {
    i18n: {
      localized: true;
    };
  };
  attributes: {
    label: Attribute.String &
      Attribute.Required &
      Attribute.SetPluginOptions<{
        i18n: {
          localized: true;
        };
      }>;
    key: Attribute.String &
      Attribute.Required &
      Attribute.SetPluginOptions<{
        i18n: {
          localized: true;
        };
      }>;
    dynamicText: Attribute.String &
      Attribute.SetPluginOptions<{
        i18n: {
          localized: true;
        };
      }>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::localization.localization',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::localization.localization',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    localizations: Attribute.Relation<
      'api::localization.localization',
      'oneToMany',
      'api::localization.localization'
    >;
    locale: Attribute.String;
  };
}

export interface ApiMarketingMarketing extends Schema.CollectionType {
  collectionName: 'marketings';
  info: {
    singularName: 'marketing';
    pluralName: 'marketings';
    displayName: 'Marketing';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    media: Attribute.Text & Attribute.Required;
    description: Attribute.Text & Attribute.Required;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::marketing.marketing',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::marketing.marketing',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiNotificationTypeNotificationType
  extends Schema.CollectionType {
  collectionName: 'notification_types';
  info: {
    singularName: 'notification-type';
    pluralName: 'notification-types';
    displayName: 'Notification Type';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    name: Attribute.String;
    icon: Attribute.Text;
    appNotifications: Attribute.Relation<
      'api::notification-type.notification-type',
      'oneToMany',
      'api::app-notification.app-notification'
    >;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::notification-type.notification-type',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::notification-type.notification-type',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiOtpOtp extends Schema.CollectionType {
  collectionName: 'otps';
  info: {
    singularName: 'otp';
    pluralName: 'otps';
    displayName: 'Otp';
    description: '';
  };
  options: {
    draftAndPublish: false;
  };
  attributes: {
    userId: Attribute.Relation<
      'api::otp.otp',
      'oneToOne',
      'plugin::users-permissions.user'
    >;
    otpCode: Attribute.Text & Attribute.Required;
    verifyOtpFailureCount: Attribute.Integer & Attribute.DefaultTo<0>;
    otpExpiryTime: Attribute.DateTime;
    verifyFailedAt: Attribute.DateTime;
    resendOtpCount: Attribute.Integer & Attribute.DefaultTo<0>;
    resendOtpFailedAt: Attribute.DateTime;
    otpPurpose: Attribute.Enumeration<['LOGIN']>;
    keyEncryption: Attribute.Text & Attribute.Required;
    deviceId: Attribute.String;
    ivString: Attribute.Text;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<'api::otp.otp', 'oneToOne', 'admin::user'> &
      Attribute.Private;
    updatedBy: Attribute.Relation<'api::otp.otp', 'oneToOne', 'admin::user'> &
      Attribute.Private;
  };
}

export interface ApiPrimaryuserPrimaryuser extends Schema.CollectionType {
  collectionName: 'primaryusers';
  info: {
    singularName: 'primaryuser';
    pluralName: 'primaryusers';
    displayName: 'Primaryuser';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    retailerName: Attribute.String &
      Attribute.SetMinMaxLength<{
        maxLength: 40;
      }>;
    retailerId: Attribute.String & Attribute.Required;
    mobileNumber: Attribute.String & Attribute.Required;
    email: Attribute.Email &
      Attribute.Required &
      Attribute.SetMinMaxLength<{
        minLength: 6;
      }>;
    alternateMobileNo: Attribute.String;
    loggedInDate: Attribute.String;
    invitationDate: Attribute.String;
    activationStatus: Attribute.Enumeration<
      [
        'Not yet invited',
        'Invitation triggered',
        'Invitation sent',
        'Logged in',
        'First scan completed'
      ]
    > &
      Attribute.DefaultTo<'Not yet invited'>;
    blockStatus: Attribute.Enumeration<
      ['Active', 'Scan block', 'Redemption block ', 'Profile block']
    > &
      Attribute.DefaultTo<'Active'>;
    dateOfBirth: Attribute.String;
    gender: Attribute.String;
    maritalStatus: Attribute.String;
    marriageAnniversary: Attribute.String;
    profilePhoto: Attribute.Text;
    salespersonName: Attribute.String;
    salespersonPhoneNumber: Attribute.String;
    storeName: Attribute.String;
    storeAddressLine1: Attribute.Text;
    storeAddressLine2: Attribute.Text;
    landmark: Attribute.String;
    pincode: Attribute.String;
    city: Attribute.String;
    district: Attribute.String;
    state: Attribute.String;
    gstIn: Attribute.Enumeration<['Yes', 'No']> & Attribute.DefaultTo<'Yes'>;
    gstStatus: Attribute.String;
    bussinessPanCardNo: Attribute.String;
    aadharNumber: Attribute.String &
      Attribute.SetMinMaxLength<{
        maxLength: 16;
      }>;
    accountNumber: Attribute.String &
      Attribute.SetMinMaxLength<{
        maxLength: 40;
      }>;
    accountHolderName: Attribute.String &
      Attribute.SetMinMaxLength<{
        maxLength: 255;
      }>;
    bankName: Attribute.String;
    ifscCode: Attribute.String;
    partnerName: Attribute.String;
    userId: Attribute.Relation<
      'api::primaryuser.primaryuser',
      'oneToOne',
      'plugin::users-permissions.user'
    >;
    secondarySchemeMemberships: Attribute.Relation<
      'api::primaryuser.primaryuser',
      'oneToMany',
      'api::secondary-scheme-membership.secondary-scheme-membership'
    >;
    areaMasterId: Attribute.String;
    storeAnniversary: Attribute.String;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::primaryuser.primaryuser',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::primaryuser.primaryuser',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiProductDisplayPriceListProductDisplayPriceList
  extends Schema.CollectionType {
  collectionName: 'product_display_price_lists';
  info: {
    singularName: 'product-display-price-list';
    pluralName: 'product-display-price-lists';
    displayName: 'Product Display Price List';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    productDisplayPriceListCode: Attribute.UID &
      Attribute.CustomField<'plugin::strapi-advanced-uuid.uuid'>;
    productDisplayPriceListId: Attribute.String;
    documentType: Attribute.Enumeration<
      [
        'Product training',
        'Product flyer',
        'Product scheme',
        'Product brochure',
        'Product demo',
        'Product Ad',
        'Product price list book'
      ]
    >;
    communicationStartDate: Attribute.Date;
    communicationEndDate: Attribute.Date;
    description: Attribute.String;
    uploadDocumentLink: Attribute.String;
    youtubeTitle: Attribute.String;
    youtubeLink: Attribute.String;
    youtubeCreatedAt: Attribute.Date;
    categoryId: Attribute.String;
    subCategoryId: Attribute.String;
    skuProduct: Attribute.String;
    zone: Attribute.String;
    district: Attribute.String;
    salesOffice: Attribute.String;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::product-display-price-list.product-display-price-list',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::product-display-price-list.product-display-price-list',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiRetailerCategoryRetailerCategory
  extends Schema.CollectionType {
  collectionName: 'retailer_categories';
  info: {
    singularName: 'retailer-category';
    pluralName: 'retailer-categories';
    displayName: 'Retailer Category';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    categoryId: Attribute.String;
    dmsType: Attribute.Enumeration<['DMS', 'Non-DMS']>;
    dmsVerified: Attribute.String;
    salesVerified: Attribute.String;
    relation: Attribute.Enumeration<
      [
        'B2C',
        'Canteen - CPC',
        'Canteen - CSD',
        'Canteen - INCS',
        'Canteen - TNPC',
        'Canteen - Other',
        'Consignment Agent',
        'Institution',
        'Modern Retail',
        'Sub Dealer',
        'DMA',
        'Target Customer',
        'Retail Dealer',
        'Direct Consumer',
        'Direct Dealer',
        'Distributor',
        'Employee',
        'Export Customer',
        'Plant Customer',
        'State Police',
        'Service Franchise',
        'e-Brand Store',
        'NCC Group Canteens',
        'Non CPC',
        'Non CSD',
        'System Integrators',
        'EPC developers',
        'Direct Dealers',
        'UBS Customer',
        'GeM Customer',
        'Retailer'
      ]
    >;
    retailerId: Attribute.Relation<
      'api::retailer-category.retailer-category',
      'oneToOne',
      'api::primaryuser.primaryuser'
    >;
    retailerPartnerId: Attribute.String;
    invoiceDate: Attribute.Date;
    sapActive: Attribute.Boolean & Attribute.DefaultTo<false>;
    categoryRetailerId: Attribute.String;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::retailer-category.retailer-category',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::retailer-category.retailer-category',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiSalesUserSalesUser extends Schema.CollectionType {
  collectionName: 'sales_users';
  info: {
    singularName: 'sales-user';
    pluralName: 'sales-users';
    displayName: 'Sales User';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    salesUserCode: Attribute.UID &
      Attribute.CustomField<'plugin::strapi-advanced-uuid.uuid'>;
    name: Attribute.String;
    mobileNumber: Attribute.String;
    salesUserId: Attribute.String;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::sales-user.sales-user',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::sales-user.sales-user',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiSalesUserCategorySalesUserCategory
  extends Schema.CollectionType {
  collectionName: 'sales_user_categories';
  info: {
    singularName: 'sales-user-category';
    pluralName: 'sales-user-categories';
    displayName: 'Sales User Category';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    salesUserCategoryCode: Attribute.UID &
      Attribute.CustomField<'plugin::strapi-advanced-uuid.uuid'>;
    categoryId: Attribute.String;
    salesUserId: Attribute.String;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::sales-user-category.sales-user-category',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::sales-user-category.sales-user-category',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiSecondarySchemeSecondaryScheme
  extends Schema.CollectionType {
  collectionName: 'secondary_schemes';
  info: {
    singularName: 'secondary-scheme';
    pluralName: 'secondary-schemes';
    displayName: 'Secondary Schemes';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    secondarySchemeId: Attribute.String;
    name: Attribute.String;
    targetActivationDate: Attribute.Date;
    endDate: Attribute.Date;
    status: Attribute.String;
    schemeType: Attribute.String;
    secondarySchemeCode: Attribute.UID &
      Attribute.CustomField<'plugin::strapi-advanced-uuid.uuid'>;
    secondarySchemeSlabs: Attribute.Relation<
      'api::secondary-scheme.secondary-scheme',
      'oneToMany',
      'api::secondary-scheme-slab.secondary-scheme-slab'
    >;
    secondarySchemeProducts: Attribute.Relation<
      'api::secondary-scheme.secondary-scheme',
      'oneToMany',
      'api::secondary-scheme-product.secondary-scheme-product'
    >;
    secondarySchemeMemberships: Attribute.Relation<
      'api::secondary-scheme.secondary-scheme',
      'oneToMany',
      'api::secondary-scheme-membership.secondary-scheme-membership'
    >;
    termsAndConditions: Attribute.Blocks;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::secondary-scheme.secondary-scheme',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::secondary-scheme.secondary-scheme',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiSecondarySchemeMembershipSecondarySchemeMembership
  extends Schema.CollectionType {
  collectionName: 'secondary_scheme_memberships';
  info: {
    singularName: 'secondary-scheme-membership';
    pluralName: 'secondary-scheme-memberships';
    displayName: 'Secondary Scheme Membership';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    retailerId: Attribute.String;
    secondarySchemeMembershipCode: Attribute.UID &
      Attribute.CustomField<'plugin::strapi-advanced-uuid.uuid'>;
    schemeMember: Attribute.Relation<
      'api::secondary-scheme-membership.secondary-scheme-membership',
      'manyToOne',
      'api::primaryuser.primaryuser'
    >;
    schemeId: Attribute.Relation<
      'api::secondary-scheme-membership.secondary-scheme-membership',
      'manyToOne',
      'api::secondary-scheme.secondary-scheme'
    >;
    secondarySchemeId: Attribute.String;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::secondary-scheme-membership.secondary-scheme-membership',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::secondary-scheme-membership.secondary-scheme-membership',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiSecondarySchemeProductSecondarySchemeProduct
  extends Schema.CollectionType {
  collectionName: 'secondary_scheme_products';
  info: {
    singularName: 'secondary-scheme-product';
    pluralName: 'secondary-scheme-products';
    displayName: 'Secondary Scheme Products';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    secondarySchemeProductsId: Attribute.String;
    secondarySchemeProductsCode: Attribute.UID &
      Attribute.CustomField<'plugin::strapi-advanced-uuid.uuid'>;
    skuproduct: Attribute.Relation<
      'api::secondary-scheme-product.secondary-scheme-product',
      'manyToOne',
      'api::skuproduct.skuproduct'
    >;
    secondaryScheme: Attribute.Relation<
      'api::secondary-scheme-product.secondary-scheme-product',
      'manyToOne',
      'api::secondary-scheme.secondary-scheme'
    >;
    skuProduct: Attribute.String;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::secondary-scheme-product.secondary-scheme-product',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::secondary-scheme-product.secondary-scheme-product',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiSecondarySchemeSlabSecondarySchemeSlab
  extends Schema.CollectionType {
  collectionName: 'secondary_scheme_slabs';
  info: {
    singularName: 'secondary-scheme-slab';
    pluralName: 'secondary-scheme-slabs';
    displayName: 'Secondary Scheme Slab';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    secondarySchemeSlabId: Attribute.String;
    scheme: Attribute.String;
    secondarySchemeSlabCode: Attribute.UID &
      Attribute.CustomField<'plugin::strapi-advanced-uuid.uuid'>;
    slabNumber: Attribute.String;
    slabThresholdFrom: Attribute.Integer;
    slabThresholdTo: Attribute.Integer;
    schemeReward: Attribute.String;
    description: Attribute.String;
    discount: Attribute.String;
    focName: Attribute.String;
    rewardType: Attribute.String;
    secondaryScheme: Attribute.Relation<
      'api::secondary-scheme-slab.secondary-scheme-slab',
      'manyToOne',
      'api::secondary-scheme.secondary-scheme'
    >;
    slabCriteriaUOM: Attribute.String;
    rewardUnit: Attribute.Integer;
    rewardToBeEarned: Attribute.String;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::secondary-scheme-slab.secondary-scheme-slab',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::secondary-scheme-slab.secondary-scheme-slab',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiSecondaryuserSecondaryuser extends Schema.CollectionType {
  collectionName: 'secondaryusers';
  info: {
    singularName: 'secondaryuser';
    pluralName: 'secondaryusers';
    displayName: 'Secondaryuser';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    name: Attribute.String & Attribute.Required;
    mobileNumber: Attribute.String & Attribute.Required & Attribute.Unique;
    profilePhoto: Attribute.Text;
    invitationDate: Attribute.String;
    activationStatus: Attribute.Enumeration<
      [
        'Not yet invited',
        'Invitation triggered',
        'Invitation sent',
        'Logged in',
        'First scan completed'
      ]
    > &
      Attribute.DefaultTo<'Not yet invited'>;
    userId: Attribute.Relation<
      'api::secondaryuser.secondaryuser',
      'oneToOne',
      'plugin::users-permissions.user'
    >;
    parentId: Attribute.Relation<
      'api::secondaryuser.secondaryuser',
      'oneToOne',
      'api::primaryuser.primaryuser'
    >;
    isDeleted: Attribute.Boolean & Attribute.DefaultTo<false>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::secondaryuser.secondaryuser',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::secondaryuser.secondaryuser',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiSkuproductSkuproduct extends Schema.CollectionType {
  collectionName: 'skuproducts';
  info: {
    singularName: 'skuproduct';
    pluralName: 'skuproducts';
    displayName: 'Sku Product';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    seriesDescription: Attribute.String;
    categoryName: Attribute.String;
    skuProductCode: Attribute.UID &
      Attribute.CustomField<'plugin::strapi-advanced-uuid.uuid'>;
    seriesCode: Attribute.Integer;
    categoryId: Attribute.String;
    subCategoryId: Attribute.String;
    skuProductId: Attribute.Relation<
      'api::skuproduct.skuproduct',
      'oneToMany',
      'api::secondary-scheme-product.secondary-scheme-product'
    >;
    skuProduct: Attribute.String;
    skuProductName: Attribute.String;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::skuproduct.skuproduct',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::skuproduct.skuproduct',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiSmsSms extends Schema.CollectionType {
  collectionName: 'smses';
  info: {
    singularName: 'sms';
    pluralName: 'smses';
    displayName: 'Sms';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    mobileNumber: Attribute.BigInteger;
    smsStatus: Attribute.String;
    errorCode: Attribute.Integer;
    errorMessage: Attribute.String;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<'api::sms.sms', 'oneToOne', 'admin::user'> &
      Attribute.Private;
    updatedBy: Attribute.Relation<'api::sms.sms', 'oneToOne', 'admin::user'> &
      Attribute.Private;
  };
}

export interface ApiSubCategorySubCategory extends Schema.CollectionType {
  collectionName: 'sub_categories';
  info: {
    singularName: 'sub-category';
    pluralName: 'sub-categories';
    displayName: 'Sub Categories';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    subCategoryCode: Attribute.UID &
      Attribute.CustomField<'plugin::strapi-advanced-uuid.uuid'>;
    subCategoryId: Attribute.String & Attribute.Required;
    subCategoryName: Attribute.String & Attribute.Required;
    categoryId: Attribute.String & Attribute.Required;
    category: Attribute.Relation<
      'api::sub-category.sub-category',
      'manyToOne',
      'api::category.category'
    >;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::sub-category.sub-category',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::sub-category.sub-category',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiSupportSupport extends Schema.CollectionType {
  collectionName: 'supports';
  info: {
    singularName: 'support';
    pluralName: 'supports';
    displayName: 'Support';
    description: '';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    retailerId: Attribute.String;
    supportType: Attribute.Enumeration<
      ['Product related', 'Channel related', 'Complaint', 'Others']
    > &
      Attribute.Required;
    subType: Attribute.Enumeration<
      [
        'Add product category',
        'Product Feedback',
        'Marketing/BTL',
        'Product complaint',
        'General complaint',
        'Distributor complaint',
        'Sales person complaint',
        'NA'
      ]
    >;
    origin: Attribute.Enumeration<['Retailer App', 'LAS App']>;
    productCategory: Attribute.String;
    comments: Attribute.String;
    marketMaterialType: Attribute.Enumeration<
      [
        'Dealer boards',
        'In shop boards',
        'Product display',
        'Dummy display',
        'Poster',
        'Banner',
        'Dangler',
        'Leaflets',
        'Brochure',
        'Nukkad meets'
      ]
    > &
      Attribute.Required;
    ticketStatus: Attribute.Enumeration<
      [
        'New',
        'Working',
        'Merged',
        'Pending',
        'Resolved',
        'Success',
        'Failed',
        'null'
      ]
    >;
    ticketId: Attribute.String;
    remarks: Attribute.String;
    ticketCreatedDate: Attribute.Date;
    supportCode: Attribute.UID &
      Attribute.CustomField<'plugin::strapi-advanced-uuid.uuid'>;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::support.support',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::support.support',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiSupportTypeSubtypeMappingSupportTypeSubtypeMapping
  extends Schema.CollectionType {
  collectionName: 'support_type_subtype_mappings';
  info: {
    singularName: 'support-type-subtype-mapping';
    pluralName: 'support-type-subtype-mappings';
    displayName: 'Support Type Subtype Mapping';
  };
  options: {
    draftAndPublish: true;
  };
  attributes: {
    supportTypeId: Attribute.Integer;
    supportType: Attribute.String;
    subType: Attribute.String;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    publishedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::support-type-subtype-mapping.support-type-subtype-mapping',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::support-type-subtype-mapping.support-type-subtype-mapping',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

export interface ApiUserDeviceUserDevice extends Schema.CollectionType {
  collectionName: 'user_devices';
  info: {
    singularName: 'user-device';
    pluralName: 'user-devices';
    displayName: 'User Devices';
    description: '';
  };
  options: {
    draftAndPublish: false;
  };
  attributes: {
    deviceId: Attribute.String & Attribute.Required & Attribute.Unique;
    fcmToken: Attribute.String;
    platform: Attribute.Enumeration<['android', 'ios']>;
    currentVersion: Attribute.String;
    latestVersion: Attribute.String;
    retailerId: Attribute.String;
    createdAt: Attribute.DateTime;
    updatedAt: Attribute.DateTime;
    createdBy: Attribute.Relation<
      'api::user-device.user-device',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
    updatedBy: Attribute.Relation<
      'api::user-device.user-device',
      'oneToOne',
      'admin::user'
    > &
      Attribute.Private;
  };
}

declare module '@strapi/types' {
  export module Shared {
    export interface ContentTypes {
      'admin::permission': AdminPermission;
      'admin::user': AdminUser;
      'admin::role': AdminRole;
      'admin::api-token': AdminApiToken;
      'admin::api-token-permission': AdminApiTokenPermission;
      'admin::transfer-token': AdminTransferToken;
      'admin::transfer-token-permission': AdminTransferTokenPermission;
      'plugin::upload.file': PluginUploadFile;
      'plugin::upload.folder': PluginUploadFolder;
      'plugin::content-releases.release': PluginContentReleasesRelease;
      'plugin::content-releases.release-action': PluginContentReleasesReleaseAction;
      'plugin::notification.notification': PluginNotificationNotification;
      'plugin::notification.config': PluginNotificationConfig;
      'plugin::i18n.locale': PluginI18NLocale;
      'plugin::users-permissions.permission': PluginUsersPermissionsPermission;
      'plugin::users-permissions.role': PluginUsersPermissionsRole;
      'plugin::users-permissions.user': PluginUsersPermissionsUser;
      'api::app-label.app-label': ApiAppLabelAppLabel;
      'api::app-notification.app-notification': ApiAppNotificationAppNotification;
      'api::area-master.area-master': ApiAreaMasterAreaMaster;
      'api::category.category': ApiCategoryCategory;
      'api::content-document.content-document': ApiContentDocumentContentDocument;
      'api::content-document-link.content-document-link': ApiContentDocumentLinkContentDocumentLink;
      'api::content-version.content-version': ApiContentVersionContentVersion;
      'api::feature.feature': ApiFeatureFeature;
      'api::lead.lead': ApiLeadLead;
      'api::lead-product.lead-product': ApiLeadProductLeadProduct;
      'api::lead-status-hierarchy.lead-status-hierarchy': ApiLeadStatusHierarchyLeadStatusHierarchy;
      'api::lead-status-history.lead-status-history': ApiLeadStatusHistoryLeadStatusHistory;
      'api::lead-type.lead-type': ApiLeadTypeLeadType;
      'api::localization.localization': ApiLocalizationLocalization;
      'api::marketing.marketing': ApiMarketingMarketing;
      'api::notification-type.notification-type': ApiNotificationTypeNotificationType;
      'api::otp.otp': ApiOtpOtp;
      'api::primaryuser.primaryuser': ApiPrimaryuserPrimaryuser;
      'api::product-display-price-list.product-display-price-list': ApiProductDisplayPriceListProductDisplayPriceList;
      'api::retailer-category.retailer-category': ApiRetailerCategoryRetailerCategory;
      'api::sales-user.sales-user': ApiSalesUserSalesUser;
      'api::sales-user-category.sales-user-category': ApiSalesUserCategorySalesUserCategory;
      'api::secondary-scheme.secondary-scheme': ApiSecondarySchemeSecondaryScheme;
      'api::secondary-scheme-membership.secondary-scheme-membership': ApiSecondarySchemeMembershipSecondarySchemeMembership;
      'api::secondary-scheme-product.secondary-scheme-product': ApiSecondarySchemeProductSecondarySchemeProduct;
      'api::secondary-scheme-slab.secondary-scheme-slab': ApiSecondarySchemeSlabSecondarySchemeSlab;
      'api::secondaryuser.secondaryuser': ApiSecondaryuserSecondaryuser;
      'api::skuproduct.skuproduct': ApiSkuproductSkuproduct;
      'api::sms.sms': ApiSmsSms;
      'api::sub-category.sub-category': ApiSubCategorySubCategory;
      'api::support.support': ApiSupportSupport;
      'api::support-type-subtype-mapping.support-type-subtype-mapping': ApiSupportTypeSubtypeMappingSupportTypeSubtypeMapping;
      'api::user-device.user-device': ApiUserDeviceUserDevice;
    }
  }
}
