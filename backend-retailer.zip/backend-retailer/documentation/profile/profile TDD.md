# Profile details

## Personas

Post login as a retailer, I should be able to see my profile details.I should be able to see my retailer's profile details. Only name, Id and photo at the top.And it also has PersonalDetails,BusinessDetails and Bank&KYC Details. Users will be of primary and secondary users.

- Primaryuser able to update his personaldetails,profilephoto and Bank&KYC details.

- As a secondaryuser able to update profilephoto.

## Services required

1. Service function to get logged in user retailerId or id - allowed for primaryuser and secondaryuser

2. Service function to send Invite link to secondaryuser

3. Service function to get personal profile details for retailer id from SFDC - allowed for primaryuser.
   
   - mobile number, name, email id, alternate mobile no, DOB
   
   - loggedIndate,invitationDate,activationstatus,blockstatus
   
   - marriage anniversary

4. Service function to update personal details in SFDC, allowed only for primaryuser

5. Service function to update profilephoto for both users

6. Service function to get business details for retailer id from SFDC - allowed for primaryuser
   
   - categoryName, salesperson name, salesperson mobile,
   
   - store name and address
   
   - landmark, pincode, state, district
   
   - invitationdate

7. Service function to get Bank & KYC details based on retailer id from SFDC - allowed for retailer/child
   
   - GSTIN (Y/N)
   
   - GST number
   
   - Adhaar number,aadhaarnumber
   
   - PAN number
   
   - Bank account number,AccountHolderName, IFSC code

8. Service function to save updated Bank&KYC details into SFDC - allowed for primaryuser only
   
   - Adhaar number
   
   - Bank account number, IFSC code

## Application Layer

### APIs required

1. API to get all Personaldetails of a primaryuser and secondaryuser.

2. API to update his/her Profilephoto of a primary and secondaryuser.

3. API to update Personaldetails of a primaryuser.

4. API to get all Businessdetails of a primaryuser.

5. API to get all Bank&KYC details of a primaryuser.

6. API to update Bank&KYC details of a primaryuser.

## Questions

| ##  | Question                                                                   | Owner      | Comments |
| --- | -------------------------------------------------------------------------- | ---------- | -------- |
| 1   | Is personaldetails comes from SFDC                                         | SFDC       |          |
| 2   | Are we are mapping secondaryuser with user                                 | Functional |          |
| 3   | Is the retailerId will send in the URL?                                    | Functional |          |
| 4   | If retailerId not displaying in URL then we integrate with authentication? | Functional |          |
| 5   | check mobile duplication of secondaryuser                                  | Functional |          |
| 6   | Need more details of  send invite - send SMS app invites.                  | Functional |          |
| 7   | Is businessdetails only for primaryusers?                                  | Functional |          |
| 8   | Is Bank&KYC also for primaryusers?                                         | Functional |          |
| 9   | Want to know fields of product_category table ?                            | Functional |          |
| 10  | Response schema of PUT - APIs                                              | Functional |          |

