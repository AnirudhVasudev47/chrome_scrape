## API Contract for Support

##### Functions Required

1. **getAllSupportDetails**: To fetch all the details that are used in dropdowns and filters

2. **getTicketHistory**: To get the ticket history of logged in retailer

3. **raiseTicket**: To raise a ticket by logged in retailer.

#### Get All Support Details:

**Description :** This API fetch all the support details used for population support pages

**Logic**: 

1. Service function to fetch all support related details based on logged in user.

**Method**: GET

**Endpoint**: 

```
/api/support/details
```

**Response**:

```json
{
    "data": {
        "supportType": [
            "Product related",
            "Channel related",
            "Complaint",
            "Others"
        ],
        "subType": {
            "Product related": [
                "Product Feedback",
                "Add product category"
            ],
            "Channel related": [
                "Marketing/BTL"
            ],
            "Complaint": [
                "General complaint",
                "Distributor complaint",
                "Sales person complaint",
                "Product complaint"
            ],
            "Others": [
                "NA"
            ]
        },
        "marketMaterialType": [
            "Dealer boards",
            "In shop boards",
            "Product display",
            "Dummy display",
            "Poster",
            "Banner",
            "Dangler",
            "Leaflets",
            "Brochure",
            "Nukkad meets"
        ],
        "productCategory": [
            {
                "categoryId": "01t0K000006QD8cQAG",
                "categoryName": "DU Battery"
            },
            {
                "categoryId": "01t28000004EdoKAAS",
                "categoryName": "Switch Gear"
            }
        ],
        "status": [
            "New",
            "Working",
            "Merged",
            "Pending",
            "Success",
            "Failed",
            "Resolved"
        ],
        "dateFilter": [
            "Last Week",
            "Custom Range",
            "Last Month",
            "Last Quarter"
        ]
    }
}
```

#### 2. Get Ticket History

**Description :** This API will fetch all existing support tickets either closed  or open.

Logic:

   1. Service method to fetch all support tickets raised based on status (open or closed)

**Method**: POST

**Endpoint**: 

```
/api/support/ticket-history
```

###### **Payload**:

```json
{
    "pagination": {
        "page": 1,
        "pageSize": 5
    },
    "filters": {
        "type": "OPEN_TICKET",
       "contentType": [""],
       "ticketStatus": ["New", "Pending"],
        "customDate": {
            "fromDate": "",
            "toDate": ""
        }
    }
}
```

###### **Response**:

```json
{
    "data": [
        {
            "id": 39,
            "ticketCreatedDate": "2024-03-07",
            "ticketStatus": "Pending",
            "ticketId": "4",
            "supportType": "Product related",
            "subType": "Product Feedback",
            "productCategory": "DU Battery",
            "remarks": null
        },
        {
            "id": 43,
            "ticketCreatedDate": "2024-03-17",
            "ticketStatus": "New",
            "ticketId": "8",
            "supportType": "Complaint",
            "subType": "Sales person complaint",
            "remarks": null
        },
        {
            "id": 44,
            "ticketCreatedDate": "2024-03-17",
            "ticketStatus": "New",
            "ticketId": "VC000044",
            "supportType": "Complaint",
            "subType": "Distributor complaint",
            "remarks": null
        },
        {
            "id": 36,
            "ticketCreatedDate": "2024-03-17",
            "ticketStatus": "New",
            "ticketId": "1",
            "supportType": "Product related",
            "subType": "Product Feedback",
            "productCategory": "DU Battery",
            "remarks": null
        }
    ],
    "meta": {
        "pagination": {
            "page": 1,
            "pageSize": 5,
            "pageCount": 1,
            "total": 4
        },
        "filters": {
            "type": "OPEN_TICKET",
            "contentType": [
                ""
            ],
            "ticketStatus": [
                "New",
                "Pending"
            ],
            "customDate": {
                "fromDate": "",
                "toDate": ""
            }
        }
    }
}
```

#### 3. Raise Ticket

**Description**: To raise a new ticket.

Logic:

1. Service method to raise a ticket

**Method**: POST

**Endpoint**: 

```
/api/support/raise-ticket
```

**Request**:

```json
{
        "supportType"       : "Complaint",
        "subType"           : "Distributor complaint",
        "productCategory"  :[""], 
        "marketMaterialType": "Dealer boards",
        "comments"          : ""
}
```

**Response**: 

```json
{
    "status": 200,
    "message": "Raised ticket successfully."
}
```
