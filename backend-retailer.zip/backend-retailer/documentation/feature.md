# Feature Table Documentation

Feature Table Description:

This feature table is required to get the name and other records required for dashboard tiles. This table records can be called to get the required tiles on dashboard UI with appropriate name and logo.I have added these records in the table as per figma dashboard tiles design.

Column 1 name: This is a text record this record consists of the tile name(feature name) to be displayed on the dashboard.

Column 2 visibilitybysecondaryuser: This is a boolean record here if this record is true that means this feature tile on dashboard can be viewed by secondary user.Else if it is false then secondary user cant see this feature tile on the dashboard.

Column 3: logo : This is also a text column which consists of images of logos to be displayed on dashboard but they are stored as base64 links of each logo in the table/

1. The end point for feature table is /api/features. It is a GET endpoint

2. Here i have added a logo column to the exisisting feature table to put our base 64 links of logos of images in that column

3. For example  hitting the API end point to get the 12 th record in the table we can see that.If you want to hit the end point to get all records or a single record in the table with logos the URL is

4. ```
   api/features/12
   ```
   
   And its response will be :
   
   ```
   
   ```

```
{
    "data": {
        "id": 12,
        "attributes": {
            "name": "Scan In",
            "visibleForSecondaryUser": true,
            "createdAt": "2024-02-07T08:50:09.096Z",
            "updatedAt": "2024-02-19T13:11:49.540Z",
            "publishedAt": "2024-02-07T08:50:10.200Z",
            "locale": "en",
            "logo": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAEhSURBVHgB7ZfRUYNAFEXPQwrQDkgH6UDowBaswEzMv1pAkA4sQTsAK7AE1w6SBrJeGBxnMssHGUJmEs7PA5Z59y2zy7triHLJwowHwrh0TUYPqkdKhSQwtDHPx23OS/y54sl7nhmWhLAw3phroltTdV+6n0v8nh3V/otZgeMAykVAOCLVl33D42IPN1Y/lOihIiFCuVRMxdVfDSdiEh5PWAvrW9ENubC6aDUcdnytiQum/le/K94xLlW9j68ZGTWkLRMTx8IaY+ZJ0pwZI1At1ZTUJCJZn5kukqBHGphGQ1r1RCcHcv7CMf8lpI3v3WNoQ9/GjbXnptfODHL9fbdau2WSzpReZ6cspyhX6lA7tUYLdqof+hLhlNyCY0aRrSl+AfWPWNHwRX1tAAAAAElFTkSuQmCC",
            "path": "ScanIn"
        }
    },


  "meta": {}
}
```
