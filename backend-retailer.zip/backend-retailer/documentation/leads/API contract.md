## API Contract for Lead

## <u>Lead Addition</u>

#### Fetching List of Leads

**Description :** This API will fetch all the leads list

**Method**: POST

**EndPoint**: /api/leads/filters

**Request:**

```json
{
    "pagination": {
        "page": 1
    },
    "filters": {
        "categoryIds": ["categoryId", "categoryId"],
        "leadType": ["Institutional", "B2C"]
    }
}
```

**Response**:

```json
{
    "data": [
        {
            "id": 4,
            "leadCode": "1e7d0204-1f76-4929-bad4-7f49ab9530ee",
            "name": "Aman Sharma",
            "email": "as@gmail.com",
            "mobileNumber": "9553998833",
            "leadType": "Institutional",
            "pincode": "101010"
        },
        {
            "id": 2,
            "leadCode": "1e7d0204-1f76-4929-bad4-7f49ab9530xx",
            "name": "Vaibhav Andhre",
            "email": "vandhre@deloitte.com",
            "mobileNumber": "9873998831",
            "leadType": "Consumer",
            "pincode": "101010"
        },
    ],
    "meta": {
        "pagination": {
            "page": 1,
            "pageSize": 10,
            "pageCount": 2,
            "total": 16
        },
        "filters": {
            "categoryIds": ["appliedCategoryId", "appliedCategoryId"],
            "leadType": "applied lead type"
        }
    }
}
```

#### Fetching Category name by leadCode

**Description :** This API will fetch associated category of lead when hitting the accordian

**Method**: GET

**EndPoint**: /api/leads/{leadCode}/category

**Response**:

```json
{
    "data": {
        "categoryName": "DU Battery"
    }
}
```

#### Fetching Filters for Lead List screen

**Description :** This API will fetch list of categories (only solar categories)

**Method**: GET

**EndPoint**: /api/categories/solar

**Response**:

```json
{
    "data": [
        {
            "id": 1,
            "categoryId": "string",
            "categoryName": "string"
        },
        {
            "id": 2,
            "categoryId": "string",
            "categoryName": "string"
        }
    ]
}
```

#### Fetching Lead Details

**Description :** This API will fetch lead details

**Method**: GET

**EndPoint**: /api/leads/:leadCode

**Response:**

```json
{
    "data": {
        "leadCode": "498bb789-a1e2-4076-b9e0-88669b66ca77",
        "name": "Aman Sharma",
        "email": "as@gmail.com",
        "mobileNumber": "9553998833",
        "leadType": "Institutional",
        "pincode": "101010",
        "district": "Jaipur",
        "salesOffice": "M.G.T Nagar",
        "state": "Rajasthan",
        "zone": "Mansorovar",
        "country": "India",
        "leadCategory": {
            "categoryName": "DU Battery"
        },
        "leadSubCategory": {
            "categoryName": "S DU  Battery"
        }
    }
}
```

#### Creating New Lead

**Description :** This API will create

**Method**: POST

**EndPoint**: /api/leads/

**Request:**

```json
{
    "data": {
        "name": "Rahul Sharma",
        "email": "xyz@gmail.com",
        "mobileNumber": "9553998831",
        "categoryId": "categoryId",
        "subCategoryId": "subCategoryId",
        "leadType": "Institutional",
        "pincode": "101010",
        "district": "Jaipur",
        "salesOffice": "M.G.T Nagar",
        "state": "Rajasthan",
        "zone": "Mansorovar",
        "country": "India"
    }
}
```

#### Fetching Pincode details

**Description :** This API will fetch the details (districy, zone etc) from given pincode while creating any new lead

**Method**: GET

**EndPoint**: /api/area-masters?filters[pincode]=500037

**Response:**

```json
{
    "data": [
        {
            "id": 1,
            "attributes": {
                "pincode": "500037",
                "createdAt": "2024-03-01T11:03:29.405Z",
                "updatedAt": "2024-03-01T11:03:33.614Z",
                "publishedAt": "2024-03-01T11:03:33.607Z",
                "city": "Medchal",
                "district": "Medchal",
                "state": "Telangana",
                "area": "Telangana",
                "country": "India",
                "displayName": null,
                "externalId": null,
                "name": null,
                "salesOffice": null,
                "zone": "Medchal"
            }
        }
    ],
    "meta": {
        "pagination": {
            "page": 1,
            "pageSize": 25,
            "pageCount": 1,
            "total": 1
        }
    }
}
```

#### Fetching Sub categories

**Description :** This API will fetch sub category list based on the selected category while creating any new lead

**Method**: GET

**EndPoint**: /api/sub-categories?filters[category][categoryId]=01t0K000006QD8cQAG

**Response:**

```json
{
    "data": [
        {
            "id": 3,
            "attributes": {
                "subCategoryCode": "96583bcc-e098-45f0-bcd2-4031f5ba551a",
                "subCategoryId": "c3",
                "subCategoryName": "S DU  Battery",
                "createdAt": "2024-03-04T04:44:24.787Z",
                "updatedAt": "2024-03-04T04:44:25.640Z",
                "publishedAt": "2024-03-04T04:44:25.638Z"
            }
        }
    ],
    "meta": {
        "pagination": {
            "page": 1,
            "pageSize": 25,
            "pageCount": 1,
            "total": 1
        }
    }
}
```

---

### <u>Lead Management</u>

#### Fetching List in lead management screen

**Description :** This API will fetch those leads only which are created by call center and assigned/associated to the logged in retailer

**Method**: POST

**EndPoint**: /api/assigned-leads

**Request:**

```json
{
    "pagination": {
        "page": 1,
        "pageSize": 10
    },
    "filters": {
        "status": ["Partner Assigned", "Closed", "New"],
        "subStatus": ["New lead assigned"]
    }
}
```

**Response**:

```json
{
    "data": [
        {
            "id": 10,
            "leadCode": "08e6a05a-66b8-4eb9-bc43-3b09eea3bff6",
            "name": "Om",
            "status": "Partner Assigned",
            "receivedOn": null,
            "leadCategory": {
                "categoryName": "DU Battery"
            }
        },
        {
            "id": 9,
            "leadCode": "cf242800-f662-47f9-94ee-722186a538bb",
            "name": "Jai",
            "status": "Closed",
            "receivedOn": null,
            "leadCategory": {
                "categoryName": "DU Battery"
            }
        },
        {
            "id": 1,
            "leadCode": "9c582cf0-072c-4732-885b-02078895e425",
            "name": "Rahul sharma",
            "status": "New",
            "receivedOn": null,
            "leadCategory": null
        }
    ],
    "meta": {
        "pagination": {
            "page": 10,
            "pageSize": 1,
            "pageCount": 1,
            "total": 3
        },
        "filters": {
            "status": [
                "Partner Assigned",
                "Closed",
                "New"
            ],
            "subStatus": [
                "New lead assigned"
            ]
        }
    }
}
```

#### Fetching Filters in lead management screen

**Description :** This API will fetch filters data

**Method**: GET

**EndPoint**: /api/leads/status-filters?status=Closed&status=Partner assigned

**Response:**

```json
{
    "data": {
        "status": [
            "Partner assigned",
            "Closed"
        ],
        "subStatus": [
            "No answer",
            "Switched off",
            "Purchase later",
            "New lead assigned",
            "Lead accepted",
            "Catalogue shared",
            "Site survey",
            "Site not ready (construction)",
            "Site ready",
            "Water testing (SWH)",
            "Quotation",
            "Distribution co approval SPS",
            "Product installed",
            "Distribution co inspection SPS",
            "Commissioning (SPS and SWH)",
            "Awaiting partner assignment",
            "Enquiry/Other category",
            "Junk",
            "Duplicate",
            "Not convertible",
            "Partner feedback valid",
            "Partner feedback invalid",
            "Converted and verified"
        ]
    }
}
```

#### API to show lead details in lead management screen

**Description :** This API will fetch the lead details

**Method**: GET

**EndPoint**: /api/assigned-leads/:leadCode

**Response:**

```json
{
    "data": {
        "leadCode": "1f6c9b30-e7ce-4224-8b16-ce7edfe7fadc",
        "leadId": null,
        "name": "Institution ",
        "email": "ini@gmail.com",
        "mobileNumber": "8989898989",
        "leadType": "Institutional",
        "pincode": "123456",
        "district": "Jaipur",
        "state": "Rajasthan",
        "salesOffice": "",
        "zone": "North",
        "country": "India",
        "leadSource": "Retailer",
        "referredBy": "EM",
        "installationDate": "yyyy-mm-dd",
        "roofType": "ON",
        "shadeFreeRoofArea": "EE",
        "avgMonthlyElectricityBill": 202.22,
        "enquiryOver10kw": "Yes",
        "leadCategory": {
            "categoryName": "Solar Mixer"
        },
        "leadSubCategory": {
            "categoryName": "Solar Mixer sub"
        }
    }
}
```

#### 

#### API to update the lead status in lead management screen

**Description :** This API will update the lead status from the button "Lead accepted/ Lead Rejected"

**Method**: PUT

**EndPoint**: /api/leads/update-status

**Request:**

```json
{
    "data": {
        "leadStatus": true // or false
    }
}
```

#### 

#### API to get status of lead details in lead management screen

**Description :** This API will fetch the particular lead status details

**Method**: GET

**EndPoint**: /api/assigned-leads/:leadCode/status

**Response:**

```json
{
    "data": {
        "status": "Partner assigned",
        "subStatus": "Catalogue shared",
        "subStatus2": null,
        "comment": "1t",
        "installationDate": "2023-04-21",
        "followUpDate": "2023-04-30",
        "image": null,
        "subStatusMetaData": {
            "parentId": 8,
            "parentStatus": "Catalogue shared",
            "isPositive": false
        }
    }
}
```

#### API to update lead status in lead management screen

**Description :** This API will update the lead status and followUp, installation date

**Method**: PUT

**EndPoint**: /api/assigned-leads/:leadCode/status

**Request:**

```json
{
    "data": {
        "status": "Partner assigned",
        "subStatus": "Site ready",
        "childId": 17,
        "subStatus2": null,
        "comment": "",
        "followUpDate": "2023-04-30",
        "installationDate": "2023-04-21"
    }
}
```

to update the lead status with lead management

```json
{
  "data": {
    "status": "Partner assigned",
    "subStatus": "Lead accepted"
  }
}
```

#### API to upload image in lead management screen

**Description :** This API will upload the product image

**Method**: POST

**EndPoint**: /api/content-documents

**Request:**

```json
{
    "data": {
        "title": "lead-image",
        "image": "base64:::image",
        "keyName": "lead",
        "keyId": "leadCode" // keyId should be the leadCode unique uuid
    }
}
```

#### API to get products of lead in lead management screen

**Description :** This API will fetch the products of particular lead

**Method**: GET

**EndPoint**: /api/assigned-leads/:leadCode/products

**Response:**

```json
{
    "data": {
        "leadProducts": [
            {
                "leadProductCode": "462c6778-7c7b-4c57-af2f-1a0dc4db1894",
                "productSKU": "ONE392SELLL10",
                "pricePerSKU": 1500,
                "quantity": 2,
                "totalPricePerSKU": 3000
            },
            {
                "leadProductCode": "8447300d-3cd6-4d0c-a973-4cdd73a7a55f",
                "productSKU": "TWO012938WQ",
                "pricePerSKU": 4500,
                "quantity": 4,
                "totalPricePerSKU": 18000
            }
        ],
        "total": 3000
    }
}
```

#### API to update lead details in lead management screen

**Description :** This API will create the lead product

**Method**: POST

**EndPoint**: /api/assigned-leads/:leadCode/products

**Request:**

```json
{
    "data": {
        "total": 21000,
        "leadProducts": [
            {
                "categoryId": "01t0K000006QD8cQAG",
                "subCategoryId": "c3",
                "productSKU": "ONE392SELLL10",
                "pricePerSKU": 1500,
                "quantity": 2,
                "totalPricePerSKU": 3000
            },
            {
                "categoryId": "01t0K000006QD8cQAG",
                "subCategoryId": "c3",
                "productSKU": "TWO012938WQ",
                "pricePerSKU": 4500,
                "quantity": 4,
                "totalPricePerSKU": 18000
            }
        ]
    }
}
```

#### 

#### API to get next sequence of subStatus mapping in lead management screen

**Description :** This API will fetch the sub status as per the current subStatus for the lead

**Method**: GET

**EndPoint**: /api/lead-sub-status?fields[0]=childId&fields[1]=childStatus&fields[2]=isPositive&leadCode=leadCode

**Response:**

```json
{
    "data": [
        {
            "id": 18,
            "childId": 19,
            "childStatus": "Quotation",
            "isPositive": true
        }
    ]
}
```

#### API to get next sequence of subStatus2 mapping in lead management screen

**Description :** This API will fetch the sub status2 as per the subStatus selection, *<mark>where parentId is the chidId from above API</mark>*

**Method**: GET

**EndPoint**: /api/lead-sub-status2?filters[parentId]=2&filters[hasSubStatus2]=true&fields[0]=childId&fields[1]=childStatus

**Response:**

```json
{
    "data": [
        {
            "id": 11,
            "attributes": {
                "childId": 12,
                "childStatus": "Price"
            }
        },
        {
            "id": 12,
            "attributes": {
                "childId": 13,
                "childStatus": "No requirement"
            }
        },
        {
            "id": 13,
            "attributes": {
                "childId": 14,
                "childStatus": "Installation challenges"
            }
        }
    ],
    "meta": {
        "pagination": {
            "page": 1,
            "pageSize": 25,
            "pageCount": 1,
            "total": 3
        }
    }
}
```

#### 

#### API to fetch the sku products in lead management screen

**Description :** This API will fetch the products list while adding the lead product

****Method**: GET

**EndPoint**: /api/sku-products?fields[0]=skuProduct&filters[skuProduct][$containsi]=SKU

**Response:**

```json
{
    "data": [
        {
            "id": 1,
            "attributes": {
                "skuProduct": "SKU-PRODUCT"
            }
        },
        {
            "id": 2,
            "attributes": {
                "skuProduct": "SKU_PRODUCT1"
            }
        }
    ],
    "meta": {
        "pagination": {
            "page": 1,
            "pageSize": 25,
            "pageCount": 1,
            "total": 2
        }
    }
}
```

#### API to get the status history of lead

**Description :** This API will fetch the history of lead status 

****Method**: GET

**EndPoint**: /api/lead-status-progress/:leadCode

**Response:**

```json
{
    "data": [
        {
            "subStatus": "Lead accepted",
            "date": "2024-03-12"
        },
        {
            "subStatus": "Catalogue shared",
            "date": "2024-03-13"
        },
        {
            "subStatus": "Site survey",
            "date": "2024-03-14"
        },
        {
            "subStatus": "Site ready",
            "date": "2024-03-14"
        },
        {
            "subStatus": "Distribution co approval SPS",
            "date": null
        },
        {
            "subStatus": "Distribution co inspection SPS",
            "date": null
        },
        {
            "subStatus": "Product installed",
            "date": null
        },
        {
            "subStatus": "Distribution co inspection SPS",
            "date": null
        },
        {
            "subStatus": "Commissioning (SPS and SWH)",
            "date": null
        },
        {
            "subStatus": "Converted",
            "date": null
        }
    ]
}
```

#### 
