## API Contract for Product and price list

#### Fetching List of Categories

**Description :** This API will fetch all the categories

**Method**: GET

**EndPoint**:` /api/categories/list?fields[0]=categoryId&fields[1]=categoryName&fields[2]=logo`

**Response**:

```json
{
    "data": [
        {
            "id": 1,
            "attributes": {
                "categoryId": "01t0K000006QD8cQAG",
                "categoryName": "DU Battery",
                "logo": null
            }
        },
        {
            "id": 2,
            "attributes": {
                "categoryId": "01t28000004EdoAAAS",
                "categoryName": "Single Phase Pumps",
                "logo": null
            }
        },
        {
            "id": 3,
            "attributes": {
                "categoryId": "01t28000004EdoHAAS",
                "categoryName": "Digital UPS",
                "logo": null
            }
        },
        {
            "id": 4,
            "attributes": {
                "categoryId": "01t28000004EdoKAAS",
                "categoryName": "Switch Gear",
                "logo": null
            }
        },
        {
            "id": 5,
            "attributes": {
                "categoryId": "01t28000004EdoNAAS",
                "categoryName": "Solar Mixer",
                "logo": null
            }
        },
        {
            "id": 6,
            "attributes": {
                "categoryId": "01t0K000006QD8cZZZ",
                "categoryName": "Electric solar water heaters",
                "logo": null
            }
        }
    ],
    "meta": {
        "pagination": {
            "page": 1,
            "pageSize": 25,
            "pageCount": 1,
            "total": 6
        }
    }
}
```

#### Fetching filters for product manual and videos, price list

**Description :** This API will fetch the filters to be shown

**Method**: GET

**EndPoint**: `/api/product-price-list/filters?categoryId=categoryId`

**Response**:

```json
{
    "data": {
        "subCategories": [
            {
                "subCategoryId": "1001",
                "subCategoryName": "SOLAR PANELS"
            }
        ],
        "SKUproducts": [
            {
                "subCategoryId": "c10011",
                "skuProductName": "product name",
                "skuProduct": "SOL_98765"
            }
        ],
        "productDocumentContentType": [
            "Product training",
            "Product flyer",
            "Product brochure",
            "Product scheme"
        ],
        "productVideoContentType": [
            "Product training",
            "Product demo",
            "Product Ad"
        ]
    }
}
```

#### Fetching product documents list

**Description :** This API will fetch list of product documents based on the retailer's region and salesOffice

**Method**: POST

**EndPoint**: `/api/product-documents-search`

**Request:**

```json
{
    "filters": {
        "categoryId": "01t28000004EdoNAAS",
        "subCategoryId": [
            "c1"
        ],
        "documentType": {
            "$containsi": [
                "Product flyer", "Product training"
            ]
        },
        "skuProduct": {
            "$containsi": [
                "SOL_1234"
            ]
        },
        "uploadedAt": {
            "$gte": "2023-02-24",
            "$lte": "2024-04-27"
        }
    },
    "pagination": {
        "page": 1,
        "pageSize": 10
    }
}
```

**Response**:

```json
{
    "data": [
        {
            "subCategoryId": "c4",
            "subCategoryName": "sub category4",
            "data": [
                {
                    "id": 8,
                    "contentDocumentId": "CD_10021",
                    "title": "Water heaters VG.pdf",
                    "uploadedAt": "2024-03-19"
                }
            ]
        }
    ],
    "meta": {
        "pagination": {
            "page": 1,
            "pageSize": 10,
            "pageCount": 1,
            "total": 1
        },
        "filters": {
            "categoryId": "01t28000004EdoNAAS",
            "subCategoryId": [
                "c1"
            ],
            "skuProduct": {
                "$containsi": [
                    "SOL_1234"
                ]
            },
            "documentType": {
                "$containsi": "Product price list book"
            }
        }
    }
}
```

#### Fetching Product videos

**Description :** This API will fetch list of product videos with paginated data

**Method**: POST

**EndPoint**: `/api/product-videos-search`

**Request:**

```json
{
    "filters": {
        "categoryId": "01t28000004EdoNAAS",
        "subCategoryId": [
            "c1"
        ],
        "documentType": {
            "$containsi": [
                "Product training"
            ]
        },
        "skuProduct": {
            "$containsi": [
                "SOL_1234"
            ]
        },
        "youtubeCreatedAt": {
            "$gte": "2023-02-24",
            "$lte": "2024-04-27"
        }
    },
    "pagination": {
        "page": 1,
        "pageSize": 10
    }
}
```

**Response:**

```json
{
    "data": [
        {
            "subCategoryId": "c4",
            "subCategoryName": "sub category4",
            "data": [
                {
                    "id": 7,
                    "youtubeTitle": "U title",
                    "youtubeLink": "youtubeLink",
                    "youtubeCreatedAt": "2024-03-19"
                },
                {
                    "id": 5,
                    "youtubeTitle": "AWS test",
                    "youtubeLink": "http:",
                    "youtubeCreatedAt": "2024-03-18"
                }
            ]
        }
    ],
    "meta": {
        "pagination": {
            "page": 1,
            "pageSize": 10,
            "pageCount": 1,
            "total": 1
        },
        "filters": {
            "categoryId": "01t28000004EdoNAAS",
            "subCategoryId": [
                "c1"
            ],
            "skuProduct": {
                "$containsi": [
                    "SOL_1234"
                ]
            },
            "salesOffice": "Mukutam",
            "zone": "North",
            "documentType": {
                "$containsi": "Product price list book"
            }
        }
    }
}
```

#### API to fetching the price list

**Description :** This API will fetch the price list

**Method**: POST

**EndPoint**: `/api/price-list-search`

**Request:**

```json
{
    "filters": {
        "categoryId": "01t28000004EdoNAAS",
        "subCategoryId": [
            "c1"
        ],
        "skuProduct": {
            "$containsi": [
                "SOL_1234"
            ]
        },
        "youtubeCreatedAt": {
            "$gte": "2023-02-24",
            "$lte": "2024-04-27"
        }
    },
    "pagination": {
        "page": 1,
        "pageSize": 10
    }
}
```

**Request:**

```json
{
    "data": [
        {
            "subCategoryId": "c4",
            "subCategoryName": "sub category4",
            "data": [
                {
                    "id": 10,
                    "contentDocumentId": "CD_10023",
                    "title": "price list pdf",
                    "uploadedAt": "2024-03-25"
                }
            ]
        }
    ],
    "meta": {
        "pagination": {
            "page": 1,
            "pageSize": 10,
            "pageCount": 1,
            "total": 1
        },
        "filters": {
            "categoryId": "01t28000004EdoNAAS",
            "subCategoryId": [
                "c1"
            ],
            "skuProduct": {
                "$containsi": [
                    "SOL_1234"
                ]
            },
            "salesOffice": "Mukutam",
            "zone": "North",
            "documentType": {
                "$containsi": "Product price list book"
            }
        }
    }
}
```

#### Fetching content document

**Description :** This API will fetch the binary data (blob) so we can use it to download the content

**Method**: GET

**EndPoint**: `/api/content-versions?filters[contentDocumentId]=CD_10021`

**Response:**

```json
{
    "data": [
        {
            "id": 1,
            "attributes": {
                "contentVersionCode": "f719d7a6-325c-40eb-a4e2-6bc1a6ec0a02",
                "contentDocumentId": "CD_10021",
                "contentUrl": "url",
                "versionData": "blob data"
                "createdAt": "2024-03-19T04:40:03.318Z",
                "updatedAt": "2024-03-19T04:40:04.307Z",
                "publishedAt": "2024-03-19T04:40:04.301Z"
            }
        }
    ],
    "meta": {
        "pagination": {
            "page": 1,
            "pageSize": 25,
            "pageCount": 1,
            "total": 1
        }
    }
} 
```
