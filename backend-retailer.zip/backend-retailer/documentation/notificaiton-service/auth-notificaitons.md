# Notification Service Documentation

## Overview

The authentication service provides APIs which are used to send notifications to users.

Example: to send otp via sms, to send invite link via sms, etc

## APIs

### 1. Send Invite Link

- **Endpoint:** `notification/send-invite`

- **Method:** `POST`

- **Description:** Sends both android and ios invitation links to retailers.

- **Request Body:**

  ```json
  {
    "details": [
      {
        "name": "Ram",
        "mobileNumber": 1234567890
      },
      {
        "name": "Padmini",
        "mobileNumber": 0987654321
      }
    ]
  }
  ```

- **Response:**

  - `200 OK` on success:

  ```json
  {
    "data": [
      {
        "status": "Success"
      }
    ]
  }
  ```

### 2. Send Otp

- **Endpoint:** `notification/send-otp`

- **Method:** `POST`

- **Description:** Sends otp sms to retailers when mobile number and otp provided

- **Request Body:**

  ```json
  {
    "mobileNumber": 9898989898,
    "otp": 123456
  }
  ```

- **Response:**

  - `200 OK` on success:

  ```json
  {
    "data": [
      {
        "status": "Success"
      }
    ]
  }
  ```

- **Request Body:**

  ```json
  {
    "mobileNumber": 988989898,
    "otp": 123456
  }
  ```

- **Response:**

  - `400 BAD REQUEST` on Error:

  ```json
  {
    "message": " The \"INTERNATIONAL_PHONE\" service is disabled for you. Kindly get the service enabled before using this action\n"
  }
  ```
