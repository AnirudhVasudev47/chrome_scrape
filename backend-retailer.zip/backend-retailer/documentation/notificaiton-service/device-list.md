# Register Device

## Overview

This API allows you to add devices registered to the FCM to the strapi database.

## APIs

### 1. Add device

- **Endpoint:** `api/user-devices`

- **Method:** `POST`

- **Description:** Add a device

- **Request:**

  `200 OK` on success:

  ```json
   {
      "data": {
          "deviceId": "Unique device ID",
          "fcmToken": "FCM token recieved",
          "platform": "android or ios",
          "currentVersion": "Current version of the app",
          "latestVersion": "Latest available version",
          "retailerId": "Retailer id"
      }
   }
  ```
