# Notification List Documentation

## Overview

The Notification List gives you the list of all the notifications sent to each user.

## APIs

### 1. Get all the notifications

- **Endpoint:** `api/app-notifications`

- **Method:** `GET`

- **Description:** Gets all the notifications without any filters.

- **Response:**

  - `200 OK` on success:

  ```json
  {
    "data": [
        {
            "id": 1,
            "attributes": {
                "title": "Birthday",
                "description": "Dear Partner Rahul Sharma, wishing you a very happy birthday. Here is 250 points additional points.",
                "isOpened": false,
                "retailerId": "userId1234",
                "date": "2024-03-21T23:15:00.000Z",
                "createdAt": "2024-03-22T07:46:39.962Z",
                "updatedAt": "2024-03-22T07:46:53.070Z",
                "publishedAt": "2024-03-22T07:46:53.066Z",
                "notificationType": {
                    "data": {
                        "id": 1,
                        "attributes": {
                            "name": "Special Event",
                            "icon": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAANJSURBVHgB7VbdUdtAEP50JnmNU0FMBbiDyBWAK4BUEGPITN5i3jKTAE4FmApwKrCoAFNBRAfOYwLo8u3dWpals+wheQvfjEeSb2//7tvdA/43RHWLkx6aMDig0A4lW/KfzXALi2FniHRJtk+5CPt8nVmL750zjJ5kePIB7egRV3ODlY0Wg7dnOMnlDzGODHZzAYvUNtDtfMF0Y8OMtBU1cMPXJr2/5nPMyKeqUDKwr8aHNH6Y7ztGjIx7I3ziZwsSvUEnZDxoOOnjh0RqgcvOKQ4qjkk2MkycY49UPERSkTnCkMrfS+TxGbbL6yawYU/Tm4aMCiQCG+Gb87zhoqviEQPRIbqYwXitYabKCTHFl6jDA4b61g4tMwszOud1RAxmrWFDJnukqIFTDNzxtSmcCAplXgfP/FXVTFV4pm9N1EBKjWf4Rp1IV4g5Hczez/WGI89AermLOhifPmV9EI5cXjapbi8jY+n4NMfX/TBxXLkhXxuFZK6Pub4g6TjgVEAx65E1OnEfFiN2q0t1BsZgn6TpwadxHJ+iW3SIj5YyPfbb2UQ2NeyUsKy4eIEVZy01zpLpCclchH2cq0NzSOs8XNU6t7AC4uXkI8/7F5VF9D5SByz/M+zVX5fPLfMMv+P6jOtjKbe5U88QrBuLkuI9Th2p1/lZu7HH3Cah+nUE4yiVsgyRqtYwZ2tPJ0xtE1HGnxQd4N6B7vWjEVwPECwqe8tSECbHbp80Byl+IVSkRMlcyewVGswSe0nIFn7nl4KWykw5xbpFB6Mlo4a1q0XP0nhXZu6Sk2LgntHpbFbjwyUZfyvxs1miz9wITWUt71wFo1P7ggI1RgWdz35s0kF3C6GB8/L4kyyILtEpupnNq/maM1xsbxTsilJsCDo4yI0bXLh7WslBuSzAd762cMDJuiljeM3xN45uHRPrkBy5FhuHUi4otOEZHdk2bsqIURLpqUYFhZQHp5oenfzczdXw0Oe3gxH+Bg9unArz43K6c+ek/uEYvWO0OQCN8DV0U2hfTlVXHBTKcsLGWzzX166m7muuMBuC5XLHQNrMYh6xRu+/t/i00FcFqT7BP4Zeg28Wni3WxHBisSI1T8XLRQ/gud7mI1VBAiZ/AN4aTRKic5QaAAAAAElFTkSuQmCC",
                            "createdAt": "2024-03-22T07:44:13.630Z",
                            "updatedAt": "2024-03-22T07:44:13.630Z",
                            "publishedAt": "2024-03-22T07:47:09.709Z"
                        }
                    }
                }
            }
        }
    ],
    "meta": {
        "pagination": {
            "page": 1,
            "pageSize": 25,
            "pageCount": 1,
            "total": 1
        }
    }
  }
  ```


### 1. Get all the notification types

- **Endpoint:** `api/notification-types`

- **Method:** `GET`

- **Description:** Gets all the notifications types.

- **Response:**

  - `200 OK` on success:

  ```json
  {
    "data": [
        {
            "id": 1,
            "attributes": {
                "name": "Special Event",
                "icon": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAANJSURBVHgB7VbdUdtAEP50JnmNU0FMBbiDyBWAK4BUEGPITN5i3jKTAE4FmApwKrCoAFNBRAfOYwLo8u3dWpals+wheQvfjEeSb2//7tvdA/43RHWLkx6aMDig0A4lW/KfzXALi2FniHRJtk+5CPt8nVmL750zjJ5kePIB7egRV3ODlY0Wg7dnOMnlDzGODHZzAYvUNtDtfMF0Y8OMtBU1cMPXJr2/5nPMyKeqUDKwr8aHNH6Y7ztGjIx7I3ziZwsSvUEnZDxoOOnjh0RqgcvOKQ4qjkk2MkycY49UPERSkTnCkMrfS+TxGbbL6yawYU/Tm4aMCiQCG+Gb87zhoqviEQPRIbqYwXitYabKCTHFl6jDA4b61g4tMwszOud1RAxmrWFDJnukqIFTDNzxtSmcCAplXgfP/FXVTFV4pm9N1EBKjWf4Rp1IV4g5Hczez/WGI89AermLOhifPmV9EI5cXjapbi8jY+n4NMfX/TBxXLkhXxuFZK6Pub4g6TjgVEAx65E1OnEfFiN2q0t1BsZgn6TpwadxHJ+iW3SIj5YyPfbb2UQ2NeyUsKy4eIEVZy01zpLpCclchH2cq0NzSOs8XNU6t7AC4uXkI8/7F5VF9D5SByz/M+zVX5fPLfMMv+P6jOtjKbe5U88QrBuLkuI9Th2p1/lZu7HH3Cah+nUE4yiVsgyRqtYwZ2tPJ0xtE1HGnxQd4N6B7vWjEVwPECwqe8tSECbHbp80Byl+IVSkRMlcyewVGswSe0nIFn7nl4KWykw5xbpFB6Mlo4a1q0XP0nhXZu6Sk2LgntHpbFbjwyUZfyvxs1miz9wITWUt71wFo1P7ggI1RgWdz35s0kF3C6GB8/L4kyyILtEpupnNq/maM1xsbxTsilJsCDo4yI0bXLh7WslBuSzAd762cMDJuiljeM3xN45uHRPrkBy5FhuHUi4otOEZHdk2bsqIURLpqUYFhZQHp5oenfzczdXw0Oe3gxH+Bg9unArz43K6c+ek/uEYvWO0OQCN8DV0U2hfTlVXHBTKcsLGWzzX166m7muuMBuC5XLHQNrMYh6xRu+/t/i00FcFqT7BP4Zeg28Wni3WxHBisSI1T8XLRQ/gud7mI1VBAiZ/AN4aTRKic5QaAAAAAElFTkSuQmCC",
                "createdAt": "2024-03-22T07:44:13.630Z",
                "updatedAt": "2024-03-22T07:44:13.630Z",
                "publishedAt": "2024-03-22T07:47:09.709Z"
            }
        }
    ],
    "meta": {
        "pagination": {
            "page": 1,
            "pageSize": 25,
            "pageCount": 1,
            "total": 1
        }
    }
  }
  ```

### 2. Filter Notifications

- **Endpoint:** `api/app-notifications`

- **Method:** `GET`

- **Filters:** Queries can accept a filters parameter with the following syntax:

  Example: `?filters[field][operator]=value`

  Sample: `notification/find?filters[type][$eq]=InApp Notification&filters[id][$eq]=2`

| Operator        | Description                              |
|-----------------|------------------------------------------|
| `$eq`           | Equal                                    |
| `$eqi`          | Equal (case-insensitive)                 |
| `$ne`           | Not equal                                |
| `$nei`          | Not equal (case-insensitive)             |
| `$lt`           | Less than                                |
| `$lte`          | Less than or equal to                    |
| `$gt`           | Greater than                             |
| `$gte`          | Greater than or equal to                 |
| `$in`           | Included in an array                     |
| `$notIn`        | Not included in an array                 |
| `$contains`     | Contains                                 |
| `$notContains`  | Does not contain                         |
| `$containsi`    | Contains (case-insensitive)              |
| `$notContainsi` | Does not contain (case-insensitive)      |
| `$null`         | Is null                                  |
| `$notNull`      | Is not null                              |
| `$between`      | Is between                               |
| `$startsWith`   | Starts with                              |
| `$startsWithi`  | Starts with (case-insensitive)           |
| `$endsWith`     | Ends with                                |
| `$endsWithi`    | Ends with (case-insensitive)             |
| `$or`           | Joins the filters in an "or" expression  |
| `$and`          | Joins the filters in an "and" expression |
| `$not`          | Joins the filters in a "not" expression  |

- **Description:** Filter notification according to the requirements. The different types of notifications are InApp
  Notification, Push Notification, SMS, Email. InApp Notification are for notifications displayed inside the
  application, Push Notification are the notification sent via FCM.
  For further reference
  please [Click Here](https://docs.strapi.io/dev-docs/api/rest/filters-locale-publication)

- **Response:**

  - `200 OK` on success:

  ```json
  [
    {
    "data": [
        {
            "id": 1,
            "attributes": {
                "title": "Birthday",
                "description": "Dear Partner Rahul Sharma, wishing you a very happy birthday. Here is 250 points additional points.",
                "isOpened": false,
                "retailerId": "userId1234",
                "date": "2024-03-21T23:15:00.000Z",
                "createdAt": "2024-03-22T07:46:39.962Z",
                "updatedAt": "2024-03-22T07:46:53.070Z",
                "publishedAt": "2024-03-22T07:46:53.066Z",
                "notificationType": {
                    "data": {
                        "id": 1,
                        "attributes": {
                            "name": "Special Event",
                            "icon": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAANJSURBVHgB7VbdUdtAEP50JnmNU0FMBbiDyBWAK4BUEGPITN5i3jKTAE4FmApwKrCoAFNBRAfOYwLo8u3dWpals+wheQvfjEeSb2//7tvdA/43RHWLkx6aMDig0A4lW/KfzXALi2FniHRJtk+5CPt8nVmL750zjJ5kePIB7egRV3ODlY0Wg7dnOMnlDzGODHZzAYvUNtDtfMF0Y8OMtBU1cMPXJr2/5nPMyKeqUDKwr8aHNH6Y7ztGjIx7I3ziZwsSvUEnZDxoOOnjh0RqgcvOKQ4qjkk2MkycY49UPERSkTnCkMrfS+TxGbbL6yawYU/Tm4aMCiQCG+Gb87zhoqviEQPRIbqYwXitYabKCTHFl6jDA4b61g4tMwszOud1RAxmrWFDJnukqIFTDNzxtSmcCAplXgfP/FXVTFV4pm9N1EBKjWf4Rp1IV4g5Hczez/WGI89AermLOhifPmV9EI5cXjapbi8jY+n4NMfX/TBxXLkhXxuFZK6Pub4g6TjgVEAx65E1OnEfFiN2q0t1BsZgn6TpwadxHJ+iW3SIj5YyPfbb2UQ2NeyUsKy4eIEVZy01zpLpCclchH2cq0NzSOs8XNU6t7AC4uXkI8/7F5VF9D5SByz/M+zVX5fPLfMMv+P6jOtjKbe5U88QrBuLkuI9Th2p1/lZu7HH3Cah+nUE4yiVsgyRqtYwZ2tPJ0xtE1HGnxQd4N6B7vWjEVwPECwqe8tSECbHbp80Byl+IVSkRMlcyewVGswSe0nIFn7nl4KWykw5xbpFB6Mlo4a1q0XP0nhXZu6Sk2LgntHpbFbjwyUZfyvxs1miz9wITWUt71wFo1P7ggI1RgWdz35s0kF3C6GB8/L4kyyILtEpupnNq/maM1xsbxTsilJsCDo4yI0bXLh7WslBuSzAd762cMDJuiljeM3xN45uHRPrkBy5FhuHUi4otOEZHdk2bsqIURLpqUYFhZQHp5oenfzczdXw0Oe3gxH+Bg9unArz43K6c+ek/uEYvWO0OQCN8DV0U2hfTlVXHBTKcsLGWzzX166m7muuMBuC5XLHQNrMYh6xRu+/t/i00FcFqT7BP4Zeg28Wni3WxHBisSI1T8XLRQ/gud7mI1VBAiZ/AN4aTRKic5QaAAAAAElFTkSuQmCC",
                            "createdAt": "2024-03-22T07:44:13.630Z",
                            "updatedAt": "2024-03-22T07:44:13.630Z",
                            "publishedAt": "2024-03-22T07:47:09.709Z"
                        }
                    }
                }
            }
        }
    ],
    "meta": {
        "pagination": {
            "page": 1,
            "pageSize": 25,
            "pageCount": 1,
            "total": 1
        }
      }
    }
  ]
  ```


### 2. Get single notification

- **Endpoint:** `api/app-notifications/:id`

- **Method:** `GET`

- **Description:** Get one notification

- **Response:**

  - `200 OK` on success:

  ```json
   {
    "data": {
            "id": 1,
            "attributes": {
                "title": "Birthday",
                "description": "Dear Partner Rahul Sharma, wishing you a very happy birthday. Here is 250 points additional points.",
                "isOpened": false,
                "retailerId": "userId1234",
                "date": "2024-03-21T23:15:00.000Z",
                "createdAt": "2024-03-22T07:46:39.962Z",
                "updatedAt": "2024-03-22T07:46:53.070Z",
                "publishedAt": "2024-03-22T07:46:53.066Z",
                "notificationType": {
                    "data": {
                        "id": 1,
                        "attributes": {
                            "name": "Special Event",
                            "icon": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAANJSURBVHgB7VbdUdtAEP50JnmNU0FMBbiDyBWAK4BUEGPITN5i3jKTAE4FmApwKrCoAFNBRAfOYwLo8u3dWpals+wheQvfjEeSb2//7tvdA/43RHWLkx6aMDig0A4lW/KfzXALi2FniHRJtk+5CPt8nVmL750zjJ5kePIB7egRV3ODlY0Wg7dnOMnlDzGODHZzAYvUNtDtfMF0Y8OMtBU1cMPXJr2/5nPMyKeqUDKwr8aHNH6Y7ztGjIx7I3ziZwsSvUEnZDxoOOnjh0RqgcvOKQ4qjkk2MkycY49UPERSkTnCkMrfS+TxGbbL6yawYU/Tm4aMCiQCG+Gb87zhoqviEQPRIbqYwXitYabKCTHFl6jDA4b61g4tMwszOud1RAxmrWFDJnukqIFTDNzxtSmcCAplXgfP/FXVTFV4pm9N1EBKjWf4Rp1IV4g5Hczez/WGI89AermLOhifPmV9EI5cXjapbi8jY+n4NMfX/TBxXLkhXxuFZK6Pub4g6TjgVEAx65E1OnEfFiN2q0t1BsZgn6TpwadxHJ+iW3SIj5YyPfbb2UQ2NeyUsKy4eIEVZy01zpLpCclchH2cq0NzSOs8XNU6t7AC4uXkI8/7F5VF9D5SByz/M+zVX5fPLfMMv+P6jOtjKbe5U88QrBuLkuI9Th2p1/lZu7HH3Cah+nUE4yiVsgyRqtYwZ2tPJ0xtE1HGnxQd4N6B7vWjEVwPECwqe8tSECbHbp80Byl+IVSkRMlcyewVGswSe0nIFn7nl4KWykw5xbpFB6Mlo4a1q0XP0nhXZu6Sk2LgntHpbFbjwyUZfyvxs1miz9wITWUt71wFo1P7ggI1RgWdz35s0kF3C6GB8/L4kyyILtEpupnNq/maM1xsbxTsilJsCDo4yI0bXLh7WslBuSzAd762cMDJuiljeM3xN45uHRPrkBy5FhuHUi4otOEZHdk2bsqIURLpqUYFhZQHp5oenfzczdXw0Oe3gxH+Bg9unArz43K6c+ek/uEYvWO0OQCN8DV0U2hfTlVXHBTKcsLGWzzX166m7muuMBuC5XLHQNrMYh6xRu+/t/i00FcFqT7BP4Zeg28Wni3WxHBisSI1T8XLRQ/gud7mI1VBAiZ/AN4aTRKic5QaAAAAAElFTkSuQmCC",
                            "createdAt": "2024-03-22T07:44:13.630Z",
                            "updatedAt": "2024-03-22T07:44:13.630Z",
                            "publishedAt": "2024-03-22T07:47:09.709Z"
                        }
                    }
                }
            }
        },
    "meta": {
        "pagination": {
            "page": 1,
            "pageSize": 25,
            "pageCount": 1,
            "total": 1
        }
    }
  }
  ```


### 3. Edit single notification

- **Endpoint:** `api/app-notifications/:id`

- **Method:** `PUT`

- **Description:** Edit one notification

- **Request:**

  - `200 OK` on success:

  ```json
   {
    "data": {
      "isOpened": false
    }
  }
  ```
