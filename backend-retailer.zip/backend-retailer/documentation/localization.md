# Localization API Documentation

1. The end point for localization is /api/localization/:locale. It is a GET endpoint

2. Locale in the end point is a parameter whose value can be one 8 values wrt the language.
   
   | Language  | Locale |
   | --------- | ------ |
   | English   | en     |
   | Telugu    | te     |
   | Hindi     | hi     |
   | Marathi   | mr     |
   | Bengali   | bn     |
   | Malayalam | ml     |
   | Kannada   | kn     |
   | Tamil     | ta     |

3. If you want to hit the end point in local and get the data in bengali language, then run the retailer code with npm run develop the hit the below end point :
   
   (We are using hi as parameter because it is the locale for hindi)
   
   ```
   http://localhost:1337/api/localization/hi
   ```
   
   And its response will be :
   
   ```json
   [
       {
           "id": 11,
           "Label": "मोबाइल नंबर पंजीकृत नहीं है",
           "createdAt": "2024-01-23T07:27:08.877Z",
           "updatedAt": "2024-02-05T06:19:14.117Z",
           "publishedAt": "2024-01-23T07:27:10.207Z",
           "locale": "hi",
           "key": "error",
           "dynamicText": null
       },
       {
           "id": 8,
           "Label": "आपका ओटीपी सफलतापूर्वक सत्यापित हो गया है",
           "createdAt": "2024-01-23T07:12:00.015Z",
           "updatedAt": "2024-02-05T06:30:26.454Z",
           "publishedAt": "2024-01-23T07:12:01.232Z",
           "locale": "hi",
           "key": "success_message",
           "dynamicText": null
       },
       {
           "id": 9,
           "Label": "मोबाइल नंबर",
           "createdAt": "2024-01-23T07:24:30.212Z",
           "updatedAt": "2024-02-05T06:16:48.974Z",
           "publishedAt": "2024-01-23T07:24:33.137Z",
           "locale": "hi",
           "key": "mobile_number",
           "dynamicText": null
       },
       {
           "id": 7,
           "Label": "बधाई हो",
           "createdAt": "2024-01-23T07:10:58.496Z",
           "updatedAt": "2024-02-05T06:09:20.448Z",
           "publishedAt": "2024-01-23T07:11:00.682Z",
           "locale": "hi",
           "key": "success_wish",
           "dynamicText": null
       },
       {
           "id": 10,
           "Label": "मोबाइल नंबर दर्ज करें",
           "createdAt": "2024-01-23T07:26:20.431Z",
           "updatedAt": "2024-02-05T06:12:04.253Z",
           "publishedAt": "2024-01-23T07:26:22.843Z",
           "locale": "hi",
           "key": "input_message",
           "dynamicText": null
       },
       {
           "id": 20,
           "Label": "सफलता",
           "createdAt": "2024-02-02T04:51:47.104Z",
           "updatedAt": "2024-02-05T06:28:15.851Z",
           "publishedAt": "2024-02-02T04:52:21.028Z",
           "locale": "hi",
           "key": "success",
           "dynamicText": null
       },
       {
           "id": 24,
           "Label": "ओटीपी नंबर",
           "createdAt": "2024-02-02T04:53:57.577Z",
           "updatedAt": "2024-02-05T06:21:25.591Z",
           "publishedAt": "2024-02-02T04:53:58.625Z",
           "locale": "hi",
           "key": "otp_number",
           "dynamicText": null
       },
       {
           "id": 12,
           "Label": "मैंने वी-गार्ड रिश्ता लॉयल्टी प्रोग्राम के नियमों और शर्तों को पढ़ और समझ लिया है और उनका पालन करता हूं।",
           "createdAt": "2024-01-23T07:27:47.938Z",
           "updatedAt": "2024-02-07T09:34:56.826Z",
           "publishedAt": "2024-01-23T07:27:49.452Z",
           "locale": "hi",
           "key": "tnc_statement",
           "dynamicText": "नियम और शर्तें"
       }
   ]
   ```
