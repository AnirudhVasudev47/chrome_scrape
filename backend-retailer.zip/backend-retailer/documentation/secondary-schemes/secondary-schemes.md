## API Contract for Secondary schemes

### Functions Required:

1. **fetchEligibleProducts** : To fetch all eligible products which are applicable for that user based on secondarySchemeId and categoryId.

2. **getAllSecondarySchemes** :  To fetch all the secondary schemes once the retailer clicks on secondary scheme slab on dashboard.

3. **getSchemeDetails** : To fetch slab details for a specific scheme.

4. **fetchListOfSKUFromSKUProducts** : To fetch list of SKU products which are applicable for loggedInUser based on secondarySchemeId,categoryId and subCategoryId.

5. **downloadScheme**: To take the binaryData from SFDC and return it

6. **termsAndConditions**: To take the rich Text data from SFDC and return it

#### 1. Fetch eligible products

**Description :** This API will fetch all eligible products under a scheme. and display their based on subcategories under that category as SKU the response will be nested based on category and subcategory.The other API will fetch SKU details by SeriesCode.

**Logic**:

1. Service function to fetch schemeIds based on loggedInUser.

2. Servcie function to fetch scheme details by scheme ids.

3. Servcie function to fetch scheme product details from secondaryscheme product table.

4. Service function to fetch skuproduct details based on skuproductId.

5. Error handling to catch and log any errors that occur during fetching eligible products.

**Method** : GET

**Endpoint**:

```
 /api/secondary-schemes/products
```

**Request**

```
secondarySchemeId = a1YC10000006BnBMAU
categoryId = a1dC1000000Le7LIAS
```

###### ***Response ***:

```json
{   "secondarySchemeId" : "a1YC10000006BnBMAU"
    "category": "CF COOLGALE PRIME VX 48 SPKL ROSE 1.2m",
    "categoryId": "a1dC1000000Le7LIAS"
    "data": [
        {
            "subCategory": "DU Sine Wave",
            "subCategoryId":c3
            "skuProductDetail": [
                {
                    "skuId": 113,
                    "series": "Fan-RED-SEPL-Fan Exhaust"
                },
                {
                    "skuId": 112,
                    "series": "Fan-Ceiling-Coolgale Prime VX"
                }
            ]
        }
    ]
}
```

#### 2.Fetch all secondary scheme details

**Description** : This api is used to fetch all the secondary scheme details for a logged in retailer.

**Logic**:

1. Service function to fetch scheme ids by category ids

2. Servcie function to fetch scheme details by scheme ids

3. Servcie function to fetch category names from schemes

4. Service function to group schemes by category

5. Error handling to catch and log any errors that occur during fetching secondary schemes.

**Method**: POST

**Endpoint**: 

```
/api/secondary-schemes
```

**Request Body -1 (With Filter)** 

```json
 {
    "pagination": {
        "page": 1,
        "pageSize": 2
    },
    "filters": {
        "schemeStatus": "Active",
        "customDate": {
            "fromDate": "2024-02-28",
            "toDate": "2024-02-29"
        },
        "categoryIds": [
            "01t0K000006QD8cQAG",
            "a0b0K000006IrO3QAK"
        ]
    }
}
```

**Resposne - 1**

```json
{
    "data": [
        {
            "category": "Mixer",
            "categoryId": "01t28000004EdoKAAS",
            "schemes": [
                {
                    "id": 1,
                    "secondarySchemeId": "a1YC100000053LRMAY",
                    "name": "Saikat testing",
                    "targetActivationDate": "2024-02-28",
                    "endDate": "2024-04-27",
                    "schemeType": "Period Based"
                }
            ]
        }
    ],
    "meta": {
        "pagination": {
            "page": 1,
            "pageSize": 2
        },
        "filters": {
            "schemeStatus": "Active",
            "customDate": {
                "fromDate": "2024-02-28",
                "toDate": "2024-02-29"
            },
            "categoryIds": [
                "01t0K000006QD8cQAG",
                "a0b0K000006IrO3QAK"
            ]
        }
    }
}
```

**Request Body -2 (Without Filters)**

```json
{
    "pagination":{
        "page": 1,
        "pageSize": 1
    },
    "filters": {
        "schemeStatus": "",
        "customDate": {
            "fromDate": "",
            "toDate": ""
        },
        "categoryIds": []
    }
}
```

**Response - 2**

```json
{
    "data": [
        {
            "category": "Mixer",
            "categoryId": "01t28000004EdoKAAS",
            "schemes": [
                {
                    "id": 2,
                    "secondarySchemeId": "a1YC1000000578vMAA",
                    "name": "Test NPH_1 8Jan24",
                    "targetActivationDate": "2024-01-23",
                    "endDate": "2025-01-22",
                    "schemeType": "Spot Based"
                }
            ]
        },
        {
            "category": "Digital UPS",
            "categoryId": "01t28000004EdoAAAS",
            "schemes": [
                {
                    "id": 2,
                    "secondarySchemeId": "a1YC1000000578vMAA",
                    "name": "Test NPH_1 8Jan24",
                    "targetActivationDate": "2024-01-23",
                    "endDate": "2025-01-22",
                    "schemeType": "Spot Based"
                }
            ]
        }
    ],
    "meta": {
        "pagination": {
            "page": 1,
            "pageSize": 1
        },
        "filters": {
            "schemeStatus": "",
            "customDate": {
                "fromDate": "",
                "toDate": ""
            },
            "categoryIds": []
        }
    }
}
```

#### 3. Fetch Slab details for a specific scheme

**Description** : This api will fetch the slab details for a specific scheme

**Logic:** 

1. Service function to fetch slab details for given scheme id

2. Error handling to catch and log any errors that occur during fetching slab details for specific scheme.

**Method** : GET

**Endpoint**: 

```
 /api/secondary-schemes/detail/:schemeId
```

**Request**: 

```
api/secondary-schemes/detail/a1YC100000053LRMAY
```

**Response**:

```json
{
    "data": {
        "slabDetails": [
            {
                "slabThresholdFrom": 20,
                "slabThresholdTo": 30,
                "slabCriteriaUOM": "Value",
                "rewardType": "Absolute discount",
                "focName": null,
                "rewardUnit": 20,
                "rewardToBeEarned": "Absolute discount"
            },
            {
                "slabThresholdFrom": 10,
                "slabThresholdTo": 20,
                "slabCriteriaUOM": "Volume",
                "rewardType": "FOC",
                "focName": "a0bC10000008fSbIAI",
                "rewardUnit": 10,
                "rewardToBeEarned": "FOC"
            }
        ]
    }
}
```

#### 4.Fetch List of SKU from sku_products

**Description**   :   This will fetch  list of skus from table by subcategories and series

**Logic**:

1. Service function to fetch schemeIds based on loggedInUser.

2. Servcie function to fetch scheme details by scheme ids.

3. Servcie function to fetch scheme product details from secondaryscheme product table.

4. Service function to fetch skuproduct details based on skuproductId.

5. Service function to fetch skuproduct Name based on subCategoryId with pagination.

6. Error handling to catch and log any errors that occur during fetching list of sku products.

**Method**  :     POST
**Endpoint**:    

```
/api/secondary-schemes/products/sku
```

**Payload** : 

```json
{
    "secondarySchemeId" : "a1YC10000006BnBMAU",
    "categoryId" : "a1dC1000000Le7KIAS",
    "subCategoryId" : "c3",
    "series" : "Fan-SEPL-Fan Exhaust-Red",
    "pagination":{
    "page" : 1,
    "pageSize" : 5
}
}
```

**Response : **

```json
{
    "data": {
        "series": "Fan-SEPL-Fan Exhaust-Red",
        "skuProductList": [
            {
                "skuproductId": 108,
                "product": "VT 12V - 2"
            },
            {
                "skuproductId": 123,
                "product": "VT 12V - 3"
            }
        ]
    },
    "meta": {
        "pagination": {
            "page": 1,
            "pageSize": 5,
            "pageCount": 1,
            "total": 5
        }
    }
}
```

#### 5.Fetch All DMSverified CategoryNames

**Description** : This will fetch all DMSVerified CategoryNames for local filter

**Logic**:

1. Service function to fetch all DMS Verified CategoryIds.

2. Servcie function to fetch all CategoryNames based on CategoryIds.

**Method** : GET

**Endpoint**: 

```
/api/retailer-categories/categoryNames
```

**Response**:

```json
[
    {
        "categoryName": "ALPHA FRESH AIR FAN 9\"",
        "categoryId": "a1dC1000000Le7JIAS"
    },
    {
        "categoryName": "PRIME 1450 - Old",
        "categoryId": "a1dC1000000Le7KIAS"
    },
    {
        "categoryName": "CF COOLGALE PRIME VX 48 SPKL ROSE 1.2m",
        "categoryId": "a1dC1000000Le7LIAS"
    }
]
```

#### 6.Fetch All SecondaySchemesBySchemeId

**Description** : This will fetch all SecondarySchemes based on SecondarySchemeId for local filter

**Logic**:

1. Service function to fetch all SecondarySchemes based on SecondarySchemeId.

**Method** : GET

**Endpoint**:

```
 /api/secondary-schemes/filters
```

**Response**:

```json
[
    {
        "secondarySchemeId": "a1YC10000006BnBMAU",
        "name": "Bharth Yojana"
    },
    {
        "secondarySchemeId": "a1YC10000006BnBMAY",
        "name": "Sukanya Yojana"
    }
]
```

#### 7. Download Scheme API

**Description** : It takes the binary data from SFDC and returns it.

**Logic**: 

1. Service function to fetch the binary data from SFDC.

2. Error handling to catch and log any errors that occur during fetching data from SFDC

**Method**: GET

**Endpoint** :

```
api/secondary-schemes/scheme-download
```

**Response**: 

```
JVBERi0xLjMKJf////8KNyAwIG9iago8PAovVHlwZSAvUGFnZQovUGFyZW50IDEgMCBSCi9NZWRpYUJveCBbMCAwIDYxMiA3OTJdCi9Db250ZW50cyA1IDAgUgovUmVzb3VyY2VzIDYgMCBSCj4+CmVuZG9iago2IDAgb2JqCjw8Ci9Qcm9jU2V0IFsvUERGIC9UZXh0IC9JbWFnZUIgL0ltYWdlQyAvSW1hZ2VJXQovRm9udCA8PAovRjEgOCAwIFIKPj4KPj4KZW5kb2JqCjUgMCBvYmoKPDwKL0xlbmd0aCAzNTIKL0ZpbHRlciAvRmxhdGVEZWNvZGUKPj4Kc3RyZWFtCnicnZSxbsMwDER3fwV/IKpIkUcZMDQUaIduBbwVHVon3jL0/5dCSYHESVNXGU3Lx6e7g5kiRdowRfJeaNp3Xx1fzR7HnyGTCzlzSFlp3HcPz0wsNM7d2+CfheI7jS/d09i9/kMHvQerXy91JEoU8YQJDFGFuYLRY/Ikkj4KWaRBojXvyyngCvuwLkpsx0cfHPmW3vIapsguME/ImDFBFYXUaHDBjO35xRInk6mVxizkHvfSmBZiiTRgXqDIPSgqIcpNoy/yTS6FNmw0oPca9ukRbKazLswRMRTKB1JMbtjCRNoZJQe237t3YhRYoeqKe6EDE7ucmeW9x7p+gXdy0s3lHjbWICu9AgqlowlJd+CjDScO7ApxJTRMmNoRYgwa17p9yx7Drma57HQzg2UES2uNXosIswpMrY4LbaSe2MGgK6m1wroE/PFz2bbqWQ71xS961qylGq6lLpC+AZMWOvcKZW5kc3RyZWFtCmVuZG9iagoxMCAwIG9iagooUERGS2l0KQplbmRvYmoKMTEgMCBvYmoKKFBERktpdCkKZW5kb2JqCjEyIDAgb2JqCihEOjIwMjQwMzIxMTEyNTAyWikKZW5kb2JqCjkgMCBvYmoKPDwKL1Byb2R1Y2VyIDEwIDAgUgovQ3JlYXRvciAxMSAwIFIKL0NyZWF0aW9uRGF0ZSAxMiAwIFIKPj4KZW5kb2JqCjggMCBvYmoKPDwKL1R5cGUgL0ZvbnQKL0Jhc2VGb250IC9IZWx2ZXRpY2EKL1N1YnR5cGUgL1R5cGUxCi9FbmNvZGluZyAvV2luQW5zaUVuY29kaW5nCj4+CmVuZG9iago0IDAgb2JqCjw8Cj4+CmVuZG9iagozIDAgb2JqCjw8Ci9UeXBlIC9DYXRhbG9nCi9QYWdlcyAxIDAgUgovTmFtZXMgMiAwIFIKPj4KZW5kb2JqCjEgMCBvYmoKPDwKL1R5cGUgL1BhZ2VzCi9Db3VudCAxCi9LaWRzIFs3IDAgUl0KPj4KZW5kb2JqCjIgMCBvYmoKPDwKL0Rlc3RzIDw8CiAgL05hbWVzIFsKXQo+Pgo+PgplbmRvYmoKeHJlZgowIDEzCjAwMDAwMDAwMDAgNjU1MzUgZiAKMDAwMDAwMDk3MyAwMDAwMCBuIAowMDAwMDAxMDMwIDAwMDAwIG4gCjAwMDAwMDA5MTEgMDAwMDAgbiAKMDAwMDAwMDg5MCAwMDAwMCBuIAowMDAwMDAwMjA4IDAwMDAwIG4gCjAwMDAwMDAxMTkgMDAwMDAgbiAKMDAwMDAwMDAxNSAwMDAwMCBuIAowMDAwMDAwNzkzIDAwMDAwIG4gCjAwMDAwMDA3MTggMDAwMDAgbiAKMDAwMDAwMDYzMiAwMDAwMCBuIAowMDAwMDAwNjU3IDAwMDAwIG4gCjAwMDAwMDA2ODIgMDAwMDAgbiAKdHJhaWxlcgo8PAovU2l6ZSAxMwovUm9vdCAzIDAgUgovSW5mbyA5IDAgUgovSUQgWzw0ZTcyOGIwMzMwODgzNjRkN2U5MzA5MGU1NDhiNDhiZT4gPDRlNzI4YjAzMzA4ODM2NGQ3ZTkzMDkwZTU0OGI0OGJlPl0KPj4Kc3RhcnR4cmVmCjEwNzcKJSVFT0YK
```

#### 8. Terms And Conditions API

**Description** : It takes the rich text from SFDC and returns it.

**Logic**:

1. Service function to fetch the rich text from SFDC.

2. Error handling to catch and log any errors that occur during fetching data from SFDC

**Method**: GET

**Endpoint** :

```
api/secondary-schemes/tnc
```

**Response**:

```json
{
    "html": "<ol><li>'Please read these terms and conditions (hereinafter referred as ‘terms’) before accessing or using Rishta loyalty program App (hereinafter referred as ‘program’) provided by V-Guard Industries Limited. By accessing or using Rishta loyalty program app, you give your free consent, acknowledge and agree that you are exclusively allowed to access and use V-Guard “Rishta Loyalty Program scheme” in accordance with these terms and conditions. You should read the terms & conditions carefully so as to understand the entire Rishta Loyalty Program scheme before availing the same.',</li><li> 'Your participation in the program, or any part thereof, shall be deemed to signify your intention to be bound by these terms.',</li><li>  'Please note that this is an invite only program which will be sent by the V-Guard Sales team on PAN India basis and is applicable for a period of X year effective from 00/00/0000 to 00/00/0000.',</li><li>  'V-GUARD INDUSTRIES LTD reserves the right to withdraw/suspend/cancel/ amend the whole or any part of this program without prior notice. No part of this program or the benefits accruing here-from are to be construed as ‘consideration’ for the purpose of any contractual relationship.',</li></ol>",
    "lastUpdatedDate": "2024-03-15T11:48:18.984Z"
}
```

**Table Schema:**

![](C:\Users\pvetcha\AppData\Roaming\marktext\images\2024-03-13-10-07-33-image.png)
