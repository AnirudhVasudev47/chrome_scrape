# Steps to Clone the repository to local

1. Clone the repository from VGuard Backend Retailer from Gitlab (https://gitlab.com/v-guard-backend/retailer/-/tree/develop?ref_type=heads) into local.

2. You need to have node JS installed in order to proceed further.

3. Run npm install command to get all the dependencies installed

4. Check if the .env file is present in root folder. If not create a .env file in the root folder with the below contents.

   ```
   HOST=0.0.0.0
   PORT=1337
   APP_KEYS=GhLgWsGsMepIHbL3oADUJg==,RAvG+JcyEWzc6XFZsZDZIQ==,zs5b0tmNCZ5dgqs5sGr/fg==,SV/6eAOjCWsRcP6zECuTQw==
   API_TOKEN_SALT=I6uNG2j5+DseMNiXtaNsDg==
   ADMIN_JWT_SECRET=Tnwou6rv0xGmNvTwy2ZaPA==
   TRANSFER_TOKEN_SALT=QaNmcd3A339LoEo3lYLIfw==

   # Database
   DATABASE_CLIENT=postgres
   DATABASE_HOST=127.0.0.1
   DATABASE_PORT=5432
   DATABASE_NAME=<your postgres db name>
   DATABASE_USERNAME=<your postgres db username>
   DATABASE_PASSWORD=<your postgres db password>
   DATABASE_SSL=false

   # Authorization
   JWT_SECRET=gS8rB1+tiIQlMmQvgC16EA==a
   REFRESH_SECRET=strapisecret
   REFRESH_TOKEN_EXPIRES=30d
   JWT_TOKEN_EXPIRES=1d
   OTP_EXPIRES=10 # in minutes
   ACCOUNT_LOCKED_PERIOD=1440 # in minutes
   RESEND_API_BLOCK_DURATION_SECONDS=60
   ENCRYPTION_PASSWORD=tobemodified

   # Aadhar verification
   PATRON_LOGIN_URL=https://preproduction.signzy.tech/api/v2/patrons/login
   PATRON_USERNAME=vguard-preprod_v2
   PATRON_PASSWORD=XfKjXQJlVY
   PATRON_IDENTITIES_URL=https://preproduction.signzy.tech/api/v2/patrons
   PATRON_IDENTITY_EMAIL=admin@signzy.com
   SNOOPS_URL=https://preproduction.signzy.tech/api/v2/snoops
   ```

5. To run the code, use command npm run develop

6. Once the code has run successfully, you can access the Strapi UI with url below :

   http://localhost:1337/admin

7. If you are using Strapi for first time, you need to create your account by giving our first name, last name, deloitte mail id, password.

8. Once logged in, go to Settings > Roles (under User and Permissions plugins) to create two roles:

   - Primary user
   - Secondary user

9. After setting up the roles, you have to go to Content Manager > Categories and use the import option to import the initial data.

10. After importing the data, run the seed files to initialize the application with default data.
