export default ({ env }) => ({
  // ...
  // "users-permissions": {
  //   config: {
  //     jwt: {
  //       expiresIn: env("JWT_TOKEN_EXPIRES", "1d"),
  //     },
  //   },
  // },
  'notification': {
    enabled: true,
    resolve: './src/plugins/notification'
  },
  // ...
});
