export default ({ env }) => ({
  upload: {
      config: {
          provider: 'aws-s3',
          providerOptions: {
              s3Options: {
                  region: env('AWS_REGION'),
                  params: {
                    Bucket: env('AWS_BUCKET_NAME'),
                  },
              }
          },
      },
  }
});