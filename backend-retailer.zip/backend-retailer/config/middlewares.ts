export default [
  "strapi::logger",
  "strapi::errors",
  "strapi::security",
  "strapi::cors",
  "strapi::poweredBy",
  "strapi::query",
  "strapi::body",
  {
    resolve: "../src/middlewares/get-logged-in-user.ts",
  },
  "strapi::session",
  "strapi::favicon",
  "strapi::public",
];
