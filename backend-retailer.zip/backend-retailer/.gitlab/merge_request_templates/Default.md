## Story / Task link

(Add story / task link from Octane)

## Description

(Add description of the story)

## Screenshots

(Add Screenshots of the API running on Postman)

## Documentation
(Add file link for the documentation)

## I have - (Use X to mark it checked)
- [ ] Completed the implmentation of the given story
- [ ] Successfully executed on my machine
- [ ] Tested and confirmed that it works fine on Postman
- [ ] Added documentation
- [ ] Added Screenshots 
